import React, { useState, useRef, useEffect } from "react";

interface HighlightEditorProps {
  value: string;
  onChange: (val: string) => void;
  language: string;
  inlineSuggestion?: string;
  onAcceptSuggestion?: () => void;
  diffMode?: boolean;
  targetLines?: string;
  replacementLines?: string;
}

export default function HighlightEditor({
  value,
  onChange,
  language,
  inlineSuggestion,
  onAcceptSuggestion,
  diffMode,
  targetLines,
  replacementLines,
}: HighlightEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const highlightRef = useRef<HTMLPreElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const lineNumbersRef = useRef<HTMLDivElement>(null);

  // Sync scrolling of textarea and highlight/line-numbers div
  const handleScroll = () => {
    if (textareaRef.current && highlightRef.current && lineNumbersRef.current) {
      highlightRef.current.scrollTop = textareaRef.current.scrollTop;
      highlightRef.current.scrollLeft = textareaRef.current.scrollLeft;
      lineNumbersRef.current.scrollTop = textareaRef.current.scrollTop;
    }
  };

  // Keep track of cursor position for suggestions
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Tab") {
      if (inlineSuggestion && onAcceptSuggestion) {
        e.preventDefault();
        onAcceptSuggestion();
      } else {
        // Normal tab indent instead of changing focus
        e.preventDefault();
        const start = e.currentTarget.selectionStart;
        const end = e.currentTarget.selectionEnd;
        const newValue = value.substring(0, start) + "  " + value.substring(end);
        onChange(newValue);
        
        // Reset selection soon
        setTimeout(() => {
          if (textareaRef.current) {
            textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + 2;
          }
        }, 0);
      }
    }
  };

  const highlightCode = (code: string, lang: string) => {
    if (!code) return "";
    let escaped = code
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

    if (lang === "html" || lang === "xml") {
      escaped = escaped.replace(/(&lt;\/?[a-zA-Z0-9:-]+)/g, '<span class="text-[#f43f5e] font-semibold">$1</span>');
      escaped = escaped.replace(/(\s[a-zA-Z0-9:-]+=)/g, '<span class="text-[#fb923c]">$1</span>');
      escaped = escaped.replace(/(['"].*?['"])/g, '<span class="text-[#34d399]">$1</span>');
    } else {
      const keywords = /\b(const|let|var|function|return|import|export|from|class|extends|if|else|for|while|new|try|catch|async|await|const|def|import|from|print|class|lambda|return|typeof|instanceof|void|in|of)\b/g;
      escaped = escaped.replace(keywords, '<span class="text-[#ff5588] font-bold">$1</span>');

      // Types & Objects
      const typeWords = /\b(string|number|boolean|any|void|unknown|never|Record|Partial|Omit|any|Array|Map|Set|Promise|Response|Request)\b/g;
      escaped = escaped.replace(typeWords, '<span class="text-[#a3e635] font-semibold">$1</span>');

      // Strings
      escaped = escaped.replace(/(["'`].*?["'`])/g, '<span class="text-[#38bdf8]">$1</span>');

      // Builtins & function names
      escaped = escaped.replace(/\b([a-zA-Z0-9_]+)(?=\()/g, '<span class="text-[#60a5fa]">$1</span>');

      // Comments
      escaped = escaped.replace(/(\/\/.*$|\/\*[\s\S]*?\*\/|#.*$)/gm, '<span class="text-gray-500 italic">$1</span>');
    }

    return escaped;
  };

  const lines = value.split("\n");
  const linesCount = Math.max(lines.length, 1);

  // Generate highlight markup with inline suggestion
  const rawSuggestion = inlineSuggestion ? 
    ` <span class="text-gray-600 italic select-none font-medium opacity-70">${inlineSuggestion} [Press Tab]</span>` : "";

  // Handle Diff highlighters
  let outputHtml = highlightCode(value, language);
  if (diffMode && targetLines && replacementLines) {
    // Custom diff highlighting simulation in the syntax view
    if (value.includes(targetLines)) {
      const parts = value.split(targetLines);
      const highlightedTarget = highlightCode(targetLines, language);
      const highlightedReplacement = highlightCode(replacementLines, language);

      outputHtml = highlightCode(parts[0], language) +
        `<div class="bg-rose-950/40 border-l-2 border-rose-500 px-1 line-through opacity-80" title="Target for removal">${highlightedTarget}</div>` +
        `<div class="bg-emerald-950/40 border-l-2 border-emerald-500 px-1" title="Proposed addition">${highlightedReplacement}</div>` +
        highlightCode(parts.slice(1).join(targetLines), language);
    }
  }

  // Inject suggestion to HTML line if suggestion exists
  if (inlineSuggestion) {
    outputHtml += rawSuggestion;
  }

  // Trigger scroll-sync on size updates
  useEffect(() => {
    handleScroll();
  }, [value, inlineSuggestion]);

  return (
    <div id="editor-viewport" ref={containerRef} className="flex flex-1 relative bg-[#0b0f14] text-gray-300 font-mono text-xs overflow-hidden h-full">
      {/* Line Numbers column */}
      <div
        ref={lineNumbersRef}
        className="w-12 bg-[#090c10] text-[#4b5563] text-right py-3 pr-3 select-none overflow-hidden flex flex-col items-stretch align-top border-r border-[#1a202a]"
        style={{ scrollbarWidth: "none" }}
      >
        {Array.from({ length: linesCount }).map((_, i) => (
          <div key={i} className="h-5 leading-5 text-[11px] font-mono tracking-tight text-gray-600">
            {i + 1}
          </div>
        ))}
      </div>

      {/* Editing Surface Area */}
      <div className="flex-1 relative overflow-hidden h-full">
        {/* Render Layer (Fading underlying pre-formatted container) */}
        <pre
          ref={highlightRef}
          className="absolute inset-0 p-3 leading-5 m-0 overflow-auto whitespace-pre font-mono pointer-events-none select-none select-all break-normal break-keep"
          style={{ scrollbarWidth: "none" }}
          dangerouslySetInnerHTML={{ __html: outputHtml }}
        />

        {/* Editing Input Layer (On Top, text transparent caret visible) */}
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          onScroll={handleScroll}
          spellCheck={false}
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          className="absolute inset-0 p-3 leading-5 bg-transparent text-transparent caret-cyan-400 focus:outline-none focus:ring-0 resize-none font-mono whitespace-pre w-full h-full overflow-auto break-normal select-text selection:bg-blue-500/20 selection:text-transparent"
        />
      </div>

      {/* Suggests Indicator Floating Card */}
      {inlineSuggestion && (
        <div className="absolute bottom-3 right-4 bg-gray-900/95 border border-blue-500/30 text-[10px] text-blue-400 font-mono px-2 py-1 rounded shadow-lg backdrop-blur-md z-10 animate-pulse flex items-center gap-1">
          <span>🔮 ghost suggests:</span>
          <span className="text-white font-semibold">Press TAB to complete</span>
        </div>
      )}
    </div>
  );
}
