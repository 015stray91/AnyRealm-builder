import { ProjectTemplate } from "./types";

export const templates: ProjectTemplate[] = [
  {
    id: "react-dashboard",
    name: "Interactive SaaS Dashboard",
    description: "A fast, responsive analytics dashboard featuring responsive charts, modern metrics, and Tailwind styling.",
    icon: "LayoutDashboard",
    files: [
      {
        id: "index-html",
        path: "index.html",
        type: "file",
        content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SaaS Dashboard App</title>
    <!-- Tailwind CSS Play CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/lucide-static@0.400.0/font/lucide.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Inter', system-ui, sans-serif; }
    </style>
</head>
<body class="bg-[#0b0f14] text-gray-100 min-h-screen">
    <div id="app"></div>
    <script src="app.js"></script>
</body>
</html>`
      },
      {
        id: "app-js",
        path: "app.js",
        type: "file",
        content: `// SaaS Analytics Application Engine
const state = {
  users: 24890,
  growth: 14.8,
  revenue: 124500,
  activeNow: 412,
  metrics: [
    { label: "Mon", value: 3200, revenue: 15400 },
    { label: "Tue", value: 4100, revenue: 19800 },
    { label: "Wed", value: 3900, revenue: 18200 },
    { label: "Thu", value: 5200, revenue: 24500 },
    { label: "Fri", value: 6500, revenue: 29800 },
    { label: "Sat", value: 4800, revenue: 21000 },
    { label: "Sun", value: 5900, revenue: 26000 }
  ]
};

function renderDashboard() {
  const container = document.getElementById('app');
  if (!container) return;

  // Header Banner
  let html = \`
    <div class="max-w-7xl mx-auto px-6 py-8">
      <div class="flex items-center justify-between mb-8 border-b border-gray-800 pb-6">
        <div>
          <h1 class="text-2xl font-semibold text-white tracking-tight flex items-center gap-2">
            <span class="text-blue-500 font-black">⚙</span> Zenith Cloud Analytics
          </h1>
          <p class="text-sm text-gray-400 mt-1">Real-time SaaS billing metrics and interactive cluster performance dashboard.</p>
        </div>
        <div class="flex items-center gap-3">
          <span class="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
            <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span> Live Cluster: Active
          </span>
          <button id="refreshBtn" class="px-3 py-1.5 text-xs font-medium rounded bg-gray-800 border border-gray-700 hover:bg-gray-700 text-gray-200 transition-all">
            Refresh Data
          </button>
        </div>
      </div>

      <!-- Quick Stats Card Grid -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition-all">
          <div class="flex items-center justify-between mb-3 text-gray-400">
            <span class="text-xs font-medium uppercase tracking-wider">Total Active Users</span>
            <span class="text-sm">👥</span>
          </div>
          <h3 class="text-3xl font-bold text-white">\${state.users.toLocaleString()}</h3>
          <p class="text-xs text-emerald-400 mt-1">▲ +\${state.growth}% vs last week</p>
        </div>

        <div class="bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition-all">
          <div class="flex items-center justify-between mb-3 text-gray-400">
            <span class="text-xs font-medium uppercase tracking-wider">Monthly Revenue</span>
            <span class="text-sm">💰</span>
          </div>
          <h3 class="text-3xl font-bold text-white">$\${state.revenue.toLocaleString()}</h3>
          <p class="text-xs text-emerald-400 mt-1">▲ +21.4% year-over-year</p>
        </div>

        <div class="bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition-all">
          <div class="flex items-center justify-between mb-3 text-gray-400">
            <span class="text-xs font-medium uppercase tracking-wider">Simulated Traffic</span>
            <span class="text-sm">⚡</span>
          </div>
          <h3 class="text-3xl font-bold text-white">\${state.activeNow}</h3>
          <p class="text-xs text-yellow-400 mt-1">● Peak rates expected today</p>
        </div>

        <div class="bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition-all">
          <div class="flex items-center justify-between mb-3 text-gray-400">
            <span class="text-xs font-medium uppercase tracking-wider">API Health</span>
            <span class="text-sm">🛡️</span>
          </div>
          <h3 class="text-3xl font-bold text-white">99.98%</h3>
          <p class="text-xs text-emerald-400 mt-1">✔ Node healthy</p>
        </div>
      </div>

      <!-- Data Visualizations -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="bg-gray-900 border border-gray-800 rounded-xl p-6 lg:col-span-2">
          <h3 class="text-base font-semibold text-white mb-6">Weekly Active Traffic Trends</h3>
          <div class="flex items-end gap-3 h-52 pt-4">
            \${state.metrics.map(d => {
              const heightPercent = Math.round((d.value / 7000) * 100);
              return \`
                <div class="flex-1 flex flex-col items-center gap-2 group cursor-pointer">
                  <div class="relative w-full bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 hover:border-blue-500/50 rounded-md transition-all flex flex-col justify-end" style="height: \${heightPercent}%">
                    <div class="absolute -top-10 left-1/2 -translate-x-1/2 bg-gray-950 text-white text-[10px] py-1 px-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity border border-gray-800 pointer-events-none whitespace-nowrap">
                      \${d.value.toLocaleString()} users
                    </div>
                    <div class="w-full bg-gradient-to-t from-blue-600 to-indigo-500 rounded-md min-h-[4px]" style="height: 30%"></div>
                  </div>
                  <span class="text-xs text-gray-500 font-mono">\${d.label}</span>
                </div>
              \`;
            }).join('')}
          </div>
        </div>

        <div class="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <h3 class="text-base font-semibold text-white mb-4">Latest Ingress Log</h3>
          <div id="logsContainer" class="space-y-3 font-mono text-[11px] overflow-y-auto max-h-52 pr-1 text-gray-400">
            <p><span class="text-blue-500">[04:41]</span> API: Authorized key token: client_prod_A4f</p>
            <p><span class="text-blue-500">[04:42]</span> DB: Postgres sync lock acquired in 12ms</p>
            <p><span class="text-yellow-500">[04:43]</span> CLUSTER: Resource threshold warning > 85% cpu (Node-2)</p>
            <p><span class="text-blue-500">[04:45]</span> SERVER: Garbage collection cycle freed 24.1MB Heap</p>
            <p><span class="text-green-500">[04:46]</span> APP: Zenith Cloud up-to-date and synchronized.</p>
          </div>
        </div>
      </div>
    </div>
  \`;

  container.innerHTML = html;

  // Add event listeners after rendering
  document.getElementById('refreshBtn')?.addEventListener('click', () => {
    state.users += Math.round((Math.random() - 0.2) * 150);
    state.revenue += Math.round(Math.random() * 850);
    state.activeNow = Math.round(300 + Math.random() * 200);
    renderDashboard();
    
    // Add real-time log
    const logs = document.getElementById('logsContainer');
    if (logs) {
      const now = new Date();
      const timeStr = \`[\${String(now.getHours()).padStart(2, '0')}:\${String(now.getMinutes()).padStart(2, '0')}]\`;
      const newLog = document.createElement('p');
      newLog.innerHTML = \`<span class="text-green-500">\${timeStr}</span> CLIENT: Refresh event triggered. Stats updated.\`;
      logs.prepend(newLog);
    }
  });
}

// Boot setup
window.addEventListener('DOMContentLoaded', renderDashboard);
renderDashboard();`
      }
    ],
    defaultOpenFiles: ["app.js", "index.html"],
    defaultCommand: "npm run dev"
  },
  {
    id: "galaxy-gravity-sim",
    name: "Astronomical Orbital Physics Sim",
    description: "An interactive HTML5 gravity engine drawing orbits, collision particles, and asteroid sweeps on a canvas loop.",
    icon: "Orbit",
    files: [
      {
        id: "space-html",
        path: "index.html",
        type: "file",
        content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Astronomical Orbit Sim</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { font-family: monospace; background-color: #020205; margin: 0; padding: 0;}
    </style>
</head>
<body class="overflow-hidden select-none h-screen flex flex-col justify-between text-gray-300">
    <div class="absolute top-4 left-4 z-10 bg-black/60 backdrop-blur-md border border-indigo-900/40 p-4 rounded-lg max-w-sm pointer-events-auto">
        <h1 class="text-indigo-400 font-bold text-sm tracking-widest uppercase mb-1">Orbital Physics Core</h1>
        <p class="text-[10px] text-gray-400 mb-3">Simulating real-time Newtonian mechanical gravity computations in custom canvas viewport.</p>
        <div class="space-y-2 text-[11px]">
            <div class="flex justify-between">
                <span>Speed Mod:</span>
                <span id="speedVal" class="text-indigo-300 font-bold">1.0x</span>
            </div>
            <input type="range" id="speedSlider" min="0" max="3" step="0.1" value="1" class="w-full accent-indigo-500 bg-gray-900 h-1.5 rounded-lg appearance-none">
            
            <div class="flex justify-between pt-1">
                <span>Attractor Mass:</span>
                <span id="massVal" class="text-rose-400 font-bold">50,000</span>
            </div>
            <input type="range" id="massSlider" min="10000" max="150000" step="5000" value="50000" class="w-full accent-rose-500 bg-gray-900 h-1.5 rounded-lg appearance-none">
        </div>
        <div class="mt-4 flex gap-2">
            <button id="addPlanet" class="flex-1 bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-400/30 font-semibold py-1 rounded text-[10px] uppercase tracking-wider text-indigo-200 hover:text-white transition-all">Add Body</button>
            <button id="clearSim" class="flex-1 bg-rose-900/35 hover:bg-rose-900/60 border border-rose-500/20 font-semibold py-1 rounded text-[10px] uppercase tracking-wider text-rose-300 transition-all">Collapse</button>
        </div>
    </div>

    <!-- Active Physics Visualizer Canvas -->
    <canvas id="stage" class="absolute inset-0 w-full h-full cursor-crosshair"></canvas>

    <div class="absolute bottom-4 right-4 z-10 text-[10px] text-indigo-400/70 font-mono tracking-widest uppercase bg-black/40 px-3 py-1.5 rounded border border-indigo-900/20">
        Newtonian Simulator (1000 Stars)
    </div>

    <script src="physics.js"></script>
</body>
</html>`
      },
      {
        id: "physics-js",
        path: "physics.js",
        type: "file",
        content: `// Core Mechanics for Space Orbital Simulation
const canvas = document.getElementById('stage');
const ctx = canvas.getContext('2d');

let width = canvas.width = window.innerWidth;
let height = canvas.height = window.innerHeight;

// Physics variables
let G = 0.5;
let speedMult = 1.0;
let baseSunMass = 50000;

window.addEventListener('resize', () => {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
});

class Body {
    constructor(x, y, vx, vy, radius, mass, color, isSun = false) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.radius = radius;
        this.mass = mass;
        this.color = color;
        this.isSun = isSun;
        this.history = [];
    }

    update() {
        if (!this.isSun) {
            this.x += this.vx * speedMult;
            this.y += this.vy * speedMult;

            // Track orbital history trail
            this.history.push({ x: this.x, y: this.y });
            if (this.history.length > 150) {
                this.history.shift();
            }
        }
    }

    draw() {
        // Draw history trail
        if (this.history.length > 1) {
            ctx.beginPath();
            ctx.strokeStyle = this.color + '22'; // low opacity
            ctx.lineWidth = 1.5;
            ctx.moveTo(this.history[0].x, this.history[0].y);
            for (let i = 1; i < this.history.length; i++) {
                ctx.lineTo(this.history[i].x, this.history[i].y);
            }
            ctx.stroke();
        }

        // Draw body core
        ctx.beginPath();
        const grad = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.radius * 2.5);
        if (this.isSun) {
            grad.addColorStop(0, '#ffffff');
            grad.addColorStop(0.2, '#ffaa00');
            grad.addColorStop(1, '#ff005500');
        } else {
            grad.addColorStop(0, this.color);
            grad.addColorStop(1, this.color + '00');
        }
        ctx.fillStyle = grad;
        ctx.arc(this.x, this.y, this.radius * 2.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.beginPath();
        ctx.fillStyle = this.color;
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();
    }
}

// Starfield Generator
const stars = Array.from({ length: 250 }, () => ({
    x: Math.random() * width,
    y: Math.random() * height,
    size: Math.random() * 1.5,
    bright: Math.random()
}));

function drawStars() {
    ctx.fillStyle = '#ffffff';
    stars.forEach(s => {
        ctx.globalAlpha = s.bright * (0.3 + Math.random() * 0.7);
        ctx.fillRect(s.x, s.y, s.size, s.size);
    });
    ctx.globalAlpha = 1.0;
}

// Pre-populate gravitational centers
let sun = new Body(width / 2, height / 2, 0, 0, 14, baseSunMass, '#ffbf00', true);
let bodies = [];

function initBodies() {
    bodies = [];
    // Orbit 1: Emerald Ring
    addStablePlanet(130, '#00ffaa', 4, 1.2);
    // Orbit 2: Lilac Gas
    addStablePlanet(210, '#cc88ff', 6.5, 1.1);
    // Orbit 3: Pyro Rock
    addStablePlanet(290, '#ff4444', 3, 0.95);
}

function addStablePlanet(distance, color, size, velocityFactor) {
    const x = sun.x;
    const y = sun.y - distance;
    // circular orbit speed equation: v = sqrt(G * M / r)
    const orbitalSpeed = Math.sqrt((G * sun.mass) / distance) * velocityFactor;
    bodies.push(new Body(x, y, orbitalSpeed, 0, size, size * 10, color));
}

function checkPhysicsLoop() {
    ctx.fillStyle = '#020206';
    ctx.fillRect(0, 0, width, height);

    drawStars();
    sun.draw();

    bodies.forEach(b => {
        // Calculate gravitational attraction toward Sun: F = G * m1 * m2 / r^2
        const dx = sun.x - b.x;
        const dy = sun.y - b.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist > 15) {
            const force = (G * sun.mass) / (dist * dist);
            // Accelerations: ax = force * dx / dist
            b.vx += force * (dx / dist) * speedMult;
            b.vy += force * (dy / dist) * speedMult;
        }

        b.update();
        b.draw();
    });

    requestAnimationFrame(checkPhysicsLoop);
}

// User Actions
document.getElementById('speedSlider')?.addEventListener('input', (e) => {
    speedMult = parseFloat(e.target.value);
    document.getElementById('speedVal').innerText = bgSpeedFormat(speedMult);
});

document.getElementById('massSlider')?.addEventListener('input', (e) => {
    sun.mass = parseInt(e.target.value);
    document.getElementById('massVal').innerText = sun.mass.toLocaleString();
});

document.getElementById('addPlanet')?.addEventListener('click', () => {
    const randomDistance = 100 + Math.random() * (Math.min(width, height) / 2 - 120);
    const colors = ['#00e5ff', '#ff00aa', '#ffd600', '#22ff66', '#ff8d00'];
    const col = colors[Math.floor(Math.random() * colors.length)];
    addStablePlanet(randomDistance, col, 3.5 + Math.random() * 4, 1.1 + (Math.random() - 0.5) * 0.2);
});

document.getElementById('clearSim')?.addEventListener('click', () => {
    bodies = [];
});

canvas.addEventListener('click', (e) => {
    // Spawn custom body with mouse vector
    const dx = e.clientX - sun.x;
    const dy = e.clientY - sun.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const speed = Math.sqrt((G * sun.mass) / dist) * 1.1;
    // Perpendicular vector for forward circular orbits
    bodies.push(new Body(e.clientX, e.clientY, -speed * (dy / dist), speed * (dx / dist), 5, 25, '#ffe100'));
});

function bgSpeedFormat(val) {
    if (val === 0) return "PAUSED";
    return val.toFixed(1) + "x";
}

initBodies();
checkPhysicsLoop();`
      }
    ],
    defaultOpenFiles: ["physics.js", "index.html"],
    defaultCommand: "python -m http.server 3000"
  },
  {
    id: "python-cli",
    name: "Autodoc AI Planner (Node Simulator)",
    description: "A server-side scheduling tool that parses task JSON and optimizes project delivery pathways.",
    icon: "SquareTerminal",
    files: [
      {
        id: "planner-js",
        path: "planner.js",
        type: "file",
        content: `// Task Scheduling Optimization Core Script
const fs = require('fs');

class TaskOptimizer {
  constructor(taskFile) {
    this.taskFile = taskFile;
  }

  loadTasks() {
    try {
      if (!fs.existsSync(this.taskFile)) {
        console.log("[-] Target task JSON matrix does not exist. Creating default set...");
        const defaults = [
          { id: "T1", name: "Construct UI Shell", duration: 8, dep: [] },
          { id: "T2", name: "Create Express Routing Engine", duration: 5, dep: ["T1"] },
          { id: "T3", name: "Integrate Gemini AI Pipeline", duration: 12, dep: ["T2"] },
          { id: "T4", name: "Verify Security Certificates", duration: 3, dep: ["T1"] },
          { id: "T5", name: "Cloud Sandbox Deployment Alpha", duration: 7, dep: ["T3", "T4"] }
        ];
        this.saveTasks(defaults);
        return defaults;
      }
      const data = fs.readFileSync(this.taskFile, 'utf8');
      return JSON.parse(data);
    } catch (err) {
      console.error("[!] Error loading task matrices:", err.message);
      return [];
    }
  }

  saveTasks(tasks) {
    fs.writeFileSync(this.taskFile, JSON.stringify(tasks, null, 2));
  }

  computePath() {
    console.log("[⚙] OPTIMIZER: Building task dependencies vector tree...");
    const tasks = this.loadTasks();
    if (tasks.length === 0) {
      console.log("[!] Task directory is empty.");
      return;
    }

    // Step 1: Topological Sort mapping for critical path analysis
    const completed = new Set();
    const ordered = [];
    let loopsGuard = 0;

    while (ordered.length < tasks.length && loopsGuard < 100) {
      loopsGuard++;
      for (const t of tasks) {
        if (ordered.includes(t.id)) continue;
        const dependenciesMet = t.dep.every(d => completed.has(d));
        if (dependenciesMet) {
          ordered.push(t.id);
          completed.add(t.id);
        }
      }
    }

    if (loopsGuard >= 100) {
      console.log("\\n[⛔] ERROR: Deadlock detected in dependency layout. Circular dependencies found!");
      return;
    }

    // Direct path tracking
    console.log("\\n[✔] OPTIMIZER SUMMARY:");
    console.log("-----------------------------------------");
    console.log("CRITICAL ORDER OF RELEASES:");
    let accumTime = 0;
    ordered.forEach((id, index) => {
      const t = tasks.find(x => x.id === id);
      accumTime += t.duration;
      console.log(\`  \${index + 1}. [\${t.id}] \${t.name.padEnd(35)} (⌛ \${t.duration}hrs) -> Cumulative: \${accumTime}hrs\`);
    });
    console.log("-----------------------------------------");
    console.log(\`Estimated project timeline is: \${accumTime} work hours\\n\`);
  }
}

// Executing pipeline
console.log("=========================================");
console.log("        Cascade AI Project Planner       ");
console.log("=========================================");
const optimizer = new TaskOptimizer("tasks.json");
optimizer.computePath();`
      },
      {
        id: "tasks-json",
        path: "tasks.json",
        type: "file",
        content: `[
  {
    "id": "T1",
    "name": "Construct UI Shell",
    "duration": 8,
    "dep": []
  },
  {
    "id": "T2",
    "name": "Create Express Routing Engine",
    "duration": 5,
    "dep": [
      "T1"
    ]
  },
  {
    "id": "T3",
    "name": "Integrate Gemini AI Pipeline",
    "duration": 12,
    "dep": [
      "T2"
    ]
  },
  {
    "id": "T4",
    "name": "Verify Security Certificates",
    "duration": 3,
    "dep": [
      "T1"
    ]
  },
  {
    "id": "T5",
    "name": "Cloud Sandbox Deployment Alpha",
    "duration": 7,
    "dep": [
      "T3",
      "T4"
    ]
  }
]`
      }
    ],
    defaultOpenFiles: ["planner.js"],
    defaultCommand: "node planner.js"
  }
];
