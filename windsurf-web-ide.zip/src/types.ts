export interface VirtualFile {
  id: string;
  path: string;
  content: string;
  type: "file" | "directory";
}

export interface Tab {
  fileId: string;
}

export interface TerminalCommand {
  id: string;
  input: string;
  output: string;
  directory: string;
  timestamp: string;
  isStreaming?: boolean;
}

export interface VirtualAction {
  id: string;
  type: "create_file" | "edit_file" | "run_command" | "show_preview";
  path?: string;
  content?: string;
  targetLines?: string;
  replacementLines?: string;
  command?: string;
  description: string;
  status: "pending" | "accepted" | "rejected" | "running" | "success" | "failed";
}

export interface CascadeMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  thought?: string;
  actions?: VirtualAction[];
  timestamp: string;
  isExecuting?: boolean;
}

export interface ProjectTemplate {
  name: string;
  id: string;
  description: string;
  icon: string;
  files: VirtualFile[];
  defaultOpenFiles: string[];
  defaultCommand?: string;
  previewUrl?: string;
}

// Collaboration and Presence UI Types
export interface Collaborator {
  id: string;
  name: string;
  color: string;
  cursor?: {
    fileId: string;
    line: number;
    ch: number;
  };
}

// Git Structural Interface
export interface GitCommit {
  hash: string;
  author: string;
  message: string;
  timestamp: string;
  filesSnapshot: { [path: string]: string }; // Stores full workspace files snapshot
  meta?: {
    branch: string;
    parent?: string;
  };
}

export interface GitState {
  isInitialized: boolean;
  currentBranch: string;
  branches: string[];
  commits: GitCommit[];
  staged: { [path: string]: string }; // Contains file path -> snap content at stage time
  stash: { id: string; msg: string; files: { [path: string]: string } }[];
  remotes: string[];
}

