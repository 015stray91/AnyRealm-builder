import React, { useState, useEffect, useRef } from "react";
import {
  LayoutDashboard,
  Orbit,
  SquareTerminal,
  GitBranch,
  Plus,
  Trash2,
  Play,
  Check,
  X,
  Send,
  Terminal,
  Globe,
  Sparkles,
  Github,
  User,
  Folder,
  File,
  Settings,
  Share2,
  Copy,
  RotateCw,
  ArrowUpRight,
  AlertCircle,
  GitMerge,
  GitCommit,
  GitPullRequest,
  Search,
  Code2,
  Cpu,
  RefreshCw,
  Lock,
  MessageSquare,
  Activity,
  History,
  Command,
  CheckCircle2,
  HelpCircle,
  Laptop,
  Smartphone,
  Radio,
  Tv
} from "lucide-react";
import { VirtualFile, TerminalCommand, GitState, CascadeMessage, Collaborator, ProjectTemplate } from "./types";
import { templates } from "./data";
import HighlightEditor from "./components/HighlightEditor";

// Predefined ghost suggestion pairs for files to trigger the advanced IDE autocomplete look
const SUGGESTIONS: { [path: string]: string } = {
  "app.js": "const trackingId = 'GA-99214-X'; // Analytics auto-inject",
  "physics.js": "const dt = 0.016; // Stable Delta frame step",
  "planner.js": "console.log('[✔] System check completed successfully.');",
  "index.html": "<!-- Collaborative remote terminal hook active -->",
};

export default function App() {
  // ----------------- App Workspace States -----------------
  const [files, setFiles] = useState<VirtualFile[]>([]);
  const [activeTemplateId, setActiveTemplateId] = useState<string>("react-dashboard");
  const [currentFileId, setCurrentFileId] = useState<string>("app-js");
  const [tabs, setTabs] = useState<string[]>(["app.js", "index.html"]);
  
  // ----------------- WebSocket & Presence configuration -----------------
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<"connecting" | "connected" | "disconnected">("disconnected");
  const [me, setMe] = useState<Collaborator>({
    id: "local_dev",
    name: "Humble Creator",
    color: "#00D1FF",
  });
  const [collaborators, setCollaborators] = useState<{ [id: string]: Collaborator }>({});
  
  // ----------------- Git state integration -----------------
  const [gitState, setGitState] = useState<GitState>({
    isInitialized: false,
    currentBranch: "main",
    branches: ["main"],
    commits: [],
    staged: {},
    stash: [],
    remotes: ["origin  https://github.com/windsurf/collaborative-app.git"]
  });
  const [newBranchName, setNewBranchName] = useState("");
  const [commitMessage, setCommitMessage] = useState("");
  const [selectedMergeBranch, setSelectedMergeBranch] = useState("main");
  
  // ----------------- GitHub Account & Codespaces state -----------------
  const [githubUser, setGithubUser] = useState<{
    loggedIn: boolean;
    username: string;
    avatarUrl: string;
    reposCount: number;
    codespaceActive: boolean;
    codespaceServer: "local" | "github";
    pingTime: number;
  }>({
    loggedIn: false,
    username: "",
    avatarUrl: "",
    reposCount: 0,
    codespaceActive: false,
    codespaceServer: "local",
    pingTime: 0
  });
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [temporaryGithubToken, setTemporaryGithubToken] = useState("");

  // ----------------- Navigation Toggles -----------------
  const [activeLeftTab, setActiveLeftTab] = useState<"explorer" | "git" | "codespaces" | "help" | "android">("explorer");

  // ----------------- Terminal Simulator UI -----------------
  const [terminalHistory, setTerminalHistory] = useState<TerminalCommand[]>([]);
  const [terminalInput, setTerminalInput] = useState("");
  const [terminalActiveTab, setTerminalActiveTab] = useState<"terminal" | "logs" | "git" | "preview">("preview");
  const [newFileNameInput, setNewFileNameInput] = useState("");
  const [editorGhostSuggestion, setEditorGhostSuggestion] = useState<string>("");

  // ----------------- Termux specific emulator states -----------------
  const [termuxRoot, setTermuxRoot] = useState<boolean>(false);
  const [termuxPackages, setTermuxPackages] = useState<string[]>(["termux-api"]);
  const [termuxStorage, setTermuxStorage] = useState<boolean>(false);
  const [termuxTheme, setTermuxTheme] = useState<string>("dracula");
  const [termuxFont, setTermuxFont] = useState<string>("monospace");
  const [termuxToastMessage, setTermuxToastMessage] = useState<string>("");

  // ----------------- Cascade flow engine states (AI tool) -----------------
  const [messages, setMessages] = useState<CascadeMessage[]>([
    {
      id: "welcome",
      role: "assistant",
      text: "Hello! I am **Cascade**, your collaborative Windsurf AI copilot. I am ready to scaffold features, inspect directory graphs, resolve git merges, or run terminal compilations either locally or on GitHub Codespace remote servers. How are we building today?",
      thought: "Initial handshake successfully completed. Prepared to monitor workspace actions.",
      timestamp: new Date().toLocaleTimeString(),
    }
  ]);
  const [aiTyping, setAiTyping] = useState(false);
  const [promptValue, setPromptValue] = useState("");
  const [aiMode, setAiMode] = useState<"chat" | "agent">("agent");
  const [cmdKActive, setCmdKActive] = useState(false);

  // ----------------- Laptop Tunnel Specific States -----------------
  const [tunnelSubTab, setTunnelSubTab] = useState<"laptop" | "github">("laptop");
  const [laptopTunnelActive, setLaptopTunnelActive] = useState<boolean>(true);
  const [laptopTunnelToken, setLaptopTunnelToken] = useState<string>("8f22e-cf891-62a22-4fe1b");
  const [isDraggingOverTunnel, setIsDraggingOverTunnel] = useState<boolean>(false);
  const [showSimulatedImportModal, setShowSimulatedImportModal] = useState<boolean>(false);
  const [importSimulatedName, setImportSimulatedName] = useState<string>("src/MyLocalApp.tsx");
  const [importSimulatedContent, setImportSimulatedContent] = useState<string>(`// Simulated import from VS Code local workspace.

export default function MyLocalApp() {
  return (
    <div className="p-4 bg-slate-900 border border-slate-800 text-white rounded">
      <h3 className="text-sm font-bold text-cyan-400">Synced Element Container</h3>
      <p className="text-xs text-gray-400">This component was synced directly from a connected remote laptop workspace via the secure Windsurf bridge.</p>
    </div>
  );
}`);
  const [laptopWorkspacePath, setLaptopWorkspacePath] = useState<string>("/Users/admin/Projects/windsurf-desktop");
  const [laptopOS, setLaptopOS] = useState<string>("OSX Darwin (macOS Sequoia) arm64");
  const [laptopLocalUrl, setLaptopLocalUrl] = useState<string>("http://localhost:3000");
  const [laptopCpuLoad, setLaptopCpuLoad] = useState<number>(12);
  const [laptopMemUsed, setLaptopMemUsed] = useState<string>("5.4 GB / 16.0 GB (33%)");
  const [laptopSyncLogs, setLaptopSyncLogs] = useState<Array<{ time: string; log: string; type: "info" | "success" | "warning" }>>([
    { time: "05:07", log: "🔌 Websocket tunnel listening safely on laptop", type: "info" },
    { time: "05:08", log: "💻 Handshake completed, linked with MacBook Pro", type: "success" }
  ]);

  // ----------------- Android ADB & WebUSB Device States -----------------
  const [androidSubTab, setAndroidSubTab] = useState<"bridge" | "addons" | "x11" | "compliance">("bridge");
  const [adbConnected, setAdbConnected] = useState<boolean>(true);
  const [connectedDevice, setConnectedDevice] = useState<{
    name: string;
    serial: string;
    battery: number;
    osVersion: string;
    rooted: boolean;
    shizukuActive: boolean;
    suiActive: boolean;
    x11Active: boolean;
  } | null>({
    name: "Redmi Note 12 Pro (Android Wifi)",
    serial: "8f22e-adb-5555",
    battery: 94,
    osVersion: "Android 14 (U, SDK 34)",
    rooted: true,
    shizukuActive: true,
    suiActive: true,
    x11Active: true
  });
  
  const [wifiIp, setWifiIp] = useState<string>("192.168.1.104");
  const [wifiPort, setWifiPort] = useState<string>("5555");
  
  // Termux-API Add-on controller triggers
  const [termuxClipboard, setTermuxClipboard] = useState<string>("Synced IDE Layout Matrix");
  const [termuxBatteryHistory, setTermuxBatteryHistory] = useState<Array<{ time: string; level: number }>>([
    { time: "05:00", level: 95 },
    { time: "05:10", level: 94 },
    { time: "05:20", level: 94 },
    { time: "05:30", level: 93 }
  ]);
  const [photoPayload, setPhotoPayload] = useState<string>(""); 
  
  // X11 Visual Display states
  const [x11Resolution, setX11Resolution] = useState<string>("1280x720");
  const [x11DesktopEnv, setX11DesktopEnv] = useState<"xfce" | "i3" | "gnome">("xfce");
  const [x11ConsoleLog, setX11ConsoleLog] = useState<string[]>([
    "[x11] Spawning Xorg server on Android layout...",
    "[x11] Bound virtual socket :0 on local frame buffer 6000",
    "[x11] Android Window Manager surface link active",
    "[x11] Running core desktop suite: Thunar, xfce4-panel, xterm"
  ]);
  const [activeWindow, setActiveWindow] = useState<string>("Termux X11 Desktop");

  // ----------------- Shizuku & Sui states synced -----------------
  const [termuxShizukuActiveState, setTermuxShizukuActiveState] = useState<boolean>(true);
  const [termuxRishActiveState, setTermuxRishActiveState] = useState<boolean>(false);

  // ----------------- GitHub Repository & Actions States -----------------
  const [githubReposList, setGithubReposList] = useState<Array<{ name: string; url: string; branches: string[]; active: boolean }>>([
    { name: "android_kernel_xiaomi_sm8250", url: "https://github.com/slm91/android_kernel_xiaomi_sm8250", branches: ["inline-clang-17", "main", "stable-v4"], active: true },
    { name: "termux-app-custom-build", url: "https://github.com/slm91/termux-app-custom-build", branches: ["shizuku-api", "master"], active: false },
    { name: "slm-custom-rom-manifests", url: "https://github.com/slm91/slm-custom-rom-manifests", branches: ["lineage-21.0", "rising-os"], active: false }
  ]);
  const [newRepoUrl, setNewRepoUrl] = useState<string>("");
  const [selectedRepo, setSelectedRepo] = useState<string>("android_kernel_xiaomi_sm8250");
  const [currentBranchRepo, setCurrentBranchRepo] = useState<string>("inline-clang-17");
  const [cloningStatus, setCloningStatus] = useState<string>("idle"); // idle, cloning, finished
  
  // GitHub Actions and compiler profiles
  const [workflowRunning, setWorkflowRunning] = useState<boolean>(false);
  const [workflowStepIndex, setWorkflowStepIndex] = useState<number>(-1);
  const [workflowSteps, setWorkflowSteps] = useState<Array<{ name: string; status: "idle" | "running" | "success" | "failed"; duration?: string; logs: string[] }>>([
    { 
      name: "Initialize runner & compiler dependencies", 
      status: "idle", 
      logs: [
        "Preparing compiler environment on GitHub hosted runner (Ubuntu-22.04 LTS)...",
        "Setting up toolchain references for building Android Kernel...",
        "Virtual architecture selected: aarch64 core profiles."
      ] 
    },
    { 
      name: "Checkout Upstream & GCC/Clang Toolchains", 
      status: "idle", 
      logs: [
        "git clone --recursive https://github.com/slm91/android_kernel_xiaomi_sm8250.git kernel",
        "Cloning compiler payload: AOSP Clang toolchain version 17.0.4...",
        "Cloning prebuilt GCC toolchains for arm/arm64 submodules..."
      ] 
    },
    { 
      name: "Setup Defconfig Config & Optimizations", 
      status: "idle", 
      logs: [
        "export ARCH=arm64 && export SUBARCH=arm64",
        "make xiaomi_sm8250_defconfig",
        "Validating Kernel configuration overrides inside .config...",
        "KPROBES and SHIZUKU-BINDER-TUNNEL variables activated."
      ] 
    },
    { 
      name: "Execute Clang-17 Android Kernel Compilation", 
      status: "idle", 
      logs: [
        "make -j$(nproc) CC=clang CLANG_TRIPLE=aarch64-linux-gnu- CROSS_COMPILE=aarch64-linux-android-",
        "Compiling core subsystems: arch/arm64/kernel/head.o...",
        "Compiling drivers/android/shizuku_binder.c...",
        "Linking target kernel payload structure...",
        "Kernel zImage-dtb successfully built. File size: 14.82 MB."
      ] 
    },
    { 
      name: "Generate Flashable Boot/Recovery/ROM Artifacts", 
      status: "idle", 
      logs: [
        "Integrating kernel into standard AnyKernel3 packaging overlay...",
        "Creating custom ROM recovery install payload (recovery.img)...",
        "Signing flashable ZIP image with secure MD5 digests..."
      ] 
    }
  ]);

  // References
  const terminalBottomRef = useRef<HTMLDivElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // 1. Initialize WebSocket Connection
  useEffect(() => {
    try {
      setConnectionStatus("connecting");
      const isHttps = window.location.protocol === "https:";
      const wsProtocol = isHttps ? "wss:" : "ws:";
      const wsUrl = `${wsProtocol}//${window.location.host}`;
      
      const ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        setConnectionStatus("connected");
        // Handshake initialized
        setSocket(ws);
      };

      ws.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          
          switch (payload.type) {
            case "sync-state": {
              const { clientInfo, workspace } = payload;
              setMe(clientInfo);
              setFiles(workspace.files);
              setActiveTemplateId(workspace.templateId);
              setGitState(workspace.gitState);
              setTerminalHistory(workspace.terminalCommands);
              setCollaborators(workspace.activeUsers);

              // Select first file if tabs exist
              if (workspace.files.length > 0) {
                const first = workspace.files[0];
                const matchedTabId = first.path.replace(/\//g, "-").replace(/\./g, "-");
                setCurrentFileId(matchedTabId);
              }
              break;
            }

            case "user-joined": {
              const newUser = payload.user;
              setCollaborators(prev => ({ ...prev, [newUser.id]: newUser }));
              appendSystemLog(`Collaboration: Guest '${newUser.name}' entered workspace via secure dev tunnel.`);
              break;
            }

            case "user-left": {
              const id = payload.clientId;
              setCollaborators(prev => {
                const updated = { ...prev };
                delete updated[id];
                return updated;
              });
              break;
            }

            case "cursor-updated": {
              const { clientId, cursor, user } = payload;
              setCollaborators(prev => ({
                ...prev,
                [clientId]: {
                  ...prev[clientId],
                  cursor,
                  name: user.name,
                  color: user.color
                }
              }));
              break;
            }

            case "file-updated": {
              const { path, content, senderId } = payload;
              setFiles(prev => prev.map(f => f.path === path ? { ...f, content } : f));
              // Log minor terminal tip
              break;
            }

            case "file-added": {
              const { file } = payload;
              setFiles(prev => {
                const copy = prev.filter(f => f.path !== file.path);
                return [...copy, file];
              });
              break;
            }

            case "file-deleted": {
              const { path } = payload;
              setFiles(prev => prev.filter(f => f.path !== path));
              break;
            }

            case "template-changed": {
              const { templateId, files: tFiles, gitState: tGit, terminalCommands: tCmds } = payload;
              setActiveTemplateId(templateId);
              setFiles(tFiles);
              setGitState(tGit);
              setTerminalHistory(tCmds);
              break;
            }

            case "terminal-result": {
              const { command, gitState: updatedGit, termuxPackages: remotePkgs, termuxRoot: remoteRoot, termuxStorage: remoteStorage, termuxTheme: remoteTheme, termuxFont: remoteFont } = payload;
              setTerminalHistory(prev => [...prev, command]);
              
              // Synchronize backend states with client React states
              if (updatedGit) setGitState(updatedGit);
              if (remotePkgs !== undefined) setTermuxPackages(remotePkgs);
              if (remoteRoot !== undefined) setTermuxRoot(remoteRoot);
              if (remoteStorage !== undefined) setTermuxStorage(remoteStorage);
              if (remoteTheme !== undefined) setTermuxTheme(remoteTheme);
              if (remoteFont !== undefined) setTermuxFont(remoteFont);

              // Handle physical alerts and simulated triggers
              if (command && command.output) {
                if (command.output.includes("TERMUX_API:TOAST:")) {
                  const tMatch = command.output.match(/TERMUX_API:TOAST:([^\n]+)/);
                  if (tMatch && tMatch[1]) {
                    setTermuxToastMessage(tMatch[1]);
                    setTimeout(() => setTermuxToastMessage(""), 4500);
                  }
                }
                if (command.output.includes("TERMUX_API:VIBRATE:")) {
                  if (typeof navigator !== "undefined" && navigator.vibrate) {
                    const vMatch = command.output.match(/TERMUX_API:VIBRATE:(\d+)/);
                    const vDur = vMatch ? parseInt(vMatch[1], 10) : 300;
                    navigator.vibrate(vDur);
                  }
                  const termBox = document.getElementById("section-terminal");
                  if (termBox) {
                    termBox.classList.add("ring-2", "ring-emerald-500", "animate-pulse");
                    setTimeout(() => termBox.classList.remove("ring-2", "ring-emerald-500", "animate-pulse"), 800);
                  }
                }
              }
              break;
            }

            case "git-updated": {
              setGitState(payload.gitState);
              break;
            }
          }
        } catch (e) {
          // Silent parsing fallback
        }
      };

      ws.onclose = () => {
        setConnectionStatus("disconnected");
        setSocket(null);
      };

      ws.onerror = () => {
        setConnectionStatus("disconnected");
        setSocket(null);
      };

      return () => {
        ws.close();
      };
    } catch (err) {
      setConnectionStatus("disconnected");
    }
  }, []);

  // ----------------- Fallback / Simulation engine when alone or offline -----------------
  // Spawns mock guest activities to demonstrate rich dual-curser collaboration immediately
  useEffect(() => {
    if (files.length === 0) {
      // Load fallback react dashboard as starter if not synchronized yet
      const fallbackTemplate = templates[0];
      setFiles(fallbackTemplate.files);
      setActiveTemplateId(fallbackTemplate.id);
      
      // Seed fallback terminal entries
      setTerminalHistory([
        {
          id: "sys-boot",
          input: "codespace --diagnostic",
          output: "✔ Local Workspace environment active on Port 3000.\n✔ Remote Git credentials mapping configured.\nType 'help' in terminal below for simulated shell instruction matrix.",
          directory: "~",
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    }

    // Synthetic guest updates interval
    const guestLoop = setInterval(() => {
      // Randomly update a mock guest's cursor location to show gorgeous coordinate bubbles live
      const names = ["Space Operator", "Cyberscript Coder", "Quantum Architect", "Delta Pilot"];
      const colors = ["#A3E635", "#F43F5E", "#FB923C", "#8B5CF6"];
      
      const randomIdx = Math.floor(Math.random() * names.length);
      const guestId = `mock_guest_${randomIdx}`;

      const randomLine = Math.floor(Math.random() * 15) + 1;
      const randomCh = Math.floor(Math.random() * 40) + 1;

      setCollaborators(prev => {
        const copy = { ...prev };
        copy[guestId] = {
          id: guestId,
          name: names[randomIdx],
          color: colors[randomIdx],
          cursor: {
            fileId: currentFileId,
            line: randomLine,
            ch: randomCh
          }
        };
        return copy;
      });
    }, 8500);

    return () => clearInterval(guestLoop);
  }, [currentFileId, files]);

  // Handle hotkeys
  useEffect(() => {
    const handleKeys = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setCmdKActive(true);
      }
      if (e.key === "Escape") {
        setCmdKActive(false);
      }
    };
    window.addEventListener("keydown", handleKeys);
    return () => window.removeEventListener("keydown", handleKeys);
  }, []);

  // Auto scroll down console logs
  useEffect(() => {
    terminalBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [terminalHistory]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, aiTyping]);

  // Compute ghost suggestion dynamic placeholders
  const activeFile = files.find(f => f.id === currentFileId);
  useEffect(() => {
    if (activeFile) {
      const textVal = SUGGESTIONS[activeFile.path] || "";
      setEditorGhostSuggestion(textVal);
    } else {
      setEditorGhostSuggestion("");
    }
  }, [currentFileId, activeFile]);

  // ----------------- Core IDE Function Handlers -----------------

  const handleActiveFileChange = (newVal: string) => {
    if (!activeFile) return;
    setFiles(prev => prev.map(f => f.id === currentFileId ? { ...f, content: newVal } : f));

    // Propagate text changes over WebSockets if active
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: "update-file",
        path: activeFile.path,
        content: newVal
      }));
    }
  };

  const selectTab = (path: string) => {
    const matchedF = files.find(f => f.path === path);
    if (matchedF) {
      setCurrentFileId(matchedF.id);
      if (!tabs.includes(path)) {
        setTabs(prev => [...prev, path]);
      }
    }
  };

  const closeTab = (path: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const filtered = tabs.filter(t => t !== path);
    setTabs(filtered);
    if (activeFile?.path === path && filtered.length > 0) {
      const nextMatch = files.find(f => f.path === filtered[filtered.length - 1]);
      if (nextMatch) setCurrentFileId(nextMatch.id);
    }
  };

  const handleCreateFile = () => {
    if (!newFileNameInput.trim()) return;
    const cleanPath = newFileNameInput.trim();
    
    const doubleUpIdx = files.findIndex(f => f.path === cleanPath);
    if (doubleUpIdx !== -1) {
      appendSystemLog(`Error: Cannot create duplicate workspace index: ${cleanPath}`);
      return;
    }

    const newF: VirtualFile = {
      id: cleanPath.replace(/\//g, "-").replace(/\./g, "-"),
      path: cleanPath,
      content: `// Source code created dynamically in collaborative workspace.\n// Active file path: ${cleanPath}\n\n`,
      type: "file"
    };

    setFiles(prev => [...prev, newF]);
    setTabs(prev => [...prev, cleanPath]);
    setCurrentFileId(newF.id);
    setNewFileNameInput("");
    appendSystemLog(`Successfully created file context: ${cleanPath}`);

    // WebSocket send
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: "add-file",
        path: cleanPath,
        content: newF.content
      }));
    }
  };

  const handleDeleteFile = (pathToDelete: string) => {
    setFiles(prev => prev.filter(f => f.path !== pathToDelete));
    setTabs(prev => prev.filter(t => t !== pathToDelete));
    if (activeFile?.path === pathToDelete) {
      const leftOver = files.filter(f => f.path !== pathToDelete);
      if (leftOver.length > 0) {
        setCurrentFileId(leftOver[0].id);
      }
    }
    appendSystemLog(`System: Cleared workspace file indexing for: ${pathToDelete}`);

    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: "delete-file",
        path: pathToDelete
      }));
    }
  };

  // ----------------- Windsurf/VS Code Laptop Tunnel Event Handlers -----------------
  const handleTunnelFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDraggingOverTunnel(false);
    
    if (!laptopTunnelActive) {
      setTermuxToastMessage("⚠️ Sync failed: Laptop active tunnel is currently disabled!");
      return;
    }

    const droppedFiles = e.dataTransfer.files;
    if (droppedFiles.length === 0) return;

    const firstFile = droppedFiles[0];
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string || "";
      const cleanPath = firstFile.name;
      
      const newF: VirtualFile = {
        id: cleanPath.replace(/\//g, "-").replace(/\./g, "-"),
        path: cleanPath,
        content: text || `// Imported from laptop workspace.\n`,
        type: "file"
      };

      setFiles(prev => {
        const filtered = prev.filter(f => f.path !== cleanPath);
        return [...filtered, newF];
      });
      setTabs(prev => prev.includes(cleanPath) ? prev : [...prev, cleanPath]);
      setCurrentFileId(newF.id);
      
      const timeNow = new Date().toLocaleTimeString().substring(0, 5);
      setLaptopSyncLogs(prev => [
        { time: timeNow, log: `📥 Sycned file '${cleanPath}' directly from remote Laptop (${firstFile.size} B)`, type: "success" },
        ...prev
      ]);

      setTermuxToastMessage(`Synced laptop file: ${cleanPath}`);
      appendSystemLog(`[Tunnel Sync]: Ingested file '${cleanPath}' from connected laptop.`);

      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({
          type: "add-file",
          path: cleanPath,
          content: newF.content
        }));
      }
    };
    reader.readAsText(firstFile);
  };

  const handleSimulatedImportAndSync = () => {
    if (!importSimulatedName.trim()) return;
    if (!laptopTunnelActive) {
      setTermuxToastMessage("⚠️ Sync failed: Enable Laptop Tunnel!");
      return;
    }

    const cleanPath = importSimulatedName.trim();
    const newF: VirtualFile = {
      id: cleanPath.replace(/\//g, "-").replace(/\./g, "-"),
      path: cleanPath,
      content: importSimulatedContent,
      type: "file"
    };

    setFiles(prev => {
      const filtered = prev.filter(f => f.path !== cleanPath);
      return [...filtered, newF];
    });
    setTabs(prev => prev.includes(cleanPath) ? prev : [...prev, cleanPath]);
    setCurrentFileId(newF.id);

    const timeNow = new Date().toLocaleTimeString().substring(0, 5);
    setLaptopSyncLogs(prev => [
      { time: timeNow, log: `💻 Imported laptop module '${cleanPath}' successfully`, type: "success" },
      ...prev
    ]);

    setTermuxToastMessage(`Synced laptop file: ${cleanPath}`);
    appendSystemLog(`[Simulated Laptop Link]: Synced ${cleanPath} from Developer-Laptop-Pro.`);
    setShowSimulatedImportModal(false);

    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: "add-file",
        path: cleanPath,
        content: newF.content
      }));
    }
  };

  const handleForceFetchRemoteStats = () => {
    if (!laptopTunnelActive) {
      setTermuxToastMessage("❌ Failed: Laptop Tunnel is offline!");
      return;
    }
    
    setLaptopCpuLoad(85);
    setTermuxToastMessage("🔄 Fetching Workspace metrics from Laptop...");
    
    setTimeout(() => {
      setLaptopCpuLoad(Math.floor(Math.random() * 20) + 10);
      const timeNow = new Date().toLocaleTimeString().substring(0, 5);
      setLaptopSyncLogs(prev => [
        { time: timeNow, log: "🪵 Dynamic background sync: Laptop git workspace active check completed", type: "info" },
        { time: timeNow, log: "ℹ️ Laptop remote environment changes parsed without conflicts", type: "success" },
        ...prev
      ]);
      setTermuxToastMessage("✅ Laptop workspace fully synchronized!");
    }, 1200);
  };

  const handleTemplateSelection = (tid: string) => {
    const selected = templates.find(t => t.id === tid);
    if (!selected) return;

    setActiveTemplateId(tid);
    setFiles(selected.files);
    setTabs(selected.defaultOpenFiles);
    
    const matchedF = selected.files.find(f => f.path === selected.defaultOpenFiles[0]);
    if (matchedF) {
      setCurrentFileId(matchedF.id);
    }

    // Push state socket update
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: "change-template",
        templateId: tid,
        files: selected.files
      }));
    } else {
      setTerminalHistory([{
        id: "l-seed",
        input: `codespace --switch-theme : ${tid}`,
        output: `Changed active environment to ${selected.name}.\nLocal Sandbox reload success without websocket cloud hook.`,
        directory: "~",
        timestamp: new Date().toLocaleTimeString()
      }]);
    }
  };

  // ----------------- Github Credentials SSO Mock Login -----------------
  const handleSimulateGithubLogin = () => {
    if (!temporaryGithubToken.trim() && temporaryGithubToken.length < 3) {
      appendSystemLog("Error: Specify a simulated access token or username to authenticate.");
      return;
    }
    const derivedUser = temporaryGithubToken.includes("@") 
      ? temporaryGithubToken.split("@")[0] 
      : temporaryGithubToken;

    setGithubUser({
      loggedIn: true,
      username: derivedUser,
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${derivedUser}`,
      reposCount: 42,
      codespaceActive: true,
      codespaceServer: "github",
      pingTime: 124 // simulated runner latency ms
    });
    setShowLoginModal(false);
    appendSystemLog(`SSO: Successfully logged in to GitHub server container as user '${derivedUser}'.`);
    
    // Auto shift terminal target to github dev host compiler
    setTerminalHistory(prev => [...prev, {
      id: "gh-conn",
      input: "github-codespaces initialize --active",
      output: `Connecting server pipeline securely as ${derivedUser}...\n✔ GitHub access verification approved (OAuth callback)\n✔ Cloud dev workspace initialized successfully\n✔ Compilation Remote Host target shifted to: GitHub Codespace (Runner-2C/4GB)\nLatency: 124ms`,
      directory: "~",
      timestamp: new Date().toLocaleTimeString()
    }]);
  };

  const handleLogoutGithub = () => {
    setGithubUser(prev => ({
      ...prev,
      loggedIn: false,
      codespaceActive: false,
      codespaceServer: "local"
    }));
    appendSystemLog("SSO Session terminated: Swapped back to client browser compilation engine.");
  };

  const triggerWorkflowCompilation = () => {
    if (workflowRunning) return;
    setWorkflowRunning(true);
    setWorkflowStepIndex(0);
    setTermuxToastMessage("🚀 GitHub Actions runner triggered. Initializing virtual workflow container...");
    
    // Set all steps to idle first
    setWorkflowSteps(prev => prev.map(s => ({ ...s, status: "idle" })));
    
    // Staggered execution of Actions steps
    let currentStep = 0;
    
    const interval = setInterval(() => {
      setWorkflowSteps(prev => {
        const copy = [...prev];
        // Mark previous step as success
        if (currentStep > 0) {
          copy[currentStep - 1].status = "success";
          copy[currentStep - 1].duration = `${Math.floor(Math.random() * 8) + 12}s`;
        }
        // Mark current as running
        if (currentStep < copy.length) {
          copy[currentStep].status = "running";
          setWorkflowStepIndex(currentStep);
          setTermuxToastMessage(`🏃 Active Pipeline Step: ${copy[currentStep].name}`);
        }
        return copy;
      });

      // Write logs to backend console so user also sees it in actual termux or background logs too!
      if (currentStep < workflowSteps.length) {
        const activeLogs = workflowSteps[currentStep].logs;
        activeLogs.forEach(logLine => {
          appendSystemLog(`[GitHub Runner]: ${logLine}`);
        });
      }

      currentStep++;
      if (currentStep > workflowSteps.length) {
        clearInterval(interval);
        setWorkflowSteps(prev => {
          const copy = [...prev];
          copy[copy.length - 1].status = "success";
          copy[copy.length - 1].duration = "18s";
          return copy;
        });
        setWorkflowRunning(false);
        setTermuxToastMessage("✅ Android target image compiled! ROM/Kernel flash ZIP artifacts ready for download.");
        appendSystemLog("[GitHub Actions SUCCESS]: Compiled AnyKernel3-sm8250-target.zip");
      }
    }, 4500);
  };

  // ----------------- Real-time Git Action Operations -----------------

  const runGitInit = () => {
    executeTerminalCommandOnBackend("git init");
  };

  const runGitAddAll = () => {
    executeTerminalCommandOnBackend("git add .");
  };

  const runGitCommit = (msg: string) => {
    if (!msg.trim()) return;
    executeTerminalCommandOnBackend(`git commit -m "${msg.trim()}"`);
    setCommitMessage("");
  };

  const runBranchCreate = () => {
    if (!newBranchName.trim()) return;
    executeTerminalCommandOnBackend(`git branch ${newBranchName.trim()}`);
    setNewBranchName("");
  };

  const handleBranchSwitch = (bname: string) => {
    executeTerminalCommandOnBackend(`git checkout ${bname}`);
  };

  const handleBranchMerge = (bname: string) => {
    executeTerminalCommandOnBackend(`git merge ${bname}`);
    setTerminalActiveTab("terminal");
  };

  const handleGitPush = () => {
    executeTerminalCommandOnBackend("git push");
  };

  const handleGitPull = () => {
    executeTerminalCommandOnBackend("git pull");
  };

  // Conflict Resolution Action triggers
  const resolveConflictState = (choice: "current" | "incoming") => {
    if (!activeFile) return;
    const text = activeFile.content;
    const startIdx = text.indexOf("<<<<<<< HEAD");
    const midIdx = text.indexOf("=======");
    const endIdx = text.indexOf(">>>>>>> ");

    if (startIdx === -1 || midIdx === -1 || endIdx === -1) {
      appendSystemLog("Indicator error: No conflict markers detected inside the open file viewport.");
      return;
    }

    const incomingEnd = text.indexOf("\n", endIdx);
    const resolvedText = choice === "current"
      ? text.substring(0, startIdx) + text.substring(startIdx + text.indexOf("\n", startIdx) + 1, midIdx) + text.substring(incomingEnd === -1 ? text.length : incomingEnd + 1)
      : text.substring(0, startIdx) + text.substring(midIdx + 8, endIdx) + text.substring(incomingEnd === -1 ? text.length : incomingEnd + 1);

    handleActiveFileChange(resolvedText);
    appendSystemLog(`[Git Resolver]: Conflict resolved successfully using choice '${choice.toUpperCase()}'. Added to pending changes.`);
  };

  // ----------------- Terminal Shell Input Actions -----------------

  const handleTerminalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!terminalInput.trim()) return;
    executeTerminalCommandOnBackend(terminalInput);
    setTerminalInput("");
  };

  const executeTerminalCommandOnBackend = (cmd: string) => {
    const rawCmd = cmd.trim();
    if (rawCmd === "clear") {
      setTerminalHistory([]);
      return;
    }

    // Trigger terminal websocket event or simulation logic on server
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: "terminal-command",
        input: rawCmd
      }));
    } else {
      // Simulate local command calculations when offline
      const output = simulateLocalCLI(rawCmd);
      const outputCmd: TerminalCommand = {
        id: Math.random().toString(36),
        input: rawCmd,
        output,
        directory: gitState.isInitialized ? `~/${activeTemplateId} (${gitState.currentBranch})` : `~/${activeTemplateId}`,
        timestamp: new Date().toLocaleTimeString()
      };
      setTerminalHistory(prev => [...prev, outputCmd]);
    }
  };

  // Secondary backup simulator
  const simulateLocalCLI = (input: string): string => {
    const parts = input.trim().split(/\s+/);
    const head = parts[0].toLowerCase();
    
    if (head === "git" && parts[1] === "init") {
      setGitState(prev => ({
        ...prev,
        isInitialized: true,
        currentBranch: "main",
        branches: ["main"]
      }));
      return "Initialized empty collaborative Git repository statically context.";
    }

    if (head === "npm" && parts[1] === "run" && parts[2] === "build") {
      return "> compiling assets\n✔ Done. Sandbox simulated production ready!";
    }

    if (head === "su") {
      setTermuxRoot(prev => !prev);
      return `[Client Offline Sandbox User Elevate Request]\nPrivilege changed. User status updated on screen.`;
    }

    if (head === "pkg") {
      const sub = parts[1]?.toLowerCase();
      if (sub === "install" && parts[2]) {
        const pStr = parts[2].toLowerCase();
        setTermuxPackages(prev => prev.includes(pStr) ? prev : [...prev, pStr]);
        return `[Client Offline Install]: Staged, compiled and successfully unpacked package '${pStr}'.`;
      }
      return `Local simulated packages: ${termuxPackages.join(", ")}`;
    }

    if (head === "termux-setup-storage") {
      setTermuxStorage(true);
      return "Local workspace folders cloned and linked to active SDCard namespace.";
    }

    if (head === "termux-styling") {
      const sub = parts[1]?.toLowerCase();
      const val = parts[2]?.toLowerCase();
      if (sub === "theme" && val) {
        setTermuxTheme(val);
        return `Layout theme updated locally to: ${val}`;
      }
    }

    return `Simulated command completed locally: ${input}\nStatus: offline connection fallback approved successfully.`;
  };

  const appendSystemLog = (text: string) => {
    setTerminalHistory(prev => [
      ...prev,
      {
        id: Math.random().toString(),
        input: "system-event",
        output: text,
        directory: "~",
        timestamp: new Date().toLocaleTimeString()
      }
    ]);
  };

  // ----------------- Cascade Flow AI Generation Proxy -----------------

  const triggerCascadeQuery = async (userPrompt: string) => {
    if (!userPrompt.trim()) return;
    
    const userMsg: CascadeMessage = {
      id: Math.random().toString(),
      role: "user",
      text: userPrompt.trim(),
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMsg]);
    setPromptValue("");
    setAiTyping(true);

    try {
      const response = await fetch("/api/cascade/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg],
          files,
          commandHistory: terminalHistory,
          currentFile: activeFile?.path || "None",
          mode: aiMode
        })
      });

      if (!response.ok) {
        throw new Error("Gemini server is initializing or API key is inactive.");
      }

      const rawData = await response.json();
      
      const assistantMsg: CascadeMessage = {
        id: Math.random().toString(),
        role: "assistant",
        text: rawData.explanation || "I analyzed your request and workspace setup. Let's inspect the files or run a terminal check to continue.",
        thought: rawData.thought,
        actions: rawData.actions?.map((act: any) => ({
          ...act,
          id: Math.random().toString(),
          status: "pending"
        })),
        timestamp: new Date().toLocaleTimeString()
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      // Elegant, styled fallback responses mimicking high intelligence if Gemini server is undergoing build refresh
      setMessages(prev => [
        ...prev,
        {
          id: Math.random().toString(),
          role: "assistant",
          text: `I've analyzed your project directory setup. Based on the files present (${files.map(f => f.path).join(", ")}), here are suggestions to enhance structural execution:\n\n1. Run **'git status'** inside the side panel to review modifications pending staging.\n2. Execute **'npm run build'** to bundle files into the local live canvas engine.\n3. Make modifications to **'app.js'** or toggle between dashboard presets. I can assist with writing functions, establishing types, or generating components whenever requested.`,
          thought: "Virtual fallback active following backend API transition. Ensuring zero UI interruptions.",
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    } finally {
      setAiTyping(false);
    }
  };

  // Run AI action step (edit file, generate file, run command, trigger preview)
  const handleExecuteAiAction = (msgId: string, actionId: string) => {
    // Locate the action
    const msgIdx = messages.findIndex(m => m.id === msgId);
    if (msgIdx === -1) return;
    const msg = { ...messages[msgIdx] };
    if (!msg.actions) return;
    const actIdx = msg.actions.findIndex(a => a.id === actionId);
    if (actIdx === -1) return;
    const act = { ...msg.actions[actIdx] };

    act.status = "running";
    msg.actions[actIdx] = act;
    setMessages(prev => prev.map(m => m.id === msgId ? msg : m));

    setTimeout(() => {
      try {
        if (act.type === "create_file" && act.path) {
          const freshFile: VirtualFile = {
            id: act.path.replace(/\//g, "-").replace(/\./g, "-"),
            path: act.path,
            content: act.content || "",
            type: "file"
          };
          setFiles(prev => {
            const temp = prev.filter(f => f.path !== act.path);
            return [...temp, freshFile];
          });
          setTabs(prev => prev.includes(act.path!) ? prev : [...prev, act.path!]);
          setCurrentFileId(freshFile.id);
          appendSystemLog(`[Cascade AI Action] Overwrote code file: ${act.path}`);
        } else if (act.type === "edit_file" && act.path && act.targetLines && act.replacementLines) {
          const fObj = files.find(f => f.path === act.path);
          if (fObj && fObj.content.includes(act.targetLines)) {
            const newContent = fObj.content.replace(act.targetLines, act.replacementLines);
            setFiles(prev => prev.map(f => f.path === act.path ? { ...f, content: newContent } : f));
            appendSystemLog(`[Cascade AI Action] Modified code blocks within: ${act.path}`);
          } else {
            throw new Error(`Lines match mismatch. Expected exact target string in '${act.path}' file.`);
          }
        } else if (act.type === "run_command" && act.command) {
          executeTerminalCommandOnBackend(act.command);
          setTerminalActiveTab("terminal");
        } else if (act.type === "show_preview") {
          setTerminalActiveTab("preview");
        }

        act.status = "success";
      } catch (e: any) {
        act.status = "failed";
        appendSystemLog(`[Cascade Error]: AI Action failed: ${e.message}`);
      } finally {
        msg.actions[actIdx] = act;
        setMessages(prev => prev.map(m => m.id === msgId ? msg : m));
      }
    }, 1500);
  };

  const handleGhostAccept = () => {
    if (activeFile && editorGhostSuggestion) {
      const updated = activeFile.content + "\n" + editorGhostSuggestion;
      handleActiveFileChange(updated);
      setEditorGhostSuggestion("");
      appendSystemLog(`[Autocomplete]: Automatically accepted inline code ghost completion.`);
    }
  };

  const getThemeClasses = () => {
    switch (termuxTheme) {
      case "monokai":
        return {
          bg: "bg-[#272822]",
          text: "text-[#f8f8f2]",
          prompt: "text-[#a6e22e]",
          border: "border-[#a6e22e]/30",
          output: "text-[#e6db74]"
        };
      case "solarized":
        return {
          bg: "bg-[#002b36]",
          text: "text-[#839496]",
          prompt: "text-[#268bd2]",
          border: "border-[#2aa198]/30",
          output: "text-[#b58900]"
        };
      case "nord":
        return {
          bg: "bg-[#2e3440]",
          text: "text-[#d8dee9]",
          prompt: "text-[#88c0d0]",
          border: "border-[#4c566a]/30",
          output: "text-[#a3be8c]"
        };
      case "retro-green":
        return {
          bg: "bg-[#040f04]",
          text: "text-[#33ff33]",
          prompt: "text-[#00ff00]",
          border: "border-[#00ff00]/40",
          output: "text-[#00ff00]"
        };
      case "cobalt":
        return {
          bg: "bg-[#002240]",
          text: "text-[#ffffff]",
          prompt: "text-[#ffc600]",
          border: "border-[#389ed7]/30",
          output: "text-[#9effff]"
        };
      case "matrix":
        return {
          bg: "bg-[#000000]",
          text: "text-[#00ff00]",
          prompt: "text-[#00fa0a]",
          border: "border-[#00ff00]/50",
          output: "text-[#00ee00]"
        };
      case "dracula":
      default:
        return {
          bg: "bg-[#181920]",
          text: "text-[#f8f8f2]",
          prompt: "text-[#50fa7b]",
          border: "border-[#bd93f9]/30",
          output: "text-[#8be9fd]"
        };
    }
  };

  const hasMergeConflict = activeFile?.content.includes("<<<<<<< HEAD") || false;

  return (
    <div className="flex h-screen w-full bg-[#090b0e] text-[#d1d5db] font-sans overflow-hidden">
      
      {/* 📱 Simulated Android Float Toast Pop-Up */}
      {termuxToastMessage && (
        <div key="termux-toast-overlay" className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-gray-950/95 border border-cyan-800/30 text-cyan-400 text-xs px-5 py-2.5 rounded-full shadow-[0_8px_30px_rgba(0,0,0,0.9)] z-50 flex items-center gap-2.5 backdrop-blur-md animate-bounce">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shrink-0"></span>
          <span className="font-mono text-[11px] font-bold tracking-tight text-white">📱 Termux Toast: {termuxToastMessage}</span>
        </div>
      )}

      {/* ----------------- Far Left Activity Bar ----------------- */}
      <nav id="col-activity-bar" className="w-14 bg-[#0e1116] border-r border-[#1a202c] flex flex-col items-center py-4 space-y-7 z-20">
        
        {/* Windsurf Core Logo Launcher with ripple rings */}
        <div 
          onClick={() => handleTemplateSelection(templates[0].id)}
          className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#00D1FF] to-[#0066FF] flex items-center justify-center cursor-pointer shadow-[0_0_15px_rgba(0,209,255,0.45)] hover:scale-105 transition-all"
          title="Zenith Windsurf Dashboard template reset"
        >
          <Code2 className="w-5 h-5 text-white animate-pulse" />
        </div>

        {/* Navigation Tab selection list */}
        <div className="flex flex-col space-y-5 flex-1 w-full items-center">
          <button
            onClick={() => setActiveLeftTab("explorer")}
            className={`p-2.5 rounded-lg transition-all relative group ${
              activeLeftTab === "explorer" ? "text-[#00D1FF] bg-[#1a202c]/50 border-l-2 border-[#00D1FF]" : "text-gray-400 hover:text-white"
            }`}
            title="Files Workspace Explorer"
          >
            <Folder className="w-5 h-5" />
            <span className="absolute left-16 bg-gray-900 border border-gray-800 text-xs px-2 py-1 rounded text-white tracking-wide opacity-0 group-hover:opacity-100 transition-opacity z-50 pointer-events-none whitespace-nowrap shadow-xl">
              File Explorer
            </span>
          </button>

          <button
            onClick={() => setActiveLeftTab("git")}
            className={`p-2.5 rounded-lg transition-all relative group ${
              activeLeftTab === "git" ? "text-[#00D1FF] bg-[#1a202c]/50 border-l-2 border-[#00D1FF]" : "text-gray-400 hover:text-white"
            }`}
            title="Git Version Control Management"
          >
            <GitBranch className="w-5 h-5" />
            {gitState.isInitialized && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
            )}
            <span className="absolute left-16 bg-gray-900 border border-gray-800 text-xs px-2 py-1 rounded text-white tracking-wide opacity-0 group-hover:opacity-100 transition-opacity z-50 pointer-events-none whitespace-nowrap shadow-xl">
              Git Controls
            </span>
          </button>

          <button
            onClick={() => setActiveLeftTab("codespaces")}
            className={`p-2.5 rounded-lg transition-all relative group ${
              activeLeftTab === "codespaces" ? "text-[#00D1FF] bg-[#1a202c]/50 border-l-2 border-[#00D1FF]" : "text-gray-400 hover:text-white"
            }`}
            title="GitHub Remote Compiler Integration"
          >
            <Github className="w-5 h-5" />
            {githubUser.loggedIn && (
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-green-400"></span>
            )}
            <span className="absolute left-16 bg-gray-900 border border-gray-800 text-xs px-2 py-1 rounded text-white tracking-wide opacity-0 group-hover:opacity-100 transition-opacity z-50 pointer-events-none whitespace-nowrap shadow-xl">
              GitHub Codespaces
            </span>
          </button>

          <button
            onClick={() => setActiveLeftTab("android")}
            className={`p-2.5 rounded-lg transition-all relative group ${
              activeLeftTab === "android" ? "text-emerald-400 bg-[#1a202c]/50 border-l-2 border-emerald-400" : "text-gray-400 hover:text-white"
            }`}
            title="Android ADB, Shizuku & Sui Workspace"
          >
            <Smartphone className="w-5 h-5" />
            {adbConnected && (
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            )}
            <span className="absolute left-16 bg-gray-900 border border-gray-800 text-xs px-2 py-1 rounded text-white tracking-wide opacity-0 group-hover:opacity-100 transition-opacity z-50 pointer-events-none whitespace-nowrap shadow-xl">
              Android Connect & Actions
            </span>
          </button>

          <button
            onClick={() => setActiveLeftTab("help")}
            className={`p-2.5 rounded-lg transition-all relative group ${
              activeLeftTab === "help" ? "text-[#00D1FF] bg-[#1a202c]/50 border-l-2 border-[#00D1FF]" : "text-gray-400 hover:text-white"
            }`}
            title="Windsurf Interactive Manual"
          >
            <HelpCircle className="w-5 h-5" />
            <span className="absolute left-16 bg-gray-900 border border-gray-800 text-xs px-2 py-1 rounded text-white tracking-wide opacity-0 group-hover:opacity-100 transition-opacity z-50 pointer-events-none whitespace-nowrap shadow-xl">
              CLI & Features Manual
            </span>
          </button>
        </div>

        {/* User status avatar / login credentials selector */}
        <div 
          onClick={() => {
            if (!githubUser.loggedIn) {
              setShowLoginModal(true);
            } else {
              setActiveLeftTab("codespaces");
            }
          }}
          className="mt-auto cursor-pointer flex flex-col items-center gap-1 group relative"
          title={githubUser.loggedIn ? `Logged in as ${githubUser.username}` : "Securely login with GitHub API account"}
        >
          {githubUser.loggedIn ? (
            <img 
              src={githubUser.avatarUrl} 
              alt="Avatar" 
              className="w-8 h-8 rounded-full border border-green-500 hover:scale-105 transition-transform" 
            />
          ) : (
            <div className="w-8 h-8 rounded-full bg-gray-800 border border-gray-700 flex items-center justify-center hover:border-blue-400 transition-colors">
              <User className="w-4 h-4 text-gray-400" />
            </div>
          )}
          <span className="text-[9px] text-gray-500 group-hover:text-cyan-400 transition-colors">SSO</span>
        </div>
      </nav>

      {/* ----------------- Explorer Side Drawer (Left sidebar) ----------------- */}
      <aside id="col-explorer" className="w-60 bg-[#12161a] border-r border-[#1a202c] flex flex-col z-10 shrink-0">
        
        {/* VIEW 1: Explorer Panel with Workspace files */}
        {activeLeftTab === "explorer" && (
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="p-4 border-b border-[#1f2633] flex justify-between items-center bg-[#0e1116]/80">
              <span className="text-[11px] font-bold text-gray-400 uppercase tracking-widest">
                Workspace Explorer
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/10 text-[#00D1FF] font-semibold">
                v1.4.2
              </span>
            </div>

            {/* Template Selector Widget (Simulating full workspace swaps) */}
            <div className="p-3 bg-[#161c24] border-b border-[#1f2633] space-y-2">
              <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block">
                Active Code Project Template
              </label>
              <div className="space-y-1">
                {templates.map(tpl => (
                  <button
                    key={tpl.id}
                    onClick={() => handleTemplateSelection(tpl.id)}
                    className={`w-full text-left p-2 rounded text-xs transition-all flex items-center justify-between border ${
                      activeTemplateId === tpl.id 
                        ? "bg-[#00D1FF]/5 text-white border-[#00D1FF]/40 font-medium"
                        : "bg-[#0e1116]/40 text-gray-400 border-transparent hover:bg-gray-800 hover:text-white"
                    }`}
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      {tpl.id === "react-dashboard" ? <LayoutDashboard className="w-3.5 h-3.5 text-cyan-400" /> :
                       tpl.id === "galaxy-gravity-sim" ? <Orbit className="w-3.5 h-3.5 text-indigo-400 animate-spin" style={{ animationDuration: '10s' }} /> :
                       <SquareTerminal className="w-3.5 h-3.5 text-rose-400" />}
                      <span className="truncate">{tpl.name}</span>
                    </div>
                    {activeTemplateId === tpl.id && (
                      <span className="w-1.5 h-1.5 rounded-full bg-[#00D1FF]"></span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Virtual File Index list structure */}
            <div className="flex-1 overflow-y-auto p-2.5 space-y-3">
              <div className="space-y-1">
                <div className="flex items-center justify-between text-gray-500 text-[10px] uppercase font-bold tracking-widest px-2 py-1">
                  <span>ROOT REPOSITORY</span>
                  <Folder className="w-3.5 h-3.5" />
                </div>
                
                {files.map(f => (
                  <div
                    key={f.id}
                    onClick={() => selectTab(f.path)}
                    className={`group flex items-center justify-between rounded px-2.5 py-1.5 text-xs font-mono cursor-pointer transition-all ${
                      currentFileId === f.id
                        ? "bg-[#1d2433] text-[#00D1FF] border-l-2 border-[#00D1FF]"
                        : "text-gray-400 hover:bg-gray-800 hover:text-white"
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <File className={`w-3.5 h-3.5 ${currentFileId === f.id ? "text-cyan-400" : "text-gray-500"}`} />
                      <span className="truncate">{f.path}</span>
                    </div>
                    
                    {/* Trash file action (prevent deleting critical preset nodes) */}
                    {files.length > 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteFile(f.path);
                        }}
                        className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-rose-950/40 text-rose-400 rounded transition-all"
                        title="Delete file from virtual workspace"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                ))}
              </div>

              {/* Advanced quick-scaffolder addition form */}
              <div className="pt-2 border-t border-[#1f2633] space-y-1.5">
                <input
                  type="text"
                  placeholder="Create file (e.g. style.css)..."
                  value={newFileNameInput}
                  onChange={(e) => setNewFileNameInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") handleCreateFile(); }}
                  className="w-full bg-[#0e1116] border border-[#212b3c] rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono transition-colors"
                />
                <button
                  onClick={handleCreateFile}
                  className="w-full bg-[#1e293b] hover:bg-cyan-500/10 hover:text-[#00D1FF] border border-[#2e3e52] text-gray-400 font-medium py-1.5 rounded text-xs transition-all flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" /> Scaffold File
                </button>
              </div>
            </div>

            {/* Sandbox host execution information */}
            <div className="p-4 border-t border-[#1f2633] bg-[#0e1116]/80 text-[10px] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-gray-500 uppercase font-black tracking-widest">Active Server Context</span>
                <span className={`px-1.5 py-0.5 rounded font-bold uppercase ${
                  githubUser.codespaceServer === "github" ? "bg-green-950 text-green-400" : "bg-cyan-950 text-cyan-400"
                }`}>
                  {githubUser.codespaceServer === "github" ? "GitHub Active" : "Local Runner"}
                </span>
              </div>
              <p className="text-gray-400 text-[10px] leading-relaxed">
                Source compilations run sandbox isolation targets over SSL WebSockets.
              </p>
            </div>
          </div>
        )}

        {/* VIEW 2: Visual Git Version Control Panel */}
        {activeLeftTab === "git" && (
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="p-4 border-b border-[#1f2633] flex justify-between items-center bg-[#0e1116]/80">
              <span className="text-[11px] font-bold text-gray-400 uppercase tracking-widest">
                Source Control (Git)
              </span>
              <span className="px-1.5 py-0.5 bg-yellow-500/10 text-yellow-400 font-mono text-[9px] rounded font-bold uppercase animate-pulse">
                Local Database
              </span>
            </div>

            <div className="flex-1 overflow-y-auto p-3.5 space-y-4">
              {!gitState.isInitialized ? (
                <div className="p-4 bg-[#161c24] border border-[#1f2633] rounded-xl text-center space-y-3 shadow-md">
                  <div className="w-8 h-8 rounded-full bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mx-auto text-cyan-400">
                    <GitBranch className="w-4 h-4 animate-spin" style={{ animationDuration: '4s' }} />
                  </div>
                  <h4 className="text-xs font-semibold text-white">Initialize Visual Repository</h4>
                  <p className="text-[10px] text-gray-400 leading-relaxed">
                    Track code updates, view inline replacement diffs, coordinate branch integrations, and test merge operations immediately.
                  </p>
                  <button
                    onClick={runGitInit}
                    className="w-full bg-[#00D1FF] hover:bg-cyan-400 text-black py-2 rounded-lg text-xs font-bold font-mono tracking-wider shadow-lg shadow-cyan-500/20"
                  >
                    git init --interactive
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Active Branch Indicators */}
                  <div className="bg-[#161c24] p-3 rounded-xl border border-[#1f2633] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">Active Branch</span>
                      <span className="text-[10px] text-cyan-400 bg-cyan-950/50 border border-cyan-500/20 px-1.5 py-0.5 rounded font-mono font-bold">
                        {gitState.currentBranch}
                      </span>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[9px] text-gray-500 uppercase tracking-wider block font-bold">Switch Branches</label>
                      <select
                        value={gitState.currentBranch}
                        onChange={(e) => handleBranchSwitch(e.target.value)}
                        className="w-full bg-[#0e1116] border border-[#212b3c] text-xs text-white p-1 px-1.5 rounded-md focus:outline-none"
                      >
                        {gitState.branches.map(b => (
                          <option key={b} value={b}>{b}</option>
                        ))}
                      </select>
                    </div>

                    {/* Branch spawning action */}
                    <div className="space-y-1.5 pt-2 border-t border-gray-800">
                      <label className="text-[9px] text-gray-500 uppercase tracking-wider block font-bold">Spawn New Branch</label>
                      <div className="flex gap-1.5">
                        <input
                          type="text"
                          placeholder="v2-feature-core..."
                          value={newBranchName}
                          onChange={(e) => setNewBranchName(e.target.value)}
                          className="flex-1 bg-[#0e1116] text-white border border-[#212b3c] rounded px-2 py-1 text-xs font-mono"
                        />
                        <button
                          onClick={runBranchCreate}
                          className="bg-indigo-600 hover:bg-indigo-500 p-1 rounded font-bold text-white transition-colors"
                          title="Create branch context"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Changes staging visual lists */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-[10px] font-bold text-gray-500 uppercase tracking-widest pl-1 border-b border-[#1f2633] pb-1">
                      <span>Status Tracking</span>
                      <span className="text-gray-400">Pending</span>
                    </div>

                    <div className="text-[11px] font-mono space-y-1">
                      <button
                        onClick={runGitAddAll}
                        className="w-full bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-400 border border-emerald-500/20 py-1 rounded text-[10px] font-bold mb-2 transition-all"
                      >
                        Stage modifications (git add .)
                      </button>

                      <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                        {/* List file pathways */}
                        {files.map(f => {
                          const isStaged = f.path in gitState.staged;
                          return (
                            <div key={f.id} className="flex items-center justify-between p-1.5 rounded bg-gray-900/40 border border-[#1a202c]">
                              <span className="truncate pr-2 text-gray-300">📄 {f.path}</span>
                              <div className="flex items-center gap-1.5">
                                <span className={`text-[9px] px-1 rounded-sm uppercase font-bold font-mono ${
                                  isStaged ? "bg-emerald-950 text-emerald-400" : "bg-red-950 text-red-400"
                                }`}>
                                  {isStaged ? "staged" : "altered"}
                                </span>
                                {!isStaged && (
                                  <button
                                    onClick={() => {
                                      setGitState(prev => {
                                        const copy = { ...prev };
                                        copy.staged[f.path] = f.content;
                                        return copy;
                                      });
                                    }}
                                    className="p-0.5 hover:bg-gray-800 rounded text-cyan-400"
                                    title="Stage file change"
                                  >
                                    +
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Branch Merging Tools */}
                  <div className="p-3 bg-slate-900 border border-indigo-900/30 rounded-xl space-y-1.5">
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                      <GitMerge className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                      <span>Interactive Merging</span>
                    </div>
                    <p className="text-[10px] text-gray-400">
                      Integrates target branch histories cleanly. Conflicts inject resolved buffers automatically!
                    </p>
                    <div className="flex gap-1.5 mt-2">
                      <select
                        value={selectedMergeBranch}
                        onChange={(e) => setSelectedMergeBranch(e.target.value)}
                        className="flex-1 bg-black text-xs text-white rounded p-1"
                      >
                        {gitState.branches.filter(b => b !== gitState.currentBranch).map(b => (
                          <option key={b} value={b}>{b}</option>
                        ))}
                      </select>
                      <button
                        onClick={() => handleBranchMerge(selectedMergeBranch)}
                        className="bg-indigo-600 hover:bg-indigo-500 text-xs text-white px-2 py-1 rounded font-bold transition-all"
                      >
                        Merge Branch
                      </button>
                    </div>
                  </div>

                  {/* Stash & Commit Actions Box */}
                  <div className="p-3 bg-[#161c24] border border-[#1f2633] rounded-xl space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block pb-1 border-b border-gray-800">
                      Commit Staged Area
                    </label>
                    <textarea
                      placeholder="Commit comment (e.g., feat: scaffold gravity engines)..."
                      value={commitMessage}
                      onChange={(e) => setCommitMessage(e.target.value)}
                      rows={2}
                      className="w-full bg-[#0a0d11] text-xs text-white p-2 rounded-lg border border-[#212b3c] focus:outline-none focus:border-cyan-400 resize-none font-mono"
                    />
                    <button
                      onClick={() => runGitCommit(commitMessage)}
                      className="w-full bg-cyan-500 hover:bg-cyan-400 text-black py-1.5 rounded text-xs font-bold font-mono tracking-wider"
                    >
                      git commit -m "..."
                    </button>
                  </div>

                  {/* Push & Pull Remote synchronization loops */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={handleGitPush}
                      className="bg-[#1e293b] hover:bg-cyan-500/10 hover:text-cyan-400 border border-[#2e3e52] py-1.5 rounded text-xs transition-colors flex items-center justify-center gap-1 font-semibold"
                    >
                      <GitCommit className="w-3.5 h-3.5" /> Push Code
                    </button>
                    <button
                      onClick={handleGitPull}
                      className="bg-[#1e293b] hover:bg-cyan-500/10 hover:text-cyan-400 border border-[#2e3e52] py-1.5 rounded text-xs transition-colors flex items-center justify-center gap-1 font-semibold"
                    >
                      <GitPullRequest className="w-3.5 h-3.5" /> Pull Remote
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* VIEW 3: GitHub login / Laptop Direct Tunnel integration */}
        {activeLeftTab === "codespaces" && (
          <div className="flex-1 flex flex-col overflow-hidden bg-[#12161a]">
            {/* Split controls at the top of the panel */}
            <div className="flex border-b border-[#1f2633] bg-[#0e1116]/80 text-[10px] select-none shrink-0 font-bold tracking-widest uppercase">
              <button
                onClick={() => setTunnelSubTab("laptop")}
                className={`flex-1 py-3 text-center border-b-2 transition-all flex items-center justify-center gap-1.5 ${
                  tunnelSubTab === "laptop" ? "border-[#00D1FF] text-[#00D1FF] bg-[#1a202c]/40" : "border-transparent text-gray-400 hover:text-white hover:bg-gray-900/40"
                }`}
                id="tab-laptop-tunnel"
              >
                <Laptop className="w-3.5 h-3.5" /> Laptop Tunnel
              </button>
              <button
                onClick={() => setTunnelSubTab("github")}
                className={`flex-1 py-3 text-center border-b-2 transition-all flex items-center justify-center gap-1.5 ${
                  tunnelSubTab === "github" ? "border-[#00D1FF] text-[#00D1FF] bg-[#1a202c]/40" : "border-transparent text-gray-400 hover:text-white hover:bg-gray-900/40"
                }`}
                id="tab-github-codespaces"
              >
                <Github className="w-3.5 h-3.5" /> GitHub Cloud
              </button>
            </div>

            {tunnelSubTab === "github" ? (
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                <div className="flex justify-between items-center bg-[#161c24] border border-[#1f2633] px-3.5 py-2 rounded-lg">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                    Cloud Compilation
                  </span>
                  <span className="px-1.5 bg-green-900/30 text-green-400 text-[9px] rounded font-mono font-bold">
                    ACTIVE STANDBY
                  </span>
                </div>

                {!githubUser.loggedIn ? (
                  <div className="p-4 bg-[#161c24] border border-[#1f2633] rounded-xl text-center space-y-3.5">
                    <div className="w-10 h-10 rounded-full bg-[#00D1FF]/10 border border-[#00D1FF]/20 flex items-center justify-center mx-auto text-[#00D1FF]">
                      <Github className="w-4 h-4 animate-pulse" />
                    </div>
                    <h4 className="text-xs font-bold text-white">OAuth Dev Integration</h4>
                    <p className="text-[10px] text-gray-400 leading-relaxed text-center">
                      By linking your GitHub credentials, compile files directly inside dedicated cloud runners (VCPU-2, RAM-4GB) simulating premium codespace servers.
                    </p>
                    
                    <div className="space-y-2">
                      <input
                        type="text"
                        placeholder="Enter GitHub Email/Username..."
                        value={temporaryGithubToken}
                        onChange={(e) => setTemporaryGithubToken(e.target.value)}
                        className="w-full bg-[#0a0d11] border border-[#212b3c] rounded px-3 py-1.5 text-xs text-white text-center focus:outline-none focus:border-cyan-400 font-mono"
                      />
                      
                      <button
                        onClick={handleSimulateGithubLogin}
                        className="w-full bg-[#00D1FF] hover:bg-cyan-400 text-black py-2 rounded-lg text-xs font-bold font-mono tracking-wider shadow-lg shadow-cyan-500/20"
                      >
                        Log In with GitHub Account
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* Account Overview Card */}
                    <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-4 space-y-3">
                      <div className="flex items-center gap-3">
                        <img src={githubUser.avatarUrl} alt="Avatar" className="w-10 h-10 rounded-full border border-green-500" />
                        <div>
                          <h4 className="text-sm font-bold text-white">{githubUser.username}</h4>
                          <p className="text-[10px] text-green-400 font-mono">Status: Connected to Upstream</p>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-gray-800 space-y-1 text-[11px] font-mono text-gray-400">
                        <div className="flex justify-between">
                          <span>Repositories API:</span>
                          <span className="text-white font-semibold">42 Online</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Remote Latency:</span>
                          <span className="text-white font-semibold">{githubUser.pingTime}ms</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Runner Host IP:</span>
                          <span className="text-cyan-400 font-bold">172.68.99.101</span>
                        </div>
                      </div>

                      <button
                        onClick={handleLogoutGithub}
                        className="w-full bg-rose-950/40 hover:bg-rose-950/70 text-rose-400 border border-rose-500/10 py-1.5 rounded text-xs font-bold transition-all"
                      >
                        Disconnect GitHub Account
                      </button>
                    </div>

                    {/* Repository Sourcing & Clone toolkit */}
                    <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-4 space-y-3">
                      <h5 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest pb-1 border-b border-gray-800">
                        📁 Git Repository & Branch Lookup
                      </h5>

                      <div className="space-y-2">
                        <div>
                          <label className="text-[9px] text-gray-400 font-bold block mb-1">Target Account Repository</label>
                          <select
                            value={selectedRepo}
                            onChange={(e) => {
                              setSelectedRepo(e.target.value);
                              const found = githubReposList.find(r => r.name === e.target.value);
                              if (found) setCurrentBranchRepo(found.branches[0]);
                            }}
                            className="w-full bg-[#0d1014] border border-gray-800 rounded px-2.5 py-1.5 text-xs text-cyan-300 font-mono focus:outline-none"
                          >
                            {githubReposList.map(r => (
                              <option key={r.name} value={r.name}>{r.name}</option>
                            ))}
                          </select>
                        </div>

                        <div className="flex gap-2">
                          <div className="flex-1">
                            <label className="text-[9px] text-gray-400 font-bold block mb-1">Active Branch</label>
                            <select
                              value={currentBranchRepo}
                              onChange={(e) => setCurrentBranchRepo(e.target.value)}
                              className="w-full bg-[#0d1014] border border-gray-800 rounded px-2.5 py-1.5 text-xs text-white uppercase font-mono focus:outline-none"
                            >
                              {githubReposList.find(r => r.name === selectedRepo)?.branches.map(b => (
                                <option key={b} value={b}>{b}</option>
                              )) || <option value="main">main</option>}
                            </select>
                          </div>
                        </div>

                        {/* Custom repo path adding input */}
                        <div className="space-y-1 pt-1">
                          <label className="text-[9px] text-gray-500 font-bold block">Integrate Upstream Repo URL</label>
                          <div className="flex gap-1.5">
                            <input
                              type="text"
                              placeholder="https://github.com/user/repo"
                              value={newRepoUrl}
                              onChange={(e) => setNewRepoUrl(e.target.value)}
                              className="flex-1 bg-[#0d1014] text-white border border-gray-800 rounded px-2 py-1 text-xs font-mono"
                            />
                            <button
                              onClick={() => {
                                if (!newRepoUrl) return;
                                const match = newRepoUrl.match(/github\.com\/([^\/]+)\/([^\/\s]+)/);
                                const name = match ? match[2].replace(".git", "") : "custom-android-src" + Math.floor(Math.random() * 100);
                                setGithubReposList(prev => [...prev, { name, url: newRepoUrl, branches: ["main", "stable"], active: false }]);
                                setSelectedRepo(name);
                                setNewRepoUrl("");
                                setTermuxToastMessage("✨ Registered upstream ROM/Kernel repository context!");
                              }}
                              className="bg-indigo-600 hover:bg-indigo-500 text-white px-2.5 rounded font-mono font-black text-xs"
                            >
                              ADD
                            </button>
                          </div>
                        </div>

                        {/* Cloner triggers */}
                        <button
                          onClick={() => {
                            if (cloningStatus === "cloning") return;
                            setCloningStatus("cloning");
                            setTermuxToastMessage("📥 Performing git clone --recursive of target sources...");
                            appendSystemLog(`[Git Clone]: Initiating recursive clone of https://github.com/slm91/${selectedRepo} into compile host...`);
                            
                            setTimeout(() => {
                              setCloningStatus("finished");
                              setTermuxToastMessage("✅ Repository cloned successfully!");
                              appendSystemLog(`[Git Clone Successful]: Checked out branch: ${currentBranchRepo}. Bound all compilation Makefiles.`);
                            }, 2500);
                          }}
                          className={`w-full py-2 rounded-lg text-xs font-bold uppercase transition-all tracking-wider text-center flex items-center justify-center gap-1.5 ${
                            cloningStatus === "cloning"
                              ? "bg-yellow-900 border border-yellow-600 text-yellow-400 cursor-not-allowed animate-pulse"
                              : cloningStatus === "finished"
                                ? "bg-emerald-950/40 border border-emerald-800 text-emerald-400"
                                : "bg-[#00D1FF] hover:bg-cyan-400 text-black font-black"
                          }`}
                        >
                          {cloningStatus === "cloning" ? "Cloning Git Payload..." : cloningStatus === "finished" ? "✓ Sources Cloned & Checked Out" : "📥 Clone Target to Workspace"}
                        </button>
                      </div>
                    </div>

                    {/* GitHub Actions active compiler engine */}
                    <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-4 space-y-3">
                      <div className="flex justify-between items-center pb-1 border-b border-gray-800">
                        <h5 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                          🛡️ GitHub Actions ROM/Kernel Builder
                        </h5>
                        <span className="text-[9px] font-sans text-orange-400 bg-orange-950/40 px-1 rounded animate-pulse">WF Enabled</span>
                      </div>

                      <div className="space-y-3">
                        {/* Active compiler profiles details */}
                        <div className="p-2.5 rounded bg-black/60 border border-gray-800 text-[10px] space-y-1">
                          <div className="flex justify-between">
                            <span className="text-gray-500">Target Type:</span>
                            <span className="text-cyan-400 font-bold font-mono">Kernel Config (AArch64)</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Toolchain Engine:</span>
                            <span className="text-emerald-400 font-mono">Clang 17.0.4 + LLVM linker</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Configuration:</span>
                            <span className="text-yellow-400 font-mono">xiaomi_sm8250_defconfig</span>
                          </div>
                        </div>

                        {/* Interactive trigger workflow script button */}
                        <button
                          onClick={triggerWorkflowCompilation}
                          disabled={workflowRunning}
                          className={`w-full py-2.5 rounded-lg text-xs font-bold font-mono tracking-wider flex items-center justify-center gap-1.5 transition-all text-center ${
                            workflowRunning 
                              ? "bg-[#1e1b4b] border border-[#4338ca] text-[#a5b4fc] cursor-not-allowed animate-pulse" 
                              : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20"
                          }`}
                        >
                          <Play className={`w-3.5 h-3.5 ${workflowRunning ? "animate-spin-slow" : ""}`} />
                          {workflowRunning ? "Running Pipeline Build..." : "🚀 Trigger GitHub Actions Build"}
                        </button>

                        {/* Steps active list */}
                        {workflowStepIndex >= 0 && (
                          <div className="space-y-2 border-t border-gray-800 pt-3">
                            <span className="text-[9px] text-gray-500 font-black uppercase tracking-wider block">Workflow Pipeline Steps</span>
                            <div className="space-y-1.5 font-mono text-[10px]">
                              {workflowSteps.map((step, idx) => (
                                <div key={idx} className="bg-[#0b0e14] border border-gray-800/40 rounded p-1.5 flex flex-col gap-1">
                                  <div className="flex justify-between items-center bg-[#07090d] px-1.5 py-1 rounded">
                                    <div className="flex items-center gap-1.5">
                                      {step.status === "success" && <span className="text-emerald-400">✅</span>}
                                      {step.status === "running" && <span className="text-cyan-400 animate-spin-slow">⏳</span>}
                                      {step.status === "idle" && <span className="text-gray-600">⚪</span>}
                                      <span className={step.status === "running" ? "text-cyan-300 font-bold" : step.status === "success" ? "text-gray-300" : "text-gray-500"}>
                                        {step.name}
                                      </span>
                                    </div>
                                    {step.duration && <span className="text-[9px] text-gray-500">{step.duration}</span>}
                                  </div>
                                  
                                  {step.status === "running" && (
                                    <div className="px-1.5 py-1 text-[8px] text-cyan-400 bg-black/50 rounded flex flex-col gap-0.5 max-h-24 overflow-y-auto" style={{ scrollbarWidth: "thin" }}>
                                      {step.logs.map((l, idy) => (
                                        <p key={idy} className="truncate select-all leading-tight">&gt; {l}</p>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Artifact compiled target download link */}
                        {workflowSteps[workflowSteps.length - 1].status === "success" && (
                          <div className="border border-emerald-500/20 bg-emerald-950/25 p-3 rounded-lg flex flex-col gap-2 mt-2 font-sans animate-fade-in">
                            <div className="flex items-center gap-2">
                              <span className="text-lg">🎁</span>
                              <div>
                                <h4 className="text-[11px] font-bold text-emerald-400 font-mono font-black">AnyKernel3-sm8250-stable.zip</h4>
                                <p className="text-[9px] text-gray-400">Kernel compiled with Link Time Optimizations (LTO)</p>
                              </div>
                            </div>
                            <button
                              onClick={() => setTermuxToastMessage("📥 Commencing browser download of compiled kernel ZIP binary target...")}
                              className="w-full py-1.5 bg-emerald-800 hover:bg-emerald-700 text-white rounded text-[10px] font-bold uppercase tracking-wide font-mono"
                            >
                              Download Target flashable.zip
                            </button>
                          </div>
                        )}

                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              /* LAPTOP TUNNEL SUB-TAB MAIN SCREEN */
              <div className="flex-1 flex flex-col overflow-hidden bg-[#12161a] p-4 space-y-4">
                
                {/* 1. Tunnel Connection Bridge Settings */}
                <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-4 space-y-3 relative overflow-hidden shrink-0">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span className={`w-2 h-2 rounded-full ${laptopTunnelActive ? "bg-emerald-400 animate-pulse" : "bg-orange-500"}`} />
                        Laptop Tunnel Link
                      </h4>
                      <p className="text-[9px] text-gray-400 font-mono mt-0.5">
                        {laptopTunnelActive ? "connected - forwarding port 3000" : "disconnected - offline"}
                      </p>
                    </div>
                    
                    <button
                      onClick={() => {
                        const nextState = !laptopTunnelActive;
                        setLaptopTunnelActive(nextState);
                        setTermuxToastMessage(nextState ? "🔌 Laptop workspace tunnel initialized!" : "🛑 Laptop workspace tunnel disabled!");
                        const timeNow = new Date().toLocaleTimeString().substring(0, 5);
                        setLaptopSyncLogs(prev => [
                          { 
                            time: timeNow, 
                            log: nextState ? "🟢 Established direct websocket workspace link" : "🔴 Tunnel disabled by WebIDE Client user", 
                            type: nextState ? "success" : "warning" 
                          },
                          ...prev
                        ]);
                      }}
                      className={`px-2.5 py-1 text-[10px] font-bold font-mono rounded transition-colors ${
                        laptopTunnelActive ? "bg-rose-950/50 hover:bg-rose-950 text-rose-400 border border-rose-500/20" : "bg-emerald-950/50 hover:bg-emerald-950 text-emerald-400 border border-emerald-500/20"
                      }`}
                    >
                      {laptopTunnelActive ? "Turn Off" : "Connect"}
                    </button>
                  </div>

                  {/* Token generator for copy/paste */}
                  <div className="bg-[#0b0e14]/90 p-2.5 rounded border border-gray-800 space-y-1.5">
                    <div className="flex justify-between items-center text-[9px] font-mono text-gray-400">
                      <span>RUN ON LAPTOP TERMINAL:</span>
                      <span className="text-emerald-400 font-semibold uppercase tracking-wider text-[8px]">Security Code</span>
                    </div>
                    <div className="flex gap-1.5">
                      <code className="text-[10px] select-all font-mono text-cyan-300 font-semibold bg-[#07090d] flex-1 px-2 py-1.5 rounded border border-gray-800/60 overflow-x-auto whitespace-nowrap">
                        windsurf-agent connect --token {laptopTunnelToken}
                      </code>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(`windsurf-agent connect --token ${laptopTunnelToken}`);
                          setTermuxToastMessage("Copied CLI Agent command!");
                        }}
                        className="p-1.5 bg-gray-800 hover:bg-cyan-500 text-gray-300 hover:text-black rounded transition-colors"
                        title="Copy command to clipboard"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* 2. Drag & Drop File Loader Zone */}
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDraggingOverTunnel(true);
                  }}
                  onDragLeave={() => setIsDraggingOverTunnel(false)}
                  onDrop={handleTunnelFileDrop}
                  className={`bg-[#161c24]/90 border border-dashed rounded-xl p-4 flex flex-col items-center justify-center text-center transition-all cursor-pointer select-none space-y-2 shrink-0 ${
                    isDraggingOverTunnel 
                      ? "border-[#00D1FF] bg-[#00D1FF]/5 scale-[0.98] ring-1 ring-[#00D1FF]/20" 
                      : "border-gray-800 hover:border-cyan-400/40"
                  }`}
                  onClick={() => setShowSimulatedImportModal(true)}
                  title="Simulate or dragging files from your laptop to instant compile!"
                >
                  <div className={`p-2 rounded-full transition-transform ${isDraggingOverTunnel ? "bg-[#00D1FF]/10 scale-110" : "bg-gray-800"}`}>
                    <Laptop className={`w-5 h-5 ${isDraggingOverTunnel ? "text-[#00D1FF]" : "text-gray-400"}`} />
                  </div>
                  <div>
                    <h4 className="text-[11px] font-bold text-white text-center leading-tight">
                      📥 Drag & Drop Laptop Files Here
                    </h4>
                    <p className="text-[9px] text-gray-400 leading-tight mt-1 max-w-[200px] mx-auto">
                      Drag any file directly from your Laptop Explorer or Windsurf workspace to link/copy it instantly here!
                    </p>
                  </div>
                  <div className="inline-block px-2.5 py-1 rounded bg-cyan-950/60 border border-cyan-500/10 text-[#00D1FF] text-[8px] font-mono leading-none tracking-wide font-black">
                    OR CLICK TO SIMULATE IMPORT
                  </div>
                </div>

                {/* 3. Connected System Metrics (Real-Time System States) */}
                {laptopTunnelActive && (
                  <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-3.5 space-y-2.5 font-sans text-xs shrink-0">
                    <div className="flex justify-between items-center pb-2 border-b border-gray-800">
                      <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                        🖥️ Laptop Hardware & Context
                      </span>
                      <button
                        onClick={handleForceFetchRemoteStats}
                        className="text-[9px] font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-mono uppercase bg-slate-900 px-1.5 py-0.5 rounded border border-cyan-500/20"
                      >
                        <RefreshCw className="w-2.5 h-2.5" /> RE-SYNC
                      </button>
                    </div>

                    <div className="space-y-2 text-[11px] text-gray-400 font-mono">
                      <div className="flex justify-between items-center bg-[#0d1014] p-1.5 rounded">
                        <span>Workspace Folder:</span>
                        <span className="text-white font-semibold truncate max-w-[130px]" title={laptopWorkspacePath}>
                          .../Projects/windsurf-desktop
                        </span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span>Platform OS:</span>
                        <span className="text-gray-300">{laptopOS}</span>
                      </div>

                      <div className="flex justify-between">
                        <span>Local Forwarding:</span>
                        <span className="text-emerald-400 underline">{laptopLocalUrl}</span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[9px] text-gray-500 font-bold uppercase">
                          <span>LAPTOP CPU LOAD:</span>
                          <span className={laptopCpuLoad > 50 ? "text-yellow-400 font-bold" : "text-cyan-400"}>{laptopCpuLoad}%</span>
                        </div>
                        <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden">
                          <div 
                            className="bg-cyan-500 h-full transition-all duration-500" 
                            style={{ width: `${laptopCpuLoad}%` }}
                          />
                        </div>
                      </div>

                      <div className="flex justify-between">
                        <span>RAM Memory Used:</span>
                        <span className="text-gray-300">{laptopMemUsed}</span>
                      </div>

                      <div className="flex justify-between">
                        <span>Active Editor File:</span>
                        <span className="text-cyan-400 max-w-[120px] truncate" title={activeFile?.path || "app.js"}>
                          {activeFile?.path || "app.js"}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* 4. Live Background Sync Event Stream Logs */}
                <div className="flex-1 flex flex-col min-h-[90px] bg-[#161c24] border border-[#1f2633] rounded-xl overflow-hidden">
                  <div className="px-3.5 py-2 bg-[#0e1116]/80 border-b border-gray-800 text-[9px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-1">
                    <Activity className="w-3 h-3 text-cyan-400 animate-pulse" />
                    Tunnel Sync Log Trace (Background)
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-2 font-mono text-[9px] space-y-1 bg-[#0b0e14]/50" style={{ scrollbarWidth: "thin" }}>
                    {laptopSyncLogs.map((l, idx) => (
                      <div key={idx} className="flex gap-1.5 leading-snug">
                        <span className="text-gray-600">[{l.time}]</span>
                        <span className={
                          l.type === "success" ? "text-emerald-400" : 
                          l.type === "warning" ? "text-rose-400" : "text-gray-400"
                        }>
                          {l.log}
                        </span>
                      </div>
                    ))}
                    {laptopSyncLogs.length === 0 && (
                      <p className="text-gray-600 text-center py-4 italic">No logs yet. Establish link to observe telemetry.</p>
                    )}
                  </div>
                </div>

              </div>
            )}
          </div>
        )}

        {/* VIEW 5: Android ADB, Shizuku & Sui Workspace */}
        {activeLeftTab === "android" && (
          <div className="flex-1 flex flex-col overflow-hidden bg-[#12161a]">
            {/* Drawer Header */}
            <div className="p-4 border-b border-[#1f2633] bg-[#0e1116]/80 flex flex-col gap-1 shrink-0">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-1.5">
                  <span className="p-1 rounded bg-emerald-500/10 text-emerald-400">
                    <Smartphone className="w-4 h-4" />
                  </span>
                  <span className="text-[11px] font-bold text-gray-300 uppercase tracking-widest leading-none">
                    Android Connect SDK
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <span className={`w-1.5 h-1.5 rounded-full ${adbConnected ? "bg-emerald-400 animate-pulse" : "bg-gray-500"}`}></span>
                  <span className="text-[9px] font-mono text-gray-500">{adbConnected ? "ACTIVE" : "OFFLINE"}</span>
                </div>
              </div>
              <p className="text-[10px] text-gray-400">Control device from the inside out via WebUSB or Wifi Debug.</p>
            </div>

            {/* Sub Tabs Selection (Bridge, Addons, X11 Display) */}
            <div className="flex border-b border-[#1f2633] bg-[#0b0e14] p-1 gap-1 shrink-0">
              <button
                onClick={() => setAndroidSubTab("bridge")}
                className={`flex-1 text-center py-1.5 text-[9px] font-bold uppercase tracking-wider rounded-md border-b-2 transition-all ${
                  androidSubTab === "bridge" 
                    ? "border-emerald-500 text-emerald-400 bg-emerald-950/25" 
                    : "border-transparent text-gray-400 hover:text-white"
                }`}
              >
                ADB Bridge
              </button>
              <button
                onClick={() => setAndroidSubTab("addons")}
                className={`flex-1 text-center py-1.5 text-[9px] font-bold uppercase tracking-wider rounded-md border-b-2 transition-all ${
                  androidSubTab === "addons" 
                    ? "border-emerald-500 text-emerald-400 bg-emerald-950/25" 
                    : "border-transparent text-gray-400 hover:text-white"
                }`}
              >
                Addons
              </button>
              <button
                onClick={() => setAndroidSubTab("x11")}
                className={`flex-1 text-center py-1.5 text-[9px] font-bold uppercase tracking-wider rounded-md border-b-2 transition-all ${
                  androidSubTab === "x11" 
                    ? "border-emerald-500 text-emerald-400 bg-emerald-950/25" 
                    : "border-transparent text-gray-400 hover:text-white"
                }`}
              >
                X11 GUI
              </button>
            </div>

            {/* Drawer Body Container */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs" style={{ scrollbarWidth: "thin" }}>
              
              {/* SUBTAB 1: Bridge Controller */}
              {androidSubTab === "bridge" && (
                <div className="space-y-4">
                  
                  {/* WebUSB Hook Trigger info */}
                  <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-3.5 space-y-3">
                    <h5 className="font-bold text-gray-300 text-[10px] uppercase tracking-wider">🔌 Hardware USB Connection</h5>
                    <p className="text-[10px] text-gray-400 leading-snug">
                      Connect your device via a real physical cable. Ensure <strong>USB Debugging</strong> is unlocked in Developer Options on your android phone.
                    </p>
                    
                    <button
                      onClick={async () => {
                        try {
                          const nav = navigator as any;
                          if (!nav.usb) {
                            setTermuxToastMessage("⚠️ WebUSB is blocked in Iframe sandbox. Open app in a new browser tab!");
                            return;
                          }
                          const dev = await nav.usb.requestDevice({ filters: [{ classCode: 255, subclassCode: 66, protocolCode: 1 }] });
                          if (dev) {
                            setConnectedDevice({
                              name: dev.productName || "Android Device Host",
                              serial: dev.serialNumber || "ADB-PRO-99X",
                              battery: 98,
                              osVersion: "Android 14 (U, SDK 34)",
                              rooted: true,
                              shizukuActive: true,
                              suiActive: true,
                              x11Active: true
                            });
                            setAdbConnected(true);
                            setTermuxToastMessage(`🔌 Authorized and linked to ${dev.productName}!`);
                          }
                        } catch (err: any) {
                          setTermuxToastMessage("⚠️ USB Scan connection canceled or blocked.");
                        }
                      }}
                      className="w-full py-2 bg-emerald-900 border border-emerald-500 hover:bg-emerald-800 text-emerald-400 hover:text-white rounded-lg text-[10px] font-bold uppercase flex items-center justify-center gap-1.5 transition-all text-center"
                    >
                      <RotateCw className="w-3.5 h-3.5" /> Scan & Authorize WebUSB
                    </button>
                  </div>

                  {/* Wireless Wi-Fi TCP controller */}
                  <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-3.5 space-y-3">
                    <h5 className="font-bold text-gray-300 text-[10px] uppercase tracking-wider">📶 Wi-Fi Wireless Debug (5555)</h5>
                    <div className="space-y-2">
                      <div className="flex gap-1.5">
                        <div className="flex-1">
                          <label className="text-[9px] text-gray-500 font-bold uppercase block mb-1">Device IP Address</label>
                          <input
                            type="text"
                            value={wifiIp}
                            onChange={(e) => setWifiIp(e.target.value)}
                            className="w-full bg-[#0d1014] border border-gray-800 rounded px-2 py-1 text-[11px] font-mono text-emerald-300 focus:outline-none"
                          />
                        </div>
                        <div className="w-16">
                          <label className="text-[9px] text-gray-500 font-bold uppercase block mb-1">Port</label>
                          <input
                            type="text"
                            value={wifiPort}
                            onChange={(e) => setWifiPort(e.target.value)}
                            className="w-full bg-[#0d1014] border border-gray-800 rounded px-2 py-1 text-[11px] font-mono text-emerald-300 focus:outline-none"
                          />
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          setAdbConnected(true);
                          setTermuxToastMessage(`📶 Tunneled wireless debug socket connection to ${wifiIp}:${wifiPort}!`);
                        }}
                        className="w-full py-2 bg-slate-900 hover:bg-slate-800 border border-emerald-800/60 text-emerald-400 rounded-lg text-[10px] font-bold uppercase flex items-center justify-center gap-1.5 transition-all"
                      >
                        <Radio className="w-3.5 h-3.5" /> Bind TCP Socket Link
                      </button>
                    </div>
                  </div>

                  {/* Shizuku Services & Superuser Sui Status */}
                  <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-3.5 space-y-2.5">
                    <div className="flex justify-between items-center pb-2 border-b border-gray-800">
                      <h5 className="font-bold text-gray-300 text-[10px] uppercase tracking-wider">📲 Android Binder Privileges</h5>
                      <span className="text-[9px] text-emerald-400 font-mono italic">Verified SDK 34</span>
                    </div>

                    {/* Shizuku controller block */}
                    <div className="space-y-2 bg-[#0d1014] p-2.5 rounded border border-gray-800/80">
                      <div className="flex justify-between items-center">
                        <div className="flex flex-col">
                          <span className="text-[11px] font-bold text-white">Shizuku API Service</span>
                          <span className="text-[9px] text-gray-400">Controls system features without rooting</span>
                        </div>
                        <span className="px-1.5 py-0.5 rounded text-[8px] font-mono font-bold bg-green-950 text-green-400 border border-green-800">
                          RUNNING
                        </span>
                      </div>
                      
                      <div className="flex gap-1.5 pt-1">
                        <button
                          onClick={() => {
                            executeTerminalCommandOnBackend("shizuku status");
                            setTermuxToastMessage("Requested Shizuku binder socket status info.");
                          }}
                          className="flex-1 py-1 bg-gray-900 border border-gray-800 hover:bg-slate-800 text-[9px] text-gray-300 font-mono rounded"
                        >
                          Query Status
                        </button>
                        <button
                          onClick={() => {
                            executeTerminalCommandOnBackend("shizuku start");
                            setTermuxToastMessage("Restarted Shizuku IPC Daemon.");
                          }}
                          className="flex-1 py-1 bg-[#12231c] hover:bg-green-900 text-[9px] text-green-400 font-bold rounded"
                        >
                          Force Start
                        </button>
                      </div>
                    </div>

                    {/* Sui Magisk controller block */}
                    <div className="space-y-2 bg-[#0d1014] p-2.5 rounded border border-gray-800/80">
                      <div className="flex justify-between items-center">
                        <div className="flex flex-col">
                          <span className="text-[11px] font-bold text-white">Sui Root Manager</span>
                          <span className="text-[9px] text-gray-400">Magisk / KernelSU privilege levels</span>
                        </div>
                        <span className="px-1.5 py-0.5 rounded text-[8px] font-mono font-bold bg-[#312e81] text-indigo-400 border border-[#4338ca]">
                          MAGISK SU
                        </span>
                      </div>

                      <div className="flex gap-1.5 pt-1">
                        <button
                          onClick={() => {
                            executeTerminalCommandOnBackend("sui request");
                            setTermuxToastMessage("Triggered Superuser popup on Android panel.");
                          }}
                          className="flex-1 py-1 bg-[#1e1b4b] hover:bg-indigo-900 text-[9px] text-indigo-400 font-bold rounded border border-indigo-700/50"
                        >
                          Request Root
                        </button>
                        <button
                          onClick={() => {
                            executeTerminalCommandOnBackend("su");
                            setTermuxToastMessage("Switched active console terminal to Superuser root@termux.");
                          }}
                          className="flex-1 py-1 bg-[#2d0f0f] border border-[#7f1d1d] hover:bg-red-950 text-red-400 text-[9px] font-bold rounded"
                        >
                          su superuser
                        </button>
                      </div>
                    </div>

                  </div>

                </div>
              )}

              {/* SUBTAB 2: Addons / Termux API Controls */}
              {androidSubTab === "addons" && (
                <div className="space-y-4">
                  <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-3.5 space-y-3">
                    <h5 className="font-bold text-gray-300 text-[10px] uppercase tracking-wider">🧳 Action Toolkit (Termux-API Addons)</h5>
                    <p className="text-[10px] text-gray-400">
                      Trigger physical triggers directly from the web client. These trigger real Android system binder calls.
                    </p>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => {
                          executeTerminalCommandOnBackend("termux-vibrate 400");
                          setTermuxToastMessage("📳 Sent vibration command!");
                        }}
                        className="py-2.5 bg-[#0d1014] hover:bg-gray-900 border border-gray-800 text-gray-300 hover:text-white rounded-lg text-[10px] font-bold flex flex-col items-center justify-center gap-1 transition-all"
                      >
                        <span className="text-base">📳</span>
                        <span>Vibrate Phone</span>
                      </button>

                      <button
                        onClick={() => {
                          executeTerminalCommandOnBackend('termux-toast "Bridged secure Windsurf sync finished!"');
                          setTermuxToastMessage("💬 Showed Android Toast notification!");
                        }}
                        className="py-2.5 bg-[#0d1014] hover:bg-gray-900 border border-gray-800 text-gray-300 hover:text-white rounded-lg text-[10px] font-bold flex flex-col items-center justify-center gap-1 transition-all"
                      >
                        <span className="text-base">💬</span>
                        <span>Send Floating Toast</span>
                      </button>

                      <button
                        onClick={() => {
                          executeTerminalCommandOnBackend("termux-battery-status");
                          setTermuxToastMessage("🔋 Queried physical battery status.");
                        }}
                        className="py-2.5 bg-[#0d1014] hover:bg-gray-900 border border-gray-800 text-gray-300 hover:text-white rounded-lg text-[10px] font-bold flex flex-col items-center justify-center gap-1 transition-all"
                      >
                        <span className="text-base">🔋</span>
                        <span>Battery Details</span>
                      </button>

                      <button
                        onClick={() => {
                          setTermuxToastMessage("📷 Generating photographic backup snapshot from secondary lens...");
                          setTimeout(() => {
                            setPhotoPayload("https://images.unsplash.com/photo-1546487813-f2a366b67fd5?auto=format&fit=crop&w=400&q=80");
                          }, 1500);
                        }}
                        className="py-2.5 bg-[#0d1014] hover:bg-gray-900 border border-gray-800 text-gray-300 hover:text-white rounded-lg text-[10px] font-bold flex flex-col items-center justify-center gap-1 transition-all"
                      >
                        <span className="text-base">📷</span>
                        <span>Camera Check</span>
                      </button>
                    </div>

                    {photoPayload && (
                      <div className="bg-[#0b0e14] p-1.5 rounded-lg border border-gray-800 space-y-1">
                        <div className="flex justify-between text-[8px] font-mono text-gray-500 font-bold uppercase">
                          <span>Live camera snapshot result:</span>
                          <button onClick={() => setPhotoPayload("")} className="hover:text-red-400">CLEAR</button>
                        </div>
                        <img src={photoPayload} alt="Snap" className="rounded-md w-full h-24 object-cover border border-gray-800 grayscale sepia tracking-widest bg-black" />
                      </div>
                    )}
                  </div>

                  {/* Clipboard Synchronizer */}
                  <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-3.5 space-y-3">
                    <h5 className="font-bold text-gray-300 text-[10px] uppercase tracking-wider">📋 Universal Clipboard Sharer</h5>
                    <div className="space-y-1.5">
                      <input
                        type="text"
                        value={termuxClipboard}
                        onChange={(e) => setTermuxClipboard(e.target.value)}
                        className="w-full bg-[#0d1014] border border-gray-800 rounded px-2 py-1.5 text-[11px] font-mono text-gray-300 focus:outline-none"
                        placeholder="Content to broadcast"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            executeTerminalCommandOnBackend(`termux-clipboard-set "${termuxClipboard}"`);
                            setTermuxToastMessage("📋 Synced local clipboard to Android.");
                          }}
                          className="flex-1 py-1.5 bg-emerald-950/40 border border-emerald-800 text-emerald-400 font-bold rounded text-[9px] uppercase hover:bg-emerald-950/70"
                        >
                          Mirror to Phone
                        </button>
                        <button
                          onClick={async () => {
                            try {
                              const text = await navigator.clipboard.readText();
                              setTermuxClipboard(text);
                              setTermuxToastMessage("Copied browser text to matrix input!");
                            } catch (e) {
                              setTermuxToastMessage("Clipboard read blocked. Type it manually!");
                            }
                          }}
                          className="py-1.5 px-3 bg-gray-900 border border-gray-800 hover:bg-gray-800 text-gray-300 font-bold rounded text-[9px] uppercase"
                        >
                          Pull Clipboard
                        </button>
                      </div>
                    </div>
                  </div>

                </div>
              )}

              {/* SUBTAB 3: X11 Server Visual Display Window */}
              {androidSubTab === "x11" && (
                <div className="space-y-4">
                  
                  {/* Visual X11 graphical viewport */}
                  <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-3.5 space-y-3">
                    <div className="flex justify-between items-center pb-2 border-b border-gray-800">
                      <h5 className="font-bold text-gray-300 text-[10px] uppercase tracking-wider">📺 Mobile X11 Display :0</h5>
                      <span className="px-1.5 py-0.5 rounded text-[8px] font-mono font-black bg-blue-950 text-blue-400 border border-blue-800">
                        ONLINE
                      </span>
                    </div>

                    {/* Simulating active graphical container layout */}
                    <div className="relative border border-cyan-500/30 rounded-lg overflow-hidden bg-slate-950 flex flex-col h-44 group shadow-2xl">
                      
                      {/* Virtual title bar */}
                      <div className="bg-[#0b0e14] px-2 py-1 flex justify-between items-center border-b border-cyan-500/20 text-[9px] text-gray-400 font-mono">
                        <div className="flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                          <span className="w-1.5 h-1.5 rounded-full bg-yellow-500"></span>
                          <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                          <span className="text-[8px] text-cyan-400/80 font-bold ml-1">{activeWindow}</span>
                        </div>
                        <span className="text-[8px] uppercase">{x11DesktopEnv} {x11Resolution}</span>
                      </div>

                      {/* Display Screen */}
                      <div className="flex-1 relative overflow-hidden bg-[#0d1017] p-2 flex flex-col justify-between">
                        {/* Interactive items drawn inside coordinate box */}
                        {activeWindow === "Termux X11 Terminal" ? (
                          <div className="font-mono text-[8px] text-emerald-400 space-y-1">
                            <p className="text-emerald-500/60 font-bold">[root@termux-desktop /etc]$ x11-utils</p>
                            <p className="text-white">Active process: compile_kernel --inline-clang-17</p>
                            <p className="text-[#00D1FF]">Memory usage: 782 MB / 4096 MB</p>
                            <p className="text-yellow-400">GUI Window System initialized safely via Android native Binder socket.</p>
                            <div className="mt-2 animate-pulse inline-block bg-emerald-500 text-black font-semibold text-[8px] px-1 rounded">
                              WAITING_FOR_ADB_DEBUG_INPUT_PROMPT_SYMBOL
                            </div>
                          </div>
                        ) : activeWindow === "XFCE Editor" ? (
                          <div className="space-y-1">
                            <div className="flex items-center justify-between text-[9px] text-gray-300 font-bold bg-[#1a202c] p-1 rounded font-mono border border-gray-800">
                              <span>📄 MyLocalApp.tsx</span>
                              <span className="text-cyan-400">UNSAVED</span>
                            </div>
                            <p className="font-mono text-[7.5px] text-cyan-300/60 leading-tight">
                              {"export default function MyLocalApp() {\n  return (\n    <div className='bg-slate-900'>\n      <h3>Direct Bridge Synced</h3>\n    </div>\n  );\n}"}
                            </p>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center justify-center h-full text-center space-y-1 font-sans">
                            <Tv className="w-7 h-7 text-cyan-400 animate-pulse mt-3" />
                            <p className="text-[10px] text-white font-bold font-mono">X11 System Workspace monitor</p>
                            <p className="text-[8px] text-gray-500 max-w-[170px]">Process tracker running inside virtual graphical layout.</p>
                          </div>
                        )}

                        <div className="bg-slate-900/90 border border-slate-800 text-[8px] text-gray-400 px-1 py-0.5 rounded self-end flex items-center gap-1 font-mono">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Display socket :0
                        </div>
                      </div>

                      {/* Virtual system hot panel */}
                      <div className="bg-[#10141d] border-t border-cyan-500/10 px-2 py-1 flex items-center gap-2 justify-between shrink-0">
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => {
                              setActiveWindow("Termux X11 Terminal");
                              setTermuxToastMessage("Switched GUI focus to X11 Console.");
                            }}
                            className={`px-1.5 py-0.5 rounded text-[8px] font-mono ${activeWindow === "Termux X11 Terminal" ? "bg-emerald-950 text-emerald-400 border border-emerald-800" : "bg-[#161c24] text-gray-400"}`}
                          >
                            XTerm console
                          </button>
                          <button
                            onClick={() => {
                              setActiveWindow("XFCE Editor");
                              setTermuxToastMessage("Switched GUI focus to XFCE editor.");
                            }}
                            className={`px-1.5 py-0.5 rounded text-[8px] font-mono ${activeWindow === "XFCE Editor" ? "bg-cyan-950 text-cyan-400 border border-cyan-800" : "bg-[#161c24] text-gray-400"}`}
                          >
                            XFCE Edit
                          </button>
                          <button
                            onClick={() => {
                              setActiveWindow("System Monitor");
                              setTermuxToastMessage("Switched GUI focus to X11 overview map.");
                            }}
                            className={`px-1.5 py-0.5 rounded text-[8px] font-mono ${activeWindow === "System Monitor" ? "bg-blue-950 text-blue-400 border border-blue-800" : "bg-[#161c24] text-gray-400"}`}
                          >
                            overview
                          </button>
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Desktop configuration panel */}
                  <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-3.5 space-y-3">
                    <h5 className="font-bold text-gray-300 text-[10px] uppercase tracking-wider">🛠 Display Configuration</h5>
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <div className="flex-1">
                          <label className="text-[9px] text-gray-500 font-bold uppercase block mb-1">X11 environment</label>
                          <select
                            value={x11DesktopEnv}
                            onChange={(e: any) => {
                              setX11DesktopEnv(e.target.value);
                              setTermuxToastMessage(`Switched virtual UI background runner to: ${e.target.value}`);
                            }}
                            className="w-full bg-[#0d1014] border border-gray-800 rounded px-2 py-1 text-[10px] text-gray-300 focus:outline-none"
                          >
                            <option value="xfce">XFCE (Proot Classic)</option>
                            <option value="i3">i3-gaps (Tiling poweruser)</option>
                            <option value="gnome">Gnome Mobile Wrapper</option>
                          </select>
                        </div>

                        <div className="w-24">
                          <label className="text-[9px] text-gray-500 font-bold uppercase block mb-1">Canvas Resolution</label>
                          <select
                            value={x11Resolution}
                            onChange={(e) => setX11Resolution(e.target.value)}
                            className="w-full bg-[#0d1014] border border-gray-800 rounded px-2 py-1 text-[10px] text-gray-300 focus:outline-none"
                          >
                            <option value="1280x720">1280x720 (16:9)</option>
                            <option value="1920x1080">1920x1080 (HD)</option>
                            <option value="2400x1080">2400x1080 (Wide)</option>
                          </select>
                        </div>
                      </div>

                      <div className="flex gap-2 pt-1">
                        <button
                          onClick={() => {
                            setX11ConsoleLog(prev => [...prev, `[x11] Force killed current bound socket :0`, `[x11] Respawning Xorg service on port 6000`, `[x11] Display initialized safely.`]);
                            setTermuxToastMessage("🔄 Rebooted local X11 layout daemon process!");
                          }}
                          className="flex-1 py-1 px-2.5 bg-gray-900 border border-gray-800 text-gray-400 rounded hover:text-white hover:bg-slate-800 text-[10px] font-mono flex items-center justify-center gap-1 uppercase font-bold"
                        >
                          <RotateCw className="w-3 h-3" /> Reboot XDisplay
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* X11 Telemetry Output logs */}
                  <div className="bg-[#161c24] border border-[#1f2633] rounded-xl p-3 flex flex-col h-28 overflow-hidden font-mono text-[9px]">
                    <span className="text-gray-500 font-bold uppercase text-[8px] tracking-wider pb-1.5 border-b border-gray-800 shrink-0">
                      📺 X11 Framebuffer server console logs
                    </span>
                    <div className="flex-1 overflow-y-auto space-y-1.5 pt-1.5 text-cyan-400" style={{ scrollbarWidth: "thin" }}>
                      {x11ConsoleLog.map((log, idx) => (
                        <div key={idx} className="flex gap-1">
                          <span className="text-gray-600 font-black">&gt;</span>
                          <span>{log}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}

            </div>
          </div>
        )}

        {/* VIEW 4: Windsurf Manual instructions */}
        {activeLeftTab === "help" && (
          <div className="flex-1 flex flex-col overflow-hidden bg-[#12161a]">
            <div className="p-4 border-b border-[#1f2633] bg-[#0e1116]/80 text-[11px] font-bold text-gray-400 uppercase tracking-widest">
              Windsurf Feature Manual
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs text-gray-300 leading-relaxed">
              <div className="space-y-1 bg-slate-900/50 p-3 rounded-lg border border-slate-800">
                <h5 className="font-bold text-cyan-400 text-[11px] uppercase">🔮 Ghost Suggests</h5>
                <p className="text-[10px] text-gray-400">
                  When modifying file documents, look for light italicized autocomplete codes. Simply press the **[Tab]** hotkey to instantly apply!
                </p>
              </div>

              <div className="space-y-1 bg-slate-900/50 p-3 rounded-lg border border-slate-800">
                <h5 className="font-bold text-[#A3E635] text-[11px] uppercase">👥 Websocket Multi-User</h5>
                <p className="text-[10px] text-gray-400">
                  Open another browser tab or copy the system URL. All edits, creations, cursor locations, and Git logs will mirror in real-time between clients!
                </p>
              </div>

              <div className="space-y-2 bg-slate-900/50 p-3 rounded-lg border border-slate-800">
                <h5 className="font-bold text-indigo-400 text-[11px] uppercase">🛠 Simulated Shell API</h5>
                <p className="text-[10px] text-gray-400">
                  The terminal below operates a live interactive processor. Try commands like:
                </p>
                <div className="font-mono text-[9px] text-cyan-300/80 space-y-0.5 bg-black/40 p-1.5 rounded">
                  <p>$ git status</p>
                  <p>$ git commit -m "feat: done"</p>
                  <p>$ git checkout -b feature-test</p>
                  <p>$ git merge master</p>
                  <p>$ npm run build</p>
                  <p>$ node app.js</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </aside>

      {/* ----------------- Active Code Editor & Preview/Terminal workspace ----------------- */}
      <main id="col-workspace-middle" className="flex-1 flex flex-col min-w-0 bg-[#07090c] relative">
        
        {/* Head tab workspace controller and peer presence avatars */}
        <div className="h-10 bg-[#0e1116] border-b border-[#1a202c] flex items-center justify-between px-3">
          
          {/* Active code tabs list */}
          <div className="flex items-center h-full overflow-x-auto select-none" style={{ scrollbarWidth: "none" }}>
            {tabs.map(tabname => {
              const matchedF = files.find(f => f.path === tabname);
              const isActive = activeFile?.path === tabname;
              return (
                <div
                  key={tabname}
                  onClick={() => selectTab(tabname)}
                  className={`group px-3.5 flex items-center gap-1.5 text-xs h-full cursor-pointer border-r border-[#1a202c] transition-all relative ${
                    isActive 
                      ? "bg-[#07090c] text-white border-t-2 border-[#00D1FF] font-medium" 
                      : "text-gray-400 hover:bg-gray-800/20 hover:text-white"
                  }`}
                >
                  <span className="text-[9px] px-1 bg-blue-500/10 text-cyan-400 rounded-sm font-bold uppercase">
                    {tabname.split(".").pop() || "js"}
                  </span>
                  <span>{tabname}</span>
                  {tabs.length > 1 && (
                    <button
                      onClick={(e) => closeTab(tabname, e)}
                      className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-gray-800 rounded transition-opacity"
                    >
                      <X className="w-2.5 h-2.5 text-gray-500 hover:text-white" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {/* Active collaborators list list with avatar tooltips */}
          <div className="flex items-center gap-3">
            <div className="flex items-center -space-x-1.5 overflow-hidden">
              {(Object.values(collaborators) as Collaborator[]).map(peer => (
                <div
                  key={peer.id}
                  className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold border text-white transition-transform hover:-translate-y-0.5 cursor-help"
                  style={{
                    backgroundColor: peer.color,
                    borderColor: '#07090c',
                    boxShadow: `0 0 8px ${peer.color}40`
                  }}
                  title={`Name: ${peer.name} (Synchronized client cursor position)`}
                >
                  {peer.name.charAt(0)}
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                navigator.clipboard.writeText(window.location.href);
                appendSystemLog("Tunnel: Secured collaboration link copied to clipboard successfully!");
              }}
              className="flex items-center gap-1.5 px-2 py-1 rounded bg-[#1e293b]/80 border border-[#2e3e52] text-xs text-gray-300 hover:text-[#00D1FF] hover:border-[#00D1FF]/40 transition-all"
              title="Copy session link"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="text-[10px] font-bold uppercase tracking-wider hidden sm:inline">Invite Peer</span>
            </button>
          </div>
        </div>

        {/* Highlight resolved code field editing workspace */}
        <div className="flex-1 relative overflow-hidden">
          {activeFile ? (
            <div className="w-full h-full relative">
              <HighlightEditor
                value={activeFile.content}
                onChange={handleActiveFileChange}
                language={activeFile.path.split(".").pop() || "javascript"}
                inlineSuggestion={editorGhostSuggestion}
                onAcceptSuggestion={handleGhostAccept}
              />
              
              {/* Dynamic Absolute Bubbles showing other active collaborator cursors */}
              {(Object.values(collaborators) as Collaborator[]).map(peer => {
                if (peer.cursor && peer.cursor.fileId === currentFileId) {
                  return (
                    <div
                      key={peer.id}
                      className="absolute pointer-events-none transition-all duration-300 z-40 flex flex-col items-start"
                      style={{
                        top: `${Math.min(peer.cursor.line * 20 + 20, 350)}px`,
                        left: `${Math.min(peer.cursor.ch * 7 + 60, 400)}px`,
                      }}
                    >
                      {/* Flashing Caret bar */}
                      <div className="w-0.5 h-4 animate-pulse" style={{ backgroundColor: peer.color }}></div>
                      {/* Tag identification */}
                      <div
                        className="text-[8px] px-1 py-0.5 text-white rounded font-bold uppercase shadow-md whitespace-nowrap"
                        style={{ backgroundColor: peer.color }}
                      >
                        {peer.name.split(" ")[0]}
                      </div>
                    </div>
                  );
                }
                return null;
              })}
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center h-full text-center p-6 space-y-3">
              <File className="w-12 h-12 text-gray-600 animate-pulse" />
              <h3 className="text-sm font-semibold text-white">No active editor files loaded</h3>
              <p className="text-xs text-gray-500 max-w-sm">
                Scaffold a fresh code document or select an indexed project template in the left sidebar directory drawer.
              </p>
            </div>
          )}

          {/* Merge Conflict Resolution overlay prompt */}
          {hasMergeConflict && (
            <div className="absolute top-3 left-3 right-3 bg-red-950/90 border border-red-500/30 p-3 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 backdrop-blur-md z-30 shadow-2xl animate-bounce">
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white">Automatic Merge Conflict Detected!</h4>
                  <p className="text-[10px] text-gray-400">
                    Git conflict delimiters are present in the editor. Choose an interactive action below to patch code files gracefully.
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => resolveConflictState("current")}
                  className="bg-cyan-500 hover:bg-cyan-400 text-black text-[10px] font-bold px-3 py-1.5 rounded-md"
                >
                  Accept Current (HEAD)
                </button>
                <button
                  onClick={() => resolveConflictState("incoming")}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold px-3 py-1.5 rounded-md"
                >
                  Accept Incoming (Incoming branch)
                </button>
              </div>
            </div>
          )}
        </div>

        {/* ----------------- Dual Mode Terminal & Sandbox Live Preview Panel ----------------- */}
        <div id="section-terminal" className="h-48 bg-[#0b0e14] border-t border-[#1a202c] flex flex-col z-10">
          
          {/* Terminal section headers */}
          <div className="h-8 border-b border-[#1a202c] bg-[#0e1116] flex items-center justify-between px-3">
            <div className="flex items-center h-full text-xs font-semibold select-none">
              <button
                onClick={() => setTerminalActiveTab("preview")}
                className={`px-3 h-full flex items-center gap-1 transition-all ${
                  terminalActiveTab === "preview" ? "text-[#00D1FF] bg-[#0b0e14] border-t border-[#00D1FF]" : "text-gray-500 hover:text-white"
                }`}
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Simulated Output Live Preview</span>
              </button>

              <button
                onClick={() => setTerminalActiveTab("terminal")}
                className={`px-3 h-full flex items-center gap-1 transition-all ${
                  terminalActiveTab === "terminal" ? "text-[#00D1FF] bg-[#0b0e14] border-t border-[#00D1FF]" : "text-gray-500 hover:text-white"
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>Active Terminal Shell</span>
              </button>

              <button
                onClick={() => setTerminalActiveTab("logs")}
                className={`px-3 h-full flex items-center gap-1 transition-all ${
                  terminalActiveTab === "logs" ? "text-[#00D1FF] bg-[#0b0e14] border-t border-[#00D1FF]" : "text-gray-500 hover:text-white"
                }`}
              >
                <Cpu className="w-3.5 h-3.5" />
                <span>Build Compilers</span>
              </button>

              <button
                onClick={() => setTerminalActiveTab("git")}
                className={`px-3 h-full flex items-center gap-1 transition-all ${
                  terminalActiveTab === "git" ? "text-[#00D1FF] bg-[#0b0e14] border-t border-[#00D1FF]" : "text-gray-500 hover:text-white"
                }`}
              >
                <History className="w-3.5 h-3.5" />
                <span>Git Commits Log</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest block">
                Target Platform:
              </span>
              <span className="text-[9px] bg-cyan-950/40 text-cyan-400 border border-cyan-500/20 px-1.5 py-0.5 rounded font-mono font-bold uppercase">
                {githubUser.codespaceServer === "github" ? "GitHub remote builder" : "VIRTUAL CLIENT PROCESS"}
              </span>
            </div>
          </div>

          {/* Sub Panels contents */}
          <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-gray-300">
            
            {/* Tab: Real-time Sandboxed Compile Screen! */}
            {terminalActiveTab === "preview" && (
              <div className="w-full h-full relative">
                {/* Simulated Web Iframe Canvas box rendering index.html & app.js */}
                <div className="absolute inset-0 bg-gray-950 rounded-xl overflow-hidden border border-[#1f2633] flex flex-col">
                  {/* Browser URL Simulator header bar */}
                  <div className="h-7 bg-[#141822] border-b border-[#212b3c] flex items-center text-[10px] text-gray-400 justify-between px-3">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="flex gap-1">
                        <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                        <span className="w-2 h-2 rounded-full bg-yellow-500"></span>
                        <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-black/40 text-blue-400 font-mono text-[9px] truncate">
                        https://simulated-preview-port-3000.run.app/?project={activeTemplateId}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => {
                          appendSystemLog("[Compiler]: Triggered manual index rebuild reload.");
                        }}
                        className="hover:text-[#00D1FF] transition-all"
                        title="Force reload canvas compiler"
                      >
                        <RefreshCw className="w-3 h-3 animate-spin" style={{ animationDuration: '6s' }} />
                      </button>
                      <span className="text-[9px] text-[#A3E635] font-bold">● ONLINE</span>
                    </div>
                  </div>

                  {/* Dynamic interactive preview renderer */}
                  <div className="flex-1 bg-[#0b0f14] relative overflow-hidden">
                    {activeTemplateId === "react-dashboard" ? (
                      <div className="w-full h-full p-4 overflow-y-auto space-y-4">
                        <div className="flex justify-between items-center bg-gray-900 border border-gray-800 p-3 rounded-lg">
                          <div>
                            <h4 className="text-white font-bold text-xs">⚙ Zenith Cloud Operations (Compiled Sandbox)</h4>
                            <p className="text-[10px] text-gray-500">Live rendering client state tracker compiled on the server.</p>
                          </div>
                          <span className="text-xs bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded font-bold animate-pulse">Running</span>
                        </div>
                        <div className="grid grid-cols-2 gap-3 text-center">
                          <div className="bg-gray-900/50 p-2.5 rounded-lg border border-gray-800/60">
                            <span className="text-[9px] text-gray-500 block uppercase font-bold text-left">Active users</span>
                            <span className="text-lg font-bold text-white">24,890 clients</span>
                          </div>
                          <div className="bg-gray-900/50 p-2.5 rounded-lg border border-gray-800/60">
                            <span className="text-[9px] text-gray-500 block uppercase font-bold text-left">Cluster Revenue</span>
                            <span className="text-lg font-bold text-emerald-400">$124,500 USD</span>
                          </div>
                        </div>
                        {/* Interactive dynamic test button */}
                        <button
                          onClick={() => {
                            appendSystemLog("Compiler Ingress Event: Simulated metrics trigger completed.");
                          }}
                          className="w-full bg-[#00D1FF] hover:bg-cyan-400 text-black py-1.5 rounded text-xs font-bold transition-all"
                        >
                          Simulate Live Metric Alteration +
                        </button>
                      </div>
                    ) : activeTemplateId === "galaxy-gravity-sim" ? (
                      <div className="w-full h-full p-4 overflow-y-auto space-y-3 font-mono text-center flex flex-col justify-center bg-gray-950">
                        <Orbit className="w-10 h-10 text-indigo-400 mx-auto animate-spin" style={{ animationDuration: '3s' }} />
                        <h4 className="text-white font-bold text-xs tracking-wider">ASTRONOMICAL PHYSICS STAGE INITIALIZED</h4>
                        <p className="text-[9px] text-gray-500 max-w-sm mx-auto">
                          Gravity engine rendering stars, mechanical velocity loops and interactive collision matrices.
                        </p>
                        <button
                          onClick={() => appendSystemLog("Sandbox event: Injected custom gravitational mass body.")}
                          className="bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] py-1 px-3 rounded max-w-xs mx-auto text-semibold transition-all"
                        >
                          Trigger Simulated Mass Attraction Vector
                        </button>
                      </div>
                    ) : (
                      <div className="w-full h-full p-4 space-y-2 overflow-y-auto">
                        <h4 className="text-white font-bold text-xs border-b border-gray-800 pb-1 flex items-center gap-1.5">
                          <SquareTerminal className="w-4 h-4 text-rose-400" />
                          <span>Autodoc AI Plan Simulator</span>
                        </h4>
                        <div className="space-y-1 font-mono text-[10px] text-gray-400">
                          <p className="text-yellow-400">Step 1. Building pipeline matrices...</p>
                          <p className="text-emerald-400">✔ Loaded tasks-json config values (5 task schemas mapped)</p>
                          <p className="text-[#00D1FF]">✔ Estimated critical execution timeline constraints: 35 Hours</p>
                          <div className="bg-gray-900 p-2 border border-gray-800 rounded font-bold text-white text-[9px] space-y-0.5">
                            <p>T1: Construct UI Shell                   [Duration: 8hrs]</p>
                            <p>T2: Create Express Routing Engine         [Duration: 5hrs]</p>
                            <p>T3: Integrate Gemini AI Pipeline          [Duration: 12hrs]</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Tab: shell outputs */}
            {terminalActiveTab === "terminal" && (
              <div className="w-full h-full flex flex-col md:flex-row gap-3 min-h-0">
                {/* Left: Termux Terminal Terminal Console */}
                <div className={`flex-1 flex flex-col justify-between p-3 rounded-lg border transition-all ${getThemeClasses().bg} ${getThemeClasses().text} ${getThemeClasses().border} overflow-hidden font-mono shadow-2xl relative min-h-0`}>
                  {/* Mini Termux Banner Status Header */}
                  <div className="flex items-center justify-between text-[10px] border-b border-gray-800/40 pb-1.5 mb-2 select-none">
                    <div className="flex items-center gap-1.5 text-[11px]">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      <span className="font-bold tracking-tight text-gray-300">📱 TERMUX EMULATOR ENGINE</span>
                    </div>
                    <div className="flex items-center gap-3 text-gray-500 text-[10px]">
                      <span>Arch: <strong className="text-amber-500 font-mono font-bold">aarch64</strong></span>
                      <span className="text-gray-800">|</span>
                      <span>Root: <button 
                          onClick={() => executeTerminalCommandOnBackend("su")}
                          type="button"
                          className={`font-semibold transition-all px-1.5 py-0.5 rounded text-[9px] ${termuxRoot ? "bg-red-950/80 text-red-400 border border-red-500/30" : "bg-gray-800/60 text-gray-400"}`}>
                          {termuxRoot ? "ACTIVE (su)" : "INACTIVE"}
                        </button>
                      </span>
                      <span className="text-gray-800">|</span>
                      <span>Skin Theme: <strong className="text-cyan-400 font-bold uppercase">{termuxTheme}</strong></span>
                    </div>
                  </div>

                  {/* Terminal history list */}
                  <div className="flex-1 overflow-y-auto space-y-2 select-text font-mono text-[10px] pr-1">
                    <div className="text-gray-500 text-[9px] border-b border-gray-900 pb-1 mb-2">
                      Welcome to Termux Android simulated sandbox! Type 'help' to inspect Termux commands.
                      Try 'su' or trigger 'termux-battery-status', or install custom plugins below.
                    </div>
                    {terminalHistory.map(cmd => (
                      <div key={cmd.id} className="space-y-1 bg-black/20 border-l-2 border-cyan-500/10 pl-2">
                        <div className="flex items-center text-gray-600 justify-between text-[8px] select-none">
                          <span className="flex items-center gap-1">
                            <span className={`${getThemeClasses().prompt} font-black`}>$ {cmd.input}</span>
                            <span className="text-gray-600">in {cmd.directory}</span>
                          </span>
                          <span>{cmd.timestamp}</span>
                        </div>
                        <pre className={`font-mono text-[10px] whitespace-pre-wrap leading-tight mt-0.5 ${getThemeClasses().output}`}>{cmd.output}</pre>
                      </div>
                    ))}
                    <div ref={terminalBottomRef}></div>
                  </div>

                  {/* Termux soft keys rows (multi-device touch accessory bar!) */}
                  <div className="flex flex-wrap gap-1 border-t border-gray-800/60 pt-1.5 mt-1 select-none">
                    {["ESC", "CTRL", "ALT", "TAB", "su", "termux-info", "termux-setup-storage", "termux-api", "Clear"].map(key => {
                      let actionLabel = key;
                      let cmdToRun = "";
                      if (key === "su") cmdToRun = "su";
                      else if (key === "termux-info") cmdToRun = "termux-info";
                      else if (key === "termux-setup-storage") cmdToRun = "termux-setup-storage";
                      else if (key === "termux-api") cmdToRun = "termux-api";
                      else if (key === "Clear") cmdToRun = "clear";
                      
                      return (
                        <button
                          key={key}
                          type="button"
                          onClick={() => {
                            if (cmdToRun) {
                              if (cmdToRun === "clear") setTerminalHistory([]);
                              else executeTerminalCommandOnBackend(cmdToRun);
                            } else if (key === "TAB") {
                              setTerminalInput(prev => prev + "pkg install ");
                            } else {
                              setTerminalInput(prev => prev + key.toLowerCase() + " ");
                            }
                          }}
                          className="bg-gray-950 hover:bg-gray-900 text-gray-400 active:text-white border border-gray-800 text-[9px] px-2 py-0.5 rounded font-mono font-bold transition-all active:scale-95"
                        >
                          {key}
                        </button>
                      );
                    })}
                  </div>

                  {/* Shell Input row */}
                  <form onSubmit={handleTerminalSubmit} className="flex border-t border-gray-800/40 pt-2 mt-1.5">
                    <span className={`${getThemeClasses().prompt} mr-2 text-xs select-none font-bold`}>
                      {termuxRoot ? "root@termux:~#" : "localhost:~$"}
                    </span>
                    <input
                      type="text"
                      placeholder="Run pkg install, su, battery, toast <text>, vibrate..."
                      value={terminalInput}
                      onChange={(e) => setTerminalInput(e.target.value)}
                      className="flex-1 bg-transparent text-white text-xs focus:outline-none border-none font-mono focus:ring-0 p-0"
                    />
                    <div className="text-[10px] text-gray-500 select-none flex items-center gap-1.5 shrink-0">
                      <span>Touch / Press</span>
                      <kbd className="px-1 bg-gray-900 border border-gray-800 text-gray-400 rounded text-[9px]">Enter</kbd>
                    </div>
                  </form>
                </div>

                {/* Right: Termux active settings & packages manager dashboard */}
                <div className="w-full md:w-64 bg-gray-950/70 border border-gray-850 rounded-lg p-3 flex flex-col justify-between text-xs font-mono shrink-0 select-none">
                  <div className="space-y-4">
                    <div className="border-b border-gray-800/80 pb-1.5 flex justify-between items-center">
                      <span className="font-bold text-gray-400 uppercase tracking-wide text-[10px]">Termux Core Control</span>
                      <span className="text-[9px] bg-red-950/60 border border-red-500/20 text-red-400 px-1 rounded">EMULATOR</span>
                    </div>

                    {/* API Trigger widgets widget */}
                    <div className="space-y-2">
                      <span className="text-[9px] text-gray-500 block uppercase font-bold tracking-widest">Hardware API Controls</span>
                      <div className="grid grid-cols-2 gap-1.5">
                        <button
                          onClick={() => executeTerminalCommandOnBackend("termux-battery-status")}
                          className="bg-[#141822] hover:bg-[#1f2635] text-gray-300 border border-gray-800 py-1 rounded text-[10px] text-center"
                          type="button"
                        >
                          🔋 Battery Status
                        </button>
                        <button
                          onClick={() => executeTerminalCommandOnBackend("termux-vibrate 600")}
                          className="bg-[#141822] hover:bg-[#1f2635] text-gray-300 border border-gray-800 py-1 rounded text-[10px] text-center"
                          type="button"
                        >
                          📳 Vibrate Device
                        </button>
                      </div>
                      <button
                        onClick={() => executeTerminalCommandOnBackend(`termux-toast "Termux active at: ${new Date().toLocaleTimeString()}"`)}
                        className="w-full bg-[#141822] hover:bg-[#1f2635] text-[#00D1FF] border border-cyan-800/30 py-1 rounded text-[10px] text-center"
                        type="button"
                      >
                        💬 Simulate Web Toast API
                      </button>
                    </div>

                    {/* Theme selector */}
                    <div className="space-y-1.5">
                      <span className="text-[9px] text-gray-500 block uppercase font-bold tracking-widest">Console Skin Theme</span>
                      <div className="relative">
                        <select
                          value={termuxTheme}
                          onChange={(e) => executeTerminalCommandOnBackend(`termux-styling theme ${e.target.value}`)}
                          className="w-full bg-[#141822] border border-gray-800 rounded px-2 py-1 text-white text-[10px] focus:outline-none focus:border-cyan-500 cursor-pointer"
                        >
                          <option value="dracula">Dracula (Lavender)</option>
                          <option value="monokai">Monokai (Classical Retro)</option>
                          <option value="solarized">Solarized (Amber Teal)</option>
                          <option value="nord">Nord (Arctic Blue)</option>
                          <option value="retro-green">Retro Green (Phosphor)</option>
                          <option value="cobalt">Cobalt (Intense Slate)</option>
                          <option value="matrix">Matrix Code (Black Green)</option>
                        </select>
                      </div>
                    </div>

                    {/* Installed packages toggle list */}
                    <div className="space-y-1.5">
                      <span className="text-[9px] text-gray-500 block uppercase font-bold tracking-widest">Package Repositories</span>
                      <div className="space-y-1 max-h-36 overflow-y-auto pr-1">
                        {[
                          { id: "python", desc: "Python Compiler Client" },
                          { id: "nodejs", desc: "Node.js JavaScript Platform" },
                          { id: "git", desc: "Collaborative Git Version Controls" },
                          { id: "termux-api", desc: "Hardware Bridge Client" },
                          { id: "clang", desc: "C/C++ Native Library GCC" },
                          { id: "vim", desc: "Vi Improved Console Editor" },
                          { id: "zsh", desc: "Z-Shell Extensions shell" }
                        ].map(pkg => {
                          const isInst = termuxPackages.includes(pkg.id);
                          return (
                            <div 
                              key={pkg.id} 
                              onClick={() => {
                                if (!isInst) {
                                  executeTerminalCommandOnBackend("pkg install " + pkg.id);
                                } else {
                                  executeTerminalCommandOnBackend("pkg uninstall " + pkg.id);
                                }
                              }}
                              className={`flex items-center justify-between p-1 rounded border text-[9px] cursor-pointer transition-all ${isInst ? "bg-cyan-950/20 border-cyan-500/20 text-[#00D1FF]" : "bg-[#0b0f14] border-gray-800/80 text-gray-500 hover:text-gray-300"}`}
                            >
                              <div className="flex items-center gap-1.5">
                                <span className={`w-1.5 h-1.5 rounded-full ${isInst ? "bg-[#00D1FF]" : "bg-gray-800"}`}></span>
                                <span className="font-bold font-mono">{pkg.id}</span>
                              </div>
                              <span className="text-[8px] opacity-85">{isInst ? "Installed" : "Click Install"}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* System states indicators */}
                  <div className="pt-2 border-t border-gray-805 text-[8px] text-gray-500 space-y-0.5">
                    <div className="flex justify-between">
                      <span>OS Bridge:</span>
                      <span className="text-[#A3E635]">API level 33 (Active)</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Shared Storage:</span>
                      <span className={termuxStorage ? "text-cyan-400" : "text-amber-500"}>
                        {termuxStorage ? "Granted (/sdcard)" : "Denied (setup required)"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab: system logs */}
            {terminalActiveTab === "logs" && (
              <div className="w-full h-full overflow-y-auto space-y-1 text-gray-400 font-mono text-[11px] select-text">
                <p className="text-gray-600">[{new Date().toLocaleDateString()}] System Boot logging initialized dev tracker...</p>
                <p><span className="text-blue-500">[Ingress Logs]</span> Tunnel connection established dynamically with peer clients.</p>
                <p><span className="text-yellow-500">[Compilation Worker]</span> Hot bundle initialized on websocket load stream.</p>
                {githubUser.loggedIn ? (
                  <>
                    <p className="text-green-500">[Remote AWS Runner] Active session user connected: '{githubUser.username}' with verified credentials.</p>
                    <p className="text-[#00D1FF]">[Codespace Server Status] Running 2C/4GB node container. Sync active in 124ms.</p>
                  </>
                ) : (
                  <p className="text-gray-500">[Client Worker] Standard local preview rendering engine active. Use Codespace tab to connect remote builders.</p>
                )}
                {files.map(f => (
                  <p key={f.id} className="text-gray-500"><span className="text-gray-600">[FileSystem]</span> Checksum matching updated for file pathway: {f.path}</p>
                ))}
              </div>
            )}

            {/* Tab: commit graph */}
            {terminalActiveTab === "git" && (
              <div className="w-full h-full overflow-y-auto space-y-2">
                {!gitState.isInitialized ? (
                  <p className="text-gray-500 text-center py-4">Git repository not initialized yet. Turn on 'git init' on control tab first.</p>
                ) : gitState.commits.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">No commit records registered. Stage modified files and record your initial index.</p>
                ) : (
                  <div className="space-y-3">
                    <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest pl-1">
                      Visual Commit logs graph history
                    </p>
                    <div className="space-y-2">
                      {gitState.commits.slice().reverse().map((c, idx) => (
                        <div key={c.hash} className="p-2 rounded-lg bg-[#161c24]/50 border border-gray-800/40 font-mono text-xs flex items-center justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-cyan-400 font-bold">commit {c.hash}</span>
                              <span className="text-gray-500 text-[10px]">{c.timestamp}</span>
                            </div>
                            <p className="text-white text-xs">{c.message}</p>
                            <p className="text-[10px] text-gray-500 font-sans">Author: {c.author}</p>
                          </div>
                          <span className="text-[10px] bg-slate-800 text-slate-300 border border-slate-700 px-1.5 py-0.5 rounded">
                            HEAD ~ {idx}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* ----------------- Bottom Status Bar ----------------- */}
        <footer id="status-bar" className="h-6 bg-[#00D1FF] text-black px-3.5 flex items-center justify-between text-[10px] font-bold uppercase tracking-wider z-20 select-none">
          <div className="flex space-x-5 items-center">
            <span className="flex items-center gap-1">
              <GitBranch className="w-3.5 h-3.5" />
              <span>{gitState.currentBranch.toUpperCase()}</span>
            </span>
            <span className="opacity-70">
              {gitState.isInitialized ? "TRACKING ACTIVE" : "GIT UNINITIALIZED"}
            </span>
            <span className="hidden md:inline">
              | Connection: {connectionStatus.toUpperCase()}
            </span>
          </div>
          
          <div className="flex space-x-5 items-center">
            <span>UTF-8</span>
            <span>TSX MODEL TARGET</span>
            <span className="flex items-center gap-1 font-black">
              CASCADE READY
              <span className="w-2 h-2 rounded-full bg-black animate-pulse"></span>
            </span>
          </div>
        </footer>
      </main>

      {/* ----------------- Right Panel Column: Windsurf Flow Dialogue ----------------- */}
      <aside id="col-cascade-ai" className="w-[320px] bg-[#0c0f13] border-l border-[#1a202c] flex flex-col relative shrink-0 z-15">
        {/* Subtle cyan neon background gradient bleed */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#00D1FF04] to-transparent pointer-events-none"></div>

        {/* Cascade Header bar */}
        <div className="p-4 border-b border-[#1a202c] flex items-center justify-between relative bg-[#0e1116]/80">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-md bg-[#00D1FF] flex items-center justify-center shadow-[0_0_10px_rgba(0,209,255,0.4)]">
              <Sparkles className="w-3.5 h-3.5 text-black" />
            </div>
            <div>
              <span className="font-extrabold text-white text-xs tracking-wider uppercase block">WINDSURF CASCADE</span>
              <span className="text-[9px] text-[#00D1FF] block font-mono font-semibold">Gemini 3.5 Assistant Active</span>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-[10px] text-gray-500 font-bold font-mono">FLOW:</span>
            <span className="w-2.5 h-2.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)] animate-pulse" title="Secure dev socket online"></span>
          </div>
        </div>

        {/* Task state and mode toggles */}
        <div className="grid grid-cols-2 text-center text-[10px] font-bold border-b border-[#1a202c] bg-black/20">
          <button
            onClick={() => { setAiMode("chat"); appendSystemLog("Cascade: Mode sets to Chat (Ask Mode)."); }}
            className={`py-2 border-r border-[#1a202c] transition-colors ${
              aiMode === "chat" ? "text-[#00D1FF] bg-[#1a202c]/30 border-b-2 border-[#00D1FF]" : "text-gray-400 hover:text-white"
            }`}
          >
            ASK (CHAT MODE)
          </button>
          <button
            onClick={() => { setAiMode("agent"); appendSystemLog("Cascade: Mode sets to Agent (Write Mode)."); }}
            className={`py-2 transition-colors ${
              aiMode === "agent" ? "text-[#00D1FF] bg-[#1a202c]/30 border-b-2 border-[#00D1FF]" : "text-gray-400 hover:text-white"
            }`}
          >
            WRITE (AGENT MODE)
          </button>
        </div>

        {/* Conversations list wrapper */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`space-y-2 p-3.5 rounded-xl border transition-all ${
                m.role === "user"
                  ? "bg-[#182133]/40 border-[#2d3a54] text-gray-200"
                  : "bg-[#10141b] border-[#1c2436] text-gray-100 shadow-lg relative"
              }`}
            >
              {/* Message identity header */}
              <div className="flex items-center justify-between text-[10px]">
                <span className={`font-bold uppercase tracking-wider ${
                  m.role === "user" ? "text-gray-400" : "text-[#00D1FF]"
                }`}>
                  {m.role === "user" ? "Developer Prompt" : "Cascade Copilot"}
                </span>
                <span className="text-gray-600 font-mono text-[9px]">{m.timestamp}</span>
              </div>

              {/* Message body */}
              <p className="text-xs leading-relaxed font-sans whitespace-pre-wrap">{m.text}</p>

              {/* Render Gemini's Thought blocks inside Windsurf panel */}
              {m.thought && (
                <div className="p-2 bg-black/40 border-l-2 border-cyan-500/20 text-[10px] text-gray-400 italic font-mono space-y-1 rounded">
                  <span className="font-bold text-[9px] text-[#00D1FF] block not-italic uppercase tracking-widest">Thought flow Tracker:</span>
                  <p>{m.thought}</p>
                </div>
              )}

              {/* Proposed IDE Action Cards if AI suggest steps */}
              {m.actions && m.actions.length > 0 && (
                <div className="pt-2 border-t border-[#1c2436] space-y-2">
                  <div className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">Suggested IDE Pipeline Actions:</div>
                  {m.actions.map(act => (
                    <div key={act.id} className="p-2.5 bg-gray-950 border border-[#232e44] rounded-lg text-[11px] font-mono space-y-2">
                      <div className="flex items-center justify-between text-[9px]">
                        <span className="text-indigo-400 font-bold uppercase">{act.type.replace("_", " ")}</span>
                        <span className={`px-1 rounded-sm uppercase font-bold tracking-tight ${
                          act.status === "success" ? "bg-emerald-950 text-emerald-400" :
                          act.status === "failed" ? "bg-rose-950 text-rose-400" :
                          act.status === "running" ? "bg-yellow-950 text-yellow-400 animate-pulse" :
                          "bg-gray-800 text-gray-400"
                        }`}>
                          {act.status}
                        </span>
                      </div>
                      <p className="text-[10px] text-gray-300 font-sans leading-tight font-medium">{act.description}</p>
                      {act.path && <span className="text-[10px] text-cyan-300 block font-semibold">File Path: {act.path}</span>}

                      {act.status === "pending" && (
                        <button
                          onClick={() => handleExecuteAiAction(m.id, act.id)}
                          className="w-full bg-[#00D1FF] hover:bg-cyan-400 text-black py-1 rounded text-[10px] font-bold uppercase font-sans tracking-wide transition-all"
                        >
                          Execute and Verify Action
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}

          {aiTyping && (
            <div className="flex items-center gap-2 p-3 bg-[#10141b] border border-[#1c2436] rounded-xl text-xs text-[#00D1FF]">
              <span className="w-1.5 h-1.5 bg-[#00D1FF] rounded-full animate-ping"></span>
              <span className="font-mono text-[10px] font-bold animate-pulse uppercase tracking-widest">Cascade thinking...</span>
            </div>
          )}

          <div ref={chatBottomRef}></div>
        </div>

        {/* Input Text Box with quick suggestions and command launcher */}
        <div className="p-4 border-t border-[#1a202c] bg-[#0e1116] space-y-3 relative">
          
          {/* Quick task triggers helper tags */}
          <div className="flex gap-1 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
            <button
              onClick={() => triggerCascadeQuery("Can you suggest a fast performance utility helper function for our dashboard?")}
              className="text-[9px] bg-[#161c24] hover:bg-gray-800 border border-[#212b3c] px-2 py-0.5 rounded-full text-gray-400 hover:text-white transition-all whitespace-nowrap whitespace-nowrap"
            >
              🚀 Suggest Helper API
            </button>
            <button
              onClick={() => triggerCascadeQuery("Analyze current files for compilation errors or syntax inconsistencies")}
              className="text-[9px] bg-[#161c24] hover:bg-gray-800 border border-[#212b3c] px-2 py-0.5 rounded-full text-gray-400 hover:text-white transition-all whitespace-nowrap whitespace-nowrap"
            >
              🛡 Check Code Quality
            </button>
            <button
              onClick={() => triggerCascadeQuery("Explain simulated git merge workflows and automatic override techniques")}
              className="text-[9px] bg-[#161c24] hover:bg-gray-800 border border-[#212b3c] px-2 py-0.5 rounded-full text-gray-400 hover:text-white transition-all whitespace-nowrap whitespace-nowrap"
            >
              📚 Explain Git Conflict Engine
            </button>
          </div>

          <div className="relative flex items-center">
            <input
              type="text"
              placeholder={`Ask Cascade (Ctrl+K help)...`}
              value={promptValue}
              onChange={(e) => setPromptValue(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") triggerCascadeQuery(promptValue); }}
              className="w-full bg-[#0a0d11] border border-[#212b3c] focus:border-[#00D1FF] rounded-xl py-3 pl-4 pr-12 text-xs text-white focus:outline-none focus:ring-1 focus:ring-[#00D1FF]/40 font-mono transition-all"
            />
            
            <button
              onClick={() => triggerCascadeQuery(promptValue)}
              className="absolute right-2 p-1.5 bg-[#00D1FF] hover:bg-cyan-400 text-black rounded-lg transition-all"
              title="Submit Prompt key"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* ----------------- Popover Interactive Modal for simulated GitHub logging ----------------- */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-[#12161a] border border-[#1f2633] p-6 rounded-2xl max-w-sm w-full space-y-4 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setShowLoginModal(false)}
              className="absolute top-4 right-4 p-1 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mx-auto text-cyan-400">
                <Github className="w-6 h-6 animate-bounce" />
              </div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">GitHub OAuth Handshake</h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                Unlock collaborative code staging repositories and switch compiling logs directly to Azure virtual containers.
              </p>
            </div>

            <div className="space-y-3 text-left">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block">GitHub Email / User Account</label>
                <input
                  type="text"
                  placeholder="e.g. slm91.sg@gmail.com"
                  value={temporaryGithubToken}
                  onChange={(e) => setTemporaryGithubToken(e.target.value)}
                  className="w-full bg-[#0a0d11] text-xs text-white p-2.5 rounded-lg border border-[#212b3c] focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block flex justify-between">
                  <span>Simulated Client Token</span>
                  <span className="text-[9px] text-[#00D1FF] font-black lowercase">(auto-populated)</span>
                </label>
                <input
                  type="password"
                  disabled
                  value="ghp_CollaborativeSafeSecret88219x8"
                  className="w-full bg-black/40 text-xs text-gray-500 p-2.5 rounded-lg border border-gray-800 cursor-not-allowed font-mono"
                />
              </div>

              <button
                onClick={handleSimulateGithubLogin}
                className="w-full bg-[#00D1FF] hover:bg-cyan-400 text-black py-2.5 rounded-xl text-xs font-bold font-mono tracking-wider transition-all shadow-lg shadow-cyan-500/10"
              >
                Authenticate with Server
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- Popover Interactive Ctrl+K Shortcuts Menu ----------------- */}
      {cmdKActive && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-start justify-center z-50 p-4 pt-20">
          <div className="bg-[#12161a] border border-[#1f2633] rounded-2xl max-w-md w-full overflow-hidden shadow-2xl animate-in fade-in slide-in-from-top-10 duration-200">
            
            {/* Search filter bar styling */}
            <div className="p-4 border-b border-[#1f2633] flex items-center gap-3 bg-black/20">
              <Search className="w-4 h-4 text-cyan-400" />
              <input
                type="text"
                placeholder="Search commands, files, or Git pipelines..."
                className="flex-1 bg-transparent text-xs text-white focus:outline-none font-mono"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    triggerCascadeQuery(e.currentTarget.value);
                    setCmdKActive(false);
                  }
                }}
              />
              <span className="text-[10px] px-2 py-0.5 bg-gray-800 text-gray-400 rounded-md font-mono border border-gray-700">ESC</span>
            </div>

            {/* List options suggested */}
            <div className="p-2.5 text-xs text-gray-300 divide-y divide-[#1a202c]">
              
              <div 
                onClick={() => { handleTemplateSelection("react-dashboard"); setCmdKActive(false); }}
                className="p-2 hover:bg-gray-800/40 rounded flex items-center justify-between cursor-pointer group"
              >
                <span className="font-medium group-hover:text-cyan-400">⚡ Switch to SaaS Analytics workspace template</span>
                <span className="text-[10px] text-gray-500 font-mono">Template</span>
              </div>

              <div 
                onClick={() => { handleTemplateSelection("galaxy-gravity-sim"); setCmdKActive(false); }}
                className="p-2 hover:bg-gray-800/40 rounded flex items-center justify-between cursor-pointer group"
              >
                <span className="font-medium group-hover:text-cyan-400">🪐 Switch to Gravity Planet Physics engine</span>
                <span className="text-[10px] text-gray-500 font-mono">Template</span>
              </div>

              <div 
                onClick={() => { runGitInit(); setCmdKActive(false); }}
                className="p-2 hover:bg-gray-800/40 rounded flex items-center justify-between cursor-pointer group"
              >
                <span className="font-medium group-hover:text-cyan-400">⚙ Initialize Collaborative Git Branch Tracker</span>
                <span className="text-[10px] text-gray-500 font-mono">Git init</span>
              </div>

              <div 
                onClick={() => { triggerCascadeQuery("Optimize code quality issues"); setCmdKActive(false); }}
                className="p-2 hover:bg-gray-800/40 rounded flex items-center justify-between cursor-pointer group"
              >
                <span className="font-medium group-hover:text-cyan-400">🔮 Ask Cascade to write a feature blueprint</span>
                <span className="text-[10px] text-gray-500 font-mono">Cascade</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- Popover Interactive Modal for simulated Laptop workspace imports ----------------- */}
      {showSimulatedImportModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-[#12161a] border border-[#1f2633] p-5 rounded-2xl max-w-md w-full space-y-4 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setShowSimulatedImportModal(false)}
              className="absolute top-4 right-4 p-1 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center space-y-1.5 animate-bounce-slow">
              <div className="w-10 h-10 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mx-auto text-cyan-400">
                <Laptop className="w-5 h-5 animate-pulse" />
              </div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Simulate Laptop Workspace Import</h3>
              <p className="text-[10px] text-gray-400 leading-relaxed max-w-xs mx-auto">
                No local file to drag? Input simulated file properties representing your laptop's Windsurf/VS Code local directories.
              </p>
            </div>

            <div className="space-y-3.5 text-left">
              <div className="space-y-1">
                <label className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block">Virtual File Name / Path</label>
                <input
                  type="text"
                  placeholder="e.g. laptop-notes.md"
                  value={importSimulatedName}
                  onChange={(e) => setImportSimulatedName(e.target.value)}
                  className="w-full bg-[#0a0d11] text-xs text-white p-2.5 border border-[#212b3c] rounded focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-bold text-[#00D1FF] uppercase tracking-widest block">
                  Code Content / Payload
                </label>
                <textarea
                  rows={5}
                  value={importSimulatedContent}
                  onChange={(e) => setImportSimulatedContent(e.target.value)}
                  placeholder="// Paste files or text content here to sync over the active socket pipeline..."
                  className="w-full bg-[#0a0d11] text-xs text-gray-300 p-2.5 rounded border border-[#212b3c] focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>

              <button
                onClick={handleSimulatedImportAndSync}
                className="w-full bg-[#00D1FF] hover:bg-cyan-400 text-black py-2.5 rounded-lg text-xs font-bold font-mono tracking-wider transition-all"
              >
                📥 Synchronize Code via Tunnel
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
