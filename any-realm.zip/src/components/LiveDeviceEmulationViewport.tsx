/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Smartphone, 
  Wifi, 
  Battery, 
  Signal, 
  Cpu, 
  Terminal, 
  Layers, 
  Play, 
  CheckCircle2, 
  Download, 
  Settings, 
  RefreshCw, 
  ShieldCheck,
  Code,
  HardDrive,
  AlertTriangle,
  Zap,
  Check
} from 'lucide-react';
import { AospComponent } from '../types';

interface LiveDeviceEmulationViewportProps {
  components: AospComponent[];
  deviceProps?: any;
}

type DeviceProfile = {
  id: string;
  name: string;
  resolution: string;
  aspectRatio: string;
  width: string;
  height: string;
  soc: string;
};

const DEVICE_PROFILES: DeviceProfile[] = [
  { id: 'moto_g', name: 'Moto G Stylus 5G', resolution: '1080 x 2400', aspectRatio: '20:9', width: 'w-[290px]', height: 'h-[580px]', soc: 'Snapdragon 6 Gen 1' },
  { id: 'pixel_8', name: 'Google Pixel 8 Pro', resolution: '1344 x 2992', aspectRatio: '20:9', width: 'w-[290px]', height: 'h-[600px]', soc: 'Google Tensor G3' },
  { id: 'galaxy_tab', name: 'Galaxy Tab S9 (Tablet)', resolution: '2560 x 1600', aspectRatio: '16:10', width: 'w-[360px]', height: 'h-[480px]', soc: 'Snapdragon 8 Gen 2' },
  { id: 'foldable', name: 'OnePlus Open (Foldable)', resolution: '2268 x 2440', aspectRatio: '5:6', width: 'w-[330px]', height: 'h-[490px]', soc: 'Snapdragon 8 Gen 2' },
];

export default function LiveDeviceEmulationViewport({ components, deviceProps }: LiveDeviceEmulationViewportProps) {
  const [activeTab, setActiveTab] = useState<'home' | 'settings' | 'terminal' | 'linux_distro'>('home');
  const [customAccent, setCustomAccent] = useState<'blue' | 'emerald' | 'purple' | 'amber'>('blue');
  const [darkTheme, setDarkTheme] = useState(true);
  const [selectedDevice, setSelectedDevice] = useState<DeviceProfile>(DEVICE_PROFILES[0]);
  
  // Monkey Wrench Stability Test States
  const [monkeyRunning, setMonkeyRunning] = useState(false);
  const [monkeyProgress, setMonkeyProgress] = useState(0);
  const [monkeyPassed, setMonkeyPassed] = useState(false);
  const [monkeyLogs, setMonkeyLogs] = useState<string[]>([]);

  const [buildingLinuxDistro, setBuildingLinuxDistro] = useState(false);
  const [linuxDistroBuilt, setLinuxDistroBuilt] = useState(false);
  const [simulatedLog, setSimulatedLog] = useState<string[]>([
    'AOSP Runtime initialized on GKI 2.0 (ARM64)',
    'SELinux enforcing mode active',
    'Display compositor: SurfaceFlinger 60fps VSync enabled'
  ]);

  const customComponentsCount = components.filter(c => c.isCustom).length;

  const handleToggleAccent = (accent: 'blue' | 'emerald' | 'purple' | 'amber') => {
    setCustomAccent(accent);
    setSimulatedLog(prev => [`[UI] Applied accent color theme: ${accent}`, ...prev.slice(0, 10)]);
  };

  const handleRunMonkeyWrenchTest = async () => {
    setMonkeyRunning(true);
    setMonkeyProgress(0);
    setMonkeyPassed(false);
    setMonkeyLogs(['[Monkey] Initializing UI Fuzzing & Stability Stress Run (1,000 events)...']);

    for (let i = 1; i <= 5; i++) {
      await new Promise(r => setTimeout(r, 600));
      setMonkeyProgress(i * 20);
      if (i === 1) setMonkeyLogs(prev => ['[Monkey] Injecting random motion events & multi-touch gestures...', ...prev]);
      if (i === 2) setMonkeyLogs(prev => ['[Monkey] Stress-testing SurfaceFlinger compositor & memory bounds...', ...prev]);
      if (i === 3) setMonkeyLogs(prev => ['[Monkey] Verifying SELinux policy denials & binder IPC transactions...', ...prev]);
      if (i === 4) setMonkeyLogs(prev => ['[Monkey] Checking APK activity lifecycle leaks & ANR watchdogs...', ...prev]);
    }

    setMonkeyRunning(false);
    setMonkeyPassed(true);
    setMonkeyLogs(prev => ['[SUCCESS] Monkey test completed: 1,000 events successfully dispatched. 0 ANRs, 0 crashes, 100% stability index.', ...prev]);
  };

  const handleBuildLinuxMobileDistro = async () => {
    setBuildingLinuxDistro(true);
    setSimulatedLog(prev => ['[Linux] Initiating mobile Linux distribution cross-compilation...', ...prev]);
    await new Promise(r => setTimeout(r, 2500));
    setBuildingLinuxDistro(false);
    setLinuxDistroBuilt(true);
    setSimulatedLog(prev => ['[Linux] SUCCESS: Mobile Linux distribution (Wayland + Phosh) compiled for target SoC.', ...prev]);
  };

  const accentColors = {
    blue: 'from-blue-600 to-indigo-600 text-blue-400 border-blue-500/40 bg-blue-500/10',
    emerald: 'from-emerald-600 to-teal-600 text-emerald-400 border-emerald-500/40 bg-emerald-500/10',
    purple: 'from-purple-600 to-violet-600 text-purple-400 border-purple-500/40 bg-purple-500/10',
    amber: 'from-amber-600 to-orange-600 text-amber-400 border-amber-500/40 bg-amber-500/10',
  };

  return (
    <div className="bg-[#111827] border border-[#1e293b] rounded-2xl p-6 shadow-xl flex flex-col gap-6" id="live-device-emulation-viewport">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-mono font-bold text-indigo-400 uppercase tracking-wider block">WYSIWYG Live Mobile Emulation &amp; Monkey Test Viewport</span>
            <h3 className="text-lg font-extrabold text-white">Dynamic Sizing Renderer &amp; Stability Suite</h3>
          </div>
        </div>

        {/* Device Profile Sizing Selector */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs">
            <span className="text-slate-400 font-mono">Profile:</span>
            <select
              value={selectedDevice.id}
              onChange={(e) => {
                const found = DEVICE_PROFILES.find(d => d.id === e.target.value);
                if (found) setSelectedDevice(found);
              }}
              className="bg-slate-900 text-white font-bold rounded px-2 py-1 outline-none border border-slate-700 cursor-pointer"
            >
              {DEVICE_PROFILES.map(d => (
                <option key={d.id} value={d.id}>{d.name} ({d.aspectRatio})</option>
              ))}
            </select>
          </div>

          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setActiveTab('home')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${activeTab === 'home' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Home UI
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${activeTab === 'settings' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Settings
            </button>
            <button
              onClick={() => setActiveTab('terminal')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${activeTab === 'terminal' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Logs
            </button>
            <button
              onClick={() => setActiveTab('linux_distro')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${activeTab === 'linux_distro' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
            >
              Linux Distro
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left: Real-time Emulated Device Frame with Dynamic Sizing */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center">
          <div className={`relative ${selectedDevice.width} ${selectedDevice.height} bg-slate-950 rounded-[40px] border-4 border-slate-800 shadow-2xl p-3 flex flex-col justify-between overflow-hidden transition-all duration-300`}>
            
            {/* Phone Speaker & Camera Notch */}
            <div className="absolute top-3 left-1/2 -translate-x-1/2 w-28 h-4 bg-slate-900 rounded-full z-30 flex items-center justify-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-slate-950 border border-slate-800"></div>
              <div className="w-8 h-1 bg-slate-800 rounded-full"></div>
            </div>

            {/* Android Status Bar */}
            <div className="pt-5 px-3 flex items-center justify-between text-[11px] font-mono text-slate-300 z-20 border-b border-slate-900/50 pb-2">
              <span className="font-bold">10:42</span>
              <div className="flex items-center gap-2">
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300">{selectedDevice.resolution}</span>
                <Signal className="w-3 h-3" />
                <Wifi className="w-3 h-3" />
                <Battery className="w-3 h-3 text-emerald-400" />
              </div>
            </div>

            {/* Phone Screen Viewport */}
            <div className={`flex-1 flex flex-col pt-3 pb-2 px-3 overflow-y-auto scrollbar-none z-10 transition-colors ${darkTheme ? 'bg-[#0b0f19] text-white' : 'bg-slate-100 text-slate-900'}`}>
              
              {activeTab === 'home' && (
                <div className="flex flex-col gap-4 animate-fadeIn">
                  {/* Device Header Widget */}
                  <div className={`p-4 rounded-2xl bg-gradient-to-br ${accentColors[customAccent]} border shadow-md`}>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider block opacity-80">Custom ROM Active</span>
                    <h4 className="text-sm font-extrabold mt-0.5">{selectedDevice.name}</h4>
                    <p className="text-[11px] opacity-90 mt-1">{selectedDevice.soc} • {selectedDevice.aspectRatio}</p>
                  </div>

                  {/* Quick Toggles */}
                  <div className="grid grid-cols-3 gap-2">
                    <div className="p-2.5 bg-slate-900/80 border border-slate-800 rounded-xl text-center">
                      <Cpu className="w-4 h-4 mx-auto text-blue-400 mb-1" />
                      <span className="text-[10px] font-mono block text-slate-300">GKI 2.0</span>
                    </div>
                    <div className="p-2.5 bg-slate-900/80 border border-slate-800 rounded-xl text-center">
                      <ShieldCheck className="w-4 h-4 mx-auto text-emerald-400 mb-1" />
                      <span className="text-[10px] font-mono block text-slate-300">Enforcing</span>
                    </div>
                    <div className="p-2.5 bg-slate-900/80 border border-slate-800 rounded-xl text-center">
                      <Layers className="w-4 h-4 mx-auto text-purple-400 mb-1" />
                      <span className="text-[10px] font-mono block text-slate-300">{components.length} Mods</span>
                    </div>
                  </div>

                  {/* Active Custom Components Section */}
                  <div>
                    <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-2">
                      Loaded OS Modules ({customComponentsCount} Custom)
                    </span>
                    <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                      {components.slice(0, 5).map((c, i) => (
                        <div key={i} className="p-2.5 bg-slate-900/90 border border-slate-800 rounded-xl flex items-center justify-between text-xs">
                          <div>
                            <span className="font-bold font-mono text-white block text-[11px]">{c.name}</span>
                            <span className="text-[10px] text-slate-400">{c.layer}</span>
                          </div>
                          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'settings' && (
                <div className="flex flex-col gap-3 animate-fadeIn text-xs">
                  <h4 className="font-bold text-sm mb-1">ROM Customizer Settings</h4>
                  
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <span>Dark Theme</span>
                    <input 
                      type="checkbox" 
                      checked={darkTheme} 
                      onChange={() => setDarkTheme(!darkTheme)} 
                      className="accent-blue-600 w-4 h-4 cursor-pointer"
                    />
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="block mb-2 font-semibold">Accent Color Theme</span>
                    <div className="flex gap-2">
                      <button onClick={() => handleToggleAccent('blue')} className={`w-6 h-6 rounded-full bg-blue-600 ${customAccent === 'blue' ? 'ring-2 ring-white' : ''}`} />
                      <button onClick={() => handleToggleAccent('emerald')} className={`w-6 h-6 rounded-full bg-emerald-600 ${customAccent === 'emerald' ? 'ring-2 ring-white' : ''}`} />
                      <button onClick={() => handleToggleAccent('purple')} className={`w-6 h-6 rounded-full bg-purple-600 ${customAccent === 'purple' ? 'ring-2 ring-white' : ''}`} />
                      <button onClick={() => handleToggleAccent('amber')} className={`w-6 h-6 rounded-full bg-amber-600 ${customAccent === 'amber' ? 'ring-2 ring-white' : ''}`} />
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-[10px] font-mono text-slate-400 block mb-1">Target SoC Architecture</span>
                    <span className="font-bold text-white">{selectedDevice.soc}</span>
                  </div>
                </div>
              )}

              {activeTab === 'terminal' && (
                <div className="flex flex-col gap-2 font-mono text-[10px] text-emerald-400 bg-slate-950 p-3 rounded-xl border border-slate-900 flex-1 overflow-y-auto">
                  <span className="font-bold text-slate-400">// Emulated Kernel Log ({selectedDevice.name})</span>
                  {simulatedLog.map((log, idx) => (
                    <div key={idx} className="leading-tight">{log}</div>
                  ))}
                </div>
              )}

              {activeTab === 'linux_distro' && (
                <div className="flex flex-col gap-3 animate-fadeIn text-xs">
                  <h4 className="font-bold text-sm text-emerald-400 flex items-center gap-1.5">
                    <HardDrive className="w-4 h-4" /> Linux Mobile Distro
                  </h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Build a complete GNU/Linux mobile operating system image (Wayland compositor + Phosh shell) for {selectedDevice.name}.
                  </p>

                  {linuxDistroBuilt ? (
                    <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-center">
                      <CheckCircle2 className="w-6 h-6 text-emerald-400 mx-auto mb-1" />
                      <span className="font-bold text-white block text-xs">Linux Distro Ready</span>
                      <a href="#download" className="text-[10px] text-emerald-400 underline mt-1 block">Download rootfs.img &amp; boot.img</a>
                    </div>
                  ) : (
                    <button
                      onClick={handleBuildLinuxMobileDistro}
                      disabled={buildingLinuxDistro}
                      className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                    >
                      {buildingLinuxDistro ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          Cross-Compiling...
                        </>
                      ) : (
                        <>
                          <Download className="w-3.5 h-3.5" />
                          Build Linux Distro
                        </>
                      )}
                    </button>
                  )}
                </div>
              )}

            </div>

            {/* Android Navigation Bar (Home, Back, Recents) */}
            <div className="pt-2 px-6 flex items-center justify-between text-slate-500 z-20">
              <div className="w-3 h-3 rounded-sm border border-slate-600"></div>
              <div className="w-8 h-1 bg-slate-600 rounded-full"></div>
              <div className="w-3 h-3 rounded-full border border-slate-600"></div>
            </div>

          </div>
        </div>

        {/* Right: Monkey Wrench Stability Suite & Build Options */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          
          {/* Monkey Wrench Stability & Safety Test Suite */}
          <div className="bg-slate-950 border border-indigo-500/30 rounded-xl p-5 shadow-lg relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-indigo-600/20 text-indigo-400">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Monkey Wrench Stability &amp; Safety Test Suite</h4>
                  <p className="text-xs text-slate-400">Pre-compilation stress test &amp; UI fuzzing (1,000 randomized events)</p>
                </div>
              </div>

              {monkeyPassed && (
                <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Stability Verified
                </span>
              )}
            </div>

            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Before flashing or building final binaries, run the rigorous Monkey Wrench test to ensure zero UI overflows, memory leaks, or binder deadlocks across {selectedDevice.name} ({selectedDevice.resolution}).
            </p>

            {monkeyRunning && (
              <div className="mb-4">
                <div className="flex justify-between text-xs font-mono text-indigo-300 mb-1">
                  <span>Executing Fuzz &amp; Stress Test...</span>
                  <span>{monkeyProgress}%</span>
                </div>
                <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                  <div className="h-full bg-indigo-600 transition-all duration-500" style={{ width: `${monkeyProgress}%` }}></div>
                </div>
              </div>
            )}

            {monkeyLogs.length > 0 && (
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 font-mono text-[11px] text-emerald-400 mb-4 max-h-32 overflow-y-auto">
                {monkeyLogs.map((log, idx) => (
                  <div key={idx} className="leading-relaxed">{log}</div>
                ))}
              </div>
            )}

            <button
              onClick={handleRunMonkeyWrenchTest}
              disabled={monkeyRunning}
              className={`w-full py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                monkeyRunning
                  ? 'bg-indigo-600/50 text-white cursor-wait'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white'
              }`}
            >
              {monkeyRunning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Running Monkey Wrench Stress Suite...
                </>
              ) : monkeyPassed ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  Re-Run Monkey Wrench Stability Suite
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Run Monkey Wrench Safety &amp; Stability Test
                </>
              )}
            </button>
          </div>

          {/* Live Build Property Binding Info */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-5">
            <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <Settings className="w-4 h-4 text-blue-400" /> Live Build Property Binding
            </h4>
            <div className="grid grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                <span className="text-slate-400 block text-[10px]">Target Device Model</span>
                <span className="text-white font-bold">{selectedDevice.name}</span>
              </div>
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                <span className="text-slate-400 block text-[10px]">Display Resolution</span>
                <span className="text-emerald-400 font-bold">{selectedDevice.resolution}</span>
              </div>
            </div>
          </div>

          {/* Linux Mobile Distribution Builder */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-5">
            <h4 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-emerald-400" /> Linux Mobile Distribution Builder
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Cross-compile a full Linux mobile distribution (Wayland compositor + Phosh shell) tailored for {selectedDevice.name}.
            </p>
            <button
              onClick={handleBuildLinuxMobileDistro}
              disabled={buildingLinuxDistro}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg cursor-pointer transition-all"
            >
              {buildingLinuxDistro ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Building Linux Mobile Distro...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Build Linux Mobile Distribution
                </>
              )}
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}

