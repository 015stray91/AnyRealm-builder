import React, { useState } from 'react';
import { Network, Server, Zap, RefreshCw, CheckCircle2 } from 'lucide-react';

export default function MatrixModuleStudio() {
  const [selectedKde, setSelectedKde] = useState<string>('kde-plasma-desktop');
  const [mountMethod, setMountMethod] = useState<'zeromount' | 'hybridmount'>('zeromount');
  const [useSusfs, setUseSusfs] = useState<boolean>(true);
  const [isIntegrating, setIsIntegrating] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([]);

  const handleIntegrate = () => {
    setIsIntegrating(true);
    setLogs([`[*] Initializing Matrix Module: Fusing ${selectedKde} into root...`]);

    setTimeout(() => {
      setLogs(prev => [...prev, `[+] Applying ${mountMethod} overlay configurations...`]);
    }, 800);

    setTimeout(() => {
      if (useSusfs) {
        setLogs(prev => [...prev, `[+] Configuring SusFS hidden object filesystem for ${selectedKde}...`]);
      }
    }, 1600);

    setTimeout(() => {
      setLogs(prev => [...prev, `[SUCCESS] ${selectedKde} fused via ${mountMethod} with SusFS active. Matrix Module ready.`]);
      setIsIntegrating(false);
    }, 2400);
  };

  return (
    <div className="bg-[#0f1225] p-6 rounded-xl border border-indigo-900/30 flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
          <Server className="text-white w-5 h-5" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">Matrix Module Studio</h2>
          <p className="text-xs text-slate-400">Advanced fusion of desktop environments with low-level mount technologies.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Environment Selection */}
        <div className="bg-[#13162d] p-4 rounded-lg border border-indigo-900/40">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">Select Component</h3>
          <select 
            value={selectedKde}
            onChange={(e) => setSelectedKde(e.target.value)}
            className="w-full bg-[#0a0d1d] text-slate-200 border border-indigo-500/30 rounded px-3 py-2 text-xs"
          >
            <option value="kde-plasma-desktop">KDE Plasma Desktop</option>
            <option value="kde-plasma-mobile">KDE Plasma Mobile</option>
            <option value="kde-network-tools">KDE Network Tools</option>
          </select>
        </div>

        {/* Mount Configuration */}
        <div className="bg-[#13162d] p-4 rounded-lg border border-indigo-900/40">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">Mount/Fusion Method</h3>
          <div className="flex gap-2">
            <button
              onClick={() => setMountMethod('zeromount')}
              className={`flex-1 p-2 rounded border text-xs font-bold transition-all ${mountMethod === 'zeromount' ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300' : 'bg-slate-900 border-slate-800 text-slate-400'}`}
            >
              Zero Mount
            </button>
            <button
              onClick={() => setMountMethod('hybridmount')}
              className={`flex-1 p-2 rounded border text-xs font-bold transition-all ${mountMethod === 'hybridmount' ? 'bg-purple-600/20 border-purple-500 text-purple-300' : 'bg-slate-900 border-slate-800 text-slate-400'}`}
            >
              Hybrid Mount
            </button>
          </div>
        </div>
      </div>

      <label className="flex items-center gap-3 cursor-pointer bg-[#13162d] p-4 rounded-lg border border-indigo-900/40">
        <input type="checkbox" checked={useSusfs} onChange={() => setUseSusfs(!useSusfs)} className="accent-indigo-500" />
        <span className="text-xs font-semibold text-slate-300">
          Enable SusFS Hidden Object Protection
        </span>
      </label>

      <button
        onClick={handleIntegrate}
        disabled={isIntegrating}
        className="flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-sm font-bold rounded-lg shadow-lg shadow-indigo-500/20 transition-all disabled:opacity-50"
      >
        {isIntegrating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
        {isIntegrating ? 'Fusing...' : 'Execute Matrix Module Fusion'}
      </button>

      {/* Logs */}
      {logs.length > 0 && (
        <div className="bg-black/50 p-4 rounded-lg border border-slate-800 font-mono text-[10px] text-slate-400 h-24 overflow-y-auto">
          {logs.map((log, i) => (
            <div key={i} className="mb-1">{log}</div>
          ))}
        </div>
      )}
    </div>
  );
}
