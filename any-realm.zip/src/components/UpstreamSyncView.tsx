import React, { useState } from 'react';
import { GitBranch, RefreshCw, AlertTriangle, FileCheck, Code, Zap } from 'lucide-react';

export default function UpstreamSyncView() {
  const [syncTarget, setSyncTarget] = useState<'5.10' | '5.15'>('5.10');
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'synced'>('idle');

  const handleSync = () => {
    setIsSyncing(true);
    setSyncStatus('syncing');
    setTimeout(() => {
      setIsSyncing(false);
      setSyncStatus('synced');
    }, 2000);
  };

  return (
    <div className="bg-[#111827] border border-[#1e293b] rounded-2xl p-6 shadow-xl flex flex-col gap-6">
      <div className="flex justify-between items-center border-b border-slate-900 pb-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <GitBranch className="text-cyan-500 w-6 h-6" /> Upstream Sync (Linaro Kernel)
        </h2>
        <select 
          value={syncTarget}
          onChange={(e) => setSyncTarget(e.target.value as any)}
          className="bg-slate-950 text-slate-200 border border-slate-800 rounded px-3 py-1 text-xs"
        >
          <option value="5.10">Kernel 5.10 (Linaro)</option>
          <option value="5.15">Kernel 5.15 (Linaro)</option>
        </select>
      </div>

      <div className="bg-slate-950 p-6 rounded-xl border border-slate-900 text-slate-400 font-mono text-xs">
        <p className="mb-4">Diffing current project modules against Linaro {syncTarget} sources...</p>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-emerald-400">
            <span>drivers/gpu/drm/colorsensor/colorsensor_driver.c</span>
            <span className="text-[10px] bg-emerald-950/30 px-2 py-0.5 rounded">MODULAR_MATCH</span>
          </div>
          <div className="flex items-center justify-between text-amber-400">
            <span>frameworks/base/services/core/java/ColorSensorService.java</span>
            <span className="text-[10px] bg-amber-950/30 px-2 py-0.5 rounded">NON_DESTRUCTIVE_DELTA</span>
          </div>
        </div>
      </div>

      <button
        onClick={handleSync}
        disabled={isSyncing || syncStatus === 'synced'}
        className="flex items-center justify-center gap-2 px-6 py-3 bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-bold rounded-lg transition-all disabled:opacity-50"
      >
        {isSyncing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
        {isSyncing ? 'Syncing...' : syncStatus === 'synced' ? 'Sync Complete' : 'Generate Patch for Submission'}
      </button>

      {syncStatus === 'synced' && (
        <div className="p-4 bg-emerald-950/20 border border-emerald-500/20 rounded-lg flex items-center gap-3 text-emerald-400 text-xs">
          <FileCheck className="w-5 h-5" />
          Patch file 'linaro_upstream_sync_{syncTarget}.patch' ready for submission.
        </div>
      )}
    </div>
  );
}
