import React, { useState } from 'react';
import { Cpu, Cloud, GitBranch, Zap, RefreshCw, Volume2 } from 'lucide-react';
import { speakText } from '../lib/speech';

export default function QualcommKernelPortingStudio() {
  const [targetSoC, setTargetSoC] = useState<string>('sm8450');
  const [kernelVersion, setKernelVersion] = useState<string>('5.10');
  const [androidVersion, setAndroidVersion] = useState<string>('15');
  const [isPorting, setIsPorting] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([]);

  const handlePort = () => {
    setIsPorting(true);
    setLogs([`[*] Initializing Cloud Porting Pipeline for ${targetSoC}...`]);

    setTimeout(() => {
      setLogs(prev => [...prev, `[+] Pulling Linaro-style upstream kernel sources (${kernelVersion})...`]);
    }, 800);

    setTimeout(() => {
      setLogs(prev => [...prev, `[+] Applying ${targetSoC} board-specific overlays and platform patches...`]);
    }, 1600);

    setTimeout(() => {
      setLogs(prev => [...prev, `[+] Fusing Android ${androidVersion} platform configurations...`]);
    }, 2400);

    setTimeout(() => {
      setLogs(prev => [...prev, `[SUCCESS] Porting project prepared for ${targetSoC} (Kernel ${kernelVersion}, Android ${androidVersion}).`]);
      setIsPorting(false);
    }, 3200);
  };

  return (
    <div className="bg-[#0f1225] p-6 rounded-xl border border-blue-900/30 flex flex-col gap-6" id="qualcomm-porting-studio">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
          <Cloud className="text-white w-5 h-5" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">Qualcomm Porting Factory</h2>
          <p className="text-xs text-slate-400">Cloud-based kernel porting and platform upgrades for Qualcomm devices.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#13162d] p-4 rounded-lg border border-blue-900/40">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Target SoC</h3>
          <select value={targetSoC} onChange={(e) => setTargetSoC(e.target.value)} className="w-full bg-[#0a0d1d] text-slate-200 border border-blue-500/30 rounded px-3 py-2 text-xs">
            <option value="sm8450">Snapdragon 8 Gen 1 (sm8450)</option>
            <option value="sm8350">Snapdragon 888 (sm8350)</option>
            <option value="sm7250">Snapdragon 765G (sm7250)</option>
          </select>
        </div>
        <div className="bg-[#13162d] p-4 rounded-lg border border-blue-900/40">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Kernel Target</h3>
          <select value={kernelVersion} onChange={(e) => setKernelVersion(e.target.value)} className="w-full bg-[#0a0d1d] text-slate-200 border border-blue-500/30 rounded px-3 py-2 text-xs">
            <option value="5.10">Kernel 5.10 (LTS)</option>
            <option value="5.15">Kernel 5.15 (LTS)</option>
            <option value="6.1">Kernel 6.1 (Mainline)</option>
          </select>
        </div>
        <div className="bg-[#13162d] p-4 rounded-lg border border-blue-900/40">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Android Ver</h3>
          <select value={androidVersion} onChange={(e) => setAndroidVersion(e.target.value)} className="w-full bg-[#0a0d1d] text-slate-200 border border-blue-500/30 rounded px-3 py-2 text-xs">
            <option value="14">Android 14</option>
            <option value="15">Android 15</option>
          </select>
        </div>
      </div>

      <button
        onClick={handlePort}
        disabled={isPorting}
        className="flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-sm font-bold rounded-lg shadow-lg shadow-blue-500/20 transition-all disabled:opacity-50"
      >
        {isPorting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <GitBranch className="w-4 h-4" />}
        {isPorting ? 'Porting...' : 'Initialize Cloud Porting Pipeline'}
      </button>

      {logs.length > 0 && (
        <div className="bg-black/50 p-4 rounded-lg border border-slate-800 font-mono text-[10px] text-slate-400 h-24 overflow-y-auto">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] uppercase font-bold text-slate-500">Log Output</span>
            <button 
              onClick={() => speakText(logs.join('. '))}
              className="text-slate-500 hover:text-white transition-colors"
              title="Speak Logs"
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>
          {logs.map((log, i) => (
            <div key={i} className="mb-1">{log}</div>
          ))}
        </div>
      )}
    </div>
  );
}
