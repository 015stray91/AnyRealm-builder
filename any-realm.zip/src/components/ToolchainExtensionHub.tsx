/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Wrench, 
  Terminal, 
  Settings, 
  Cpu, 
  Layers, 
  Hammer, 
  Play, 
  Download, 
  Info, 
  Check, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  Plus, 
  Trash2, 
  RefreshCw, 
  FileCode, 
  Package, 
  Code, 
  FileText, 
  Activity, 
  Boxes, 
  Link,
  ChevronRight,
  ShieldCheck,
  Zap,
  Globe,
  Search,
  MessageSquare,
  Send,
  GitBranch,
  Sliders,
  Folder,
  FolderOpen,
  Eye,
  Minimize2,
  Maximize2,
  ChevronDown,
  Server,
  LifeBuoy,
  Mic,
  Volume2,
  Bot
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { speakText, startListening } from '../lib/speech';

import MatrixModuleStudio from './MatrixModuleStudio';
import CustomRecoveryStudio from './CustomRecoveryStudio';
import OnDeviceAgentConfigurator from './OnDeviceAgentConfigurator';

// Extension interface
interface ToolchainExtension {
  id: string;
  name: string;
  identifier: string;
  version: string;
  category: 'compiler' | 'utility' | 'firmware' | 'security' | 'desktop_env';
  status: 'active' | 'standby' | 'compiling' | 'conflict';
  arch: 'arm64' | 'x86_64' | 'universal' | 'riscv64';
  sizeBytes: number;
  description: string;
  binaries: string[];
  dependencies: string[];
  author: string;
}

// Workspace File interface
interface ExtensionFile {
  name: string;
  path: string;
  content: string;
  language: 'c' | 'makefile' | 'json' | 'shell';
}

// AI Message interface
interface AIMessage {
  id: string;
  sender: 'user' | 'assistant';
  timestamp: string;
  text: string;
  suggestedAction?: {
    type: 'apply_diff' | 'run_build' | 'install_binary';
    label: string;
    targetPath?: string;
    newContent?: string;
  };
}

export default function ToolchainExtensionHub() {
  // 1. Sidebar Activity State
  const [activeActivity, setActiveActivity] = useState<'explorer' | 'extensions' | 'ai' | 'settings' | 'matrix' | 'recovery' | 'agent'>('explorer');
  const [bottomTab, setBottomTab] = useState<'terminal' | 'build_output' | 'problems'>('terminal');

  // Speech State
  const [isSpeechEnabled, setIsSpeechEnabled] = useState(false);
  const recognitionRef = useRef<any>(null);

  const toggleSpeech = () => {
    if (isSpeechEnabled) {
      if (recognitionRef.current) recognitionRef.current.stop();
      setIsSpeechEnabled(false);
      speakText("Speech disabled.");
    } else {
      recognitionRef.current = startListening((text) => console.log(text), (err) => console.error(err));
      setIsSpeechEnabled(true);
      speakText("Speech enabled.");
    }
  };

  // 2. Binary extensions database
  const [extensions, setExtensions] = useState<ToolchainExtension[]>([
    {
      id: 'llvm-arm64',
      name: 'GNU LLVM / Clang Arm64 Cross-Toolchain',
      identifier: 'realm.toolchain.llvm_arm64',
      version: '17.0.6',
      category: 'compiler',
      status: 'active',
      arch: 'arm64',
      sizeBytes: 184549376,
      description: 'Cross-compiler toolchain containing Clang, LLD, and LLVM binaries optimized for direct kernel GKI/AOSP compilation.',
      binaries: ['aarch64-linux-gnu-clang', 'aarch64-linux-gnu-ld', 'llvm-objdump', 'llvm-strip'],
      dependencies: ['libc6-dev', 'libssl-dev'],
      author: 'GNU Core Maintainers'
    },
    {
      id: 'rust-android',
      name: 'Rust Android Toolchain (GKI-Ready)',
      identifier: 'realm.toolchain.rust_android',
      version: '1.78.0',
      category: 'compiler',
      status: 'active',
      arch: 'arm64',
      sizeBytes: 294120394,
      description: 'Statically optimized Rust compiler backend with target registry configured for aarch64-linux-android userspace system daemons.',
      binaries: ['rustc-android', 'cargo-android', 'bindgen-gki'],
      dependencies: ['llvm-arm64'],
      author: 'Mozilla Rust Android SIG'
    },
    {
      id: 'busybox-static',
      name: 'BusyBox Multi-call Static Utilities Pack',
      identifier: 'realm.utility.busybox_static',
      version: '1.36.1',
      category: 'utility',
      status: 'active',
      arch: 'universal',
      sizeBytes: 1245902,
      description: 'Combines tiny versions of over 300 common UNIX utilities into a single, statically linked binary. Resolves missing system userland binaries.',
      binaries: ['busybox', 'busybox-sed', 'busybox-awk', 'busybox-grep'],
      dependencies: [],
      author: 'Denys Vlasenko & Contributors'
    },
    {
      id: 'android-image-kitchen-bin',
      name: 'AIK-Linux Low-level Ramdisk binaries',
      identifier: 'realm.utility.aik_binaries',
      version: '3.8.0',
      category: 'firmware',
      status: 'active',
      arch: 'x86_64',
      sizeBytes: 4194304,
      description: 'Low-latency native binaries including mkbootimg, unpackbootimg, and minigzip for parsing, decompiling, and modifying boot/recovery partitions.',
      binaries: ['unpackbootimg', 'mkbootimg', 'minigzip-static'],
      dependencies: ['busybox-static'],
      author: 'osm0sis'
    },
    {
      id: 'magiskpolicy-sepolicy',
      name: 'magiskpolicy SELinux Rule Compiler',
      identifier: 'realm.security.magiskpolicy',
      version: '27.0',
      category: 'security',
      status: 'standby',
      arch: 'arm64',
      sizeBytes: 850392,
      description: 'Pre-compiled security engine standalone utility used to inject direct permissive/enforced security context transitions into binary sepolicy rules.',
      binaries: ['magiskpolicy', 'sepolicy-inject'],
      dependencies: [],
      author: 'topjohnwu'
    },
    {
      id: 'kde-plasma-desktop',
      name: 'KDE Plasma Desktop Environment',
      identifier: 'realm.desktop.plasma_desktop',
      version: '6.1.0',
      category: 'desktop_env',
      status: 'standby',
      arch: 'universal',
      sizeBytes: 850493760,
      description: 'Full KDE Plasma desktop environment optimized for AOSP container fusion. Includes KWin, Plasma Shell, and default breeze themes.',
      binaries: ['plasmashell', 'kwin_wayland'],
      dependencies: ['busybox-static'],
      author: 'KDE Community'
    },
    {
      id: 'kde-plasma-mobile',
      name: 'KDE Plasma Mobile Shell',
      identifier: 'realm.desktop.plasma_mobile',
      version: '6.1.0',
      category: 'desktop_env',
      status: 'standby',
      arch: 'arm64',
      sizeBytes: 540493760,
      description: 'Touch-optimized Plasma shell for mobile form factors. Includes mobile-specific home screens, shell, and input agents.',
      binaries: ['plasmamobile_shell', 'kwin_wayland'],
      dependencies: ['busybox-static'],
      author: 'KDE Community'
    },
    {
      id: 'kde-network-tools',
      name: 'KDE Network Management Tools',
      identifier: 'realm.utility.kde_network',
      version: '6.1.0',
      category: 'utility',
      status: 'standby',
      arch: 'universal',
      sizeBytes: 45093760,
      description: 'Network management utilities for Plasma, including plasmoid network manager and KNetAttach.',
      binaries: ['plasma-nm', 'knetattach'],
      dependencies: ['busybox-static'],
      author: 'KDE Community'
    }
  ]);

  // Selected extension inside the "extensions" side panel
  const [selectedExt, setSelectedExt] = useState<ToolchainExtension>(extensions[0]);

  // 3. Virtual workspace files explorer
  const [workspaceFiles, setWorkspaceFiles] = useState<ExtensionFile[]>([
    {
      name: 'main.c',
      path: 'src/main.c',
      language: 'c',
      content: `#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n\n// AnyRealm stand-alone core diagnostic tool\nint main(int argc, char *argv[]) {\n    printf("==========================================\\n");\n    printf("   ANYREALM VIRTUAL CORE RUNTIME v1.0.5   \\n");\n    printf("==========================================\\n");\n    \n    if (argc < 2) {\n        printf("Usage: %s [run-diagnostics | --status | --help]\\n", argv[0]);\n        return 1;\n    }\n    \n    if (strcmp(argv[1], "--status") == 0) {\n        printf("Environment status: ONLINE\\n");\n        printf("GKI Kernel integration: ATTACHED\\n");\n        printf("Overlay status: READ-WRITE-PERSISTENT\\n");\n        return 0;\n    }\n    \n    if (strcmp(argv[1], "run-diagnostics") == 0) {\n        printf("[*] Instantiating low-level sensor board test...\\n");\n        printf("[OK] Root filesystem fuser mounted flawlessly.\\n");\n        printf("[OK] LLVM linker structures generated safely.\\n");\n        printf("[SUCCESS] standalone compilation block parsed completely.\\n");\n        return 0;\n    }\n    \n    printf("Error: Unsupported parameter '%s'\\n", argv[1]);\n    return 1;\n}`
    },
    {
      name: 'Makefile',
      path: 'Makefile',
      language: 'makefile',
      content: `CC = aarch64-linux-gnu-gcc\nCFLAGS = -O3 -Wall -static\nTARGET = out/bin/realm_diagnostic_tool\n\nall: clean\n\tmkdir -p out/bin\n\t$(CC) $(CFLAGS) src/main.c -o $(TARGET)\n\nclean:\n\trm -rf out/`
    },
    {
      name: 'extension_manifest.json',
      path: 'extension_manifest.json',
      language: 'json',
      content: `{\n  "name": "AnyRealm Diagnostics Companion",\n  "identifier": "realm.addon.diagnostics_core",\n  "version": "1.0.5",\n  "category": "utility",\n  "arch": "arm64",\n  "binaries": [\n    "realm_diagnostic_tool"\n  ],\n  "dependencies": [\n    "busybox-static"\n  ],\n  "description": "Cross-compiled standalone diagnostic binary overlay to audit root partition fuser state changes in real-time."\n}`
    }
  ]);

  const [activeFile, setActiveFile] = useState<ExtensionFile>(workspaceFiles[0]);
  const [editorCode, setEditorCode] = useState<string>(workspaceFiles[0].content);

  // Sync editor when active file changes
  useEffect(() => {
    setEditorCode(activeFile.content);
  }, [activeFile]);

  // Sync back edits to workspace files
  const handleEditorChange = (val: string) => {
    setEditorCode(val);
    setWorkspaceFiles(prev => prev.map(f => f.path === activeFile.path ? { ...f, content: val } : f));
  };

  // 4. Windsurf Cascade AI Companion state
  const [aiChat, setAiChat] = useState<AIMessage[]>([
    {
      id: 'init-msg',
      sender: 'assistant',
      timestamp: '06:18:22 AM',
      text: "Hi! I am **Cascade**, your Windsurf AI co-pilot. I am pre-wired with your ARM64/x86_64 toolchain compiler parameters. Ask me to write code, compile standalone utilities, inject permission scripts, or add more missing tools to the container overlay."
    }
  ]);
  const [aiInput, setAiInput] = useState('');
  const [isAiTyping, setIsAiTyping] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [aiChat, isAiTyping]);

  // Bottom terminal execution logs state
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    'realm-user@anyrealm-os-container:~/workspace$ aosp-build-daemon --version',
    'AnyRealm Standalone Toolchain Daemon version 2.4.9-GKI',
    'Installed Toolchains: LLVM/Clang v17.0.6, Rust v1.78.0, GCC aarch64-linux-gnu cross-compilers',
    'Active partition nodes: /system (SquashFS R/O Overlay), /vendor (Ext4 R/W)',
    'realm-user@anyrealm-os-container:~/workspace$ '
  ]);
  const [terminalInput, setTerminalInput] = useState('');

  // GCC Compiler state
  const [buildLogs, setBuildLogs] = useState<string[]>([]);
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildProblems, setBuildProblems] = useState<string[]>([]);

  // Execute terminal input
  const handleTerminalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!terminalInput.trim()) return;

    const cmd = terminalInput.trim();
    setTerminalLogs(prev => [...prev, `realm-user@anyrealm-os-container:~/workspace$ ${cmd}`]);

    setTimeout(() => {
      let output: string[] = [];
      if (cmd === 'clear') {
        setTerminalLogs([]);
        setTerminalInput('');
        return;
      } else if (cmd === 'ls' || cmd === 'ls -la') {
        output = [
          'total 16',
          'drwxr-xr-x  3 realm-user realm-user  4096 Jul 21 06:15 .',
          'drwxr-xr-x 12 realm-user realm-user  4096 Jul 21 06:15 ..',
          '-rw-r--r--  1 realm-user realm-user   235 Jul 21 06:15 Makefile',
          '-rw-r--r--  1 realm-user realm-user   340 Jul 21 06:15 extension_manifest.json',
          'drwxr-xr-x  2 realm-user realm-user  4096 Jul 21 06:15 src'
        ];
      } else if (cmd.startsWith('cat ')) {
        const targetName = cmd.replace('cat ', '').trim();
        const fileObj = workspaceFiles.find(f => f.name === targetName || f.path === targetName);
        if (fileObj) {
          output = fileObj.content.split('\n');
        } else {
          output = [`cat: ${targetName}: No such file or directory`];
        }
      } else if (cmd === 'make' || cmd === 'make all') {
        handleTriggerBuild();
        setTerminalInput('');
        return;
      } else if (cmd === './out/bin/realm_diagnostic_tool --status') {
        output = [
          '==========================================',
          '   ANYREALM VIRTUAL CORE RUNTIME v1.0.5   ',
          '==========================================',
          'Environment status: ONLINE',
          'GKI Kernel integration: ATTACHED',
          'Overlay status: READ-WRITE-PERSISTENT'
        ];
      } else if (cmd === './out/bin/realm_diagnostic_tool run-diagnostics') {
        output = [
          '==========================================',
          '   ANYREALM VIRTUAL CORE RUNTIME v1.0.5   ',
          '==========================================',
          '[*] Instantiating low-level sensor board test...',
          '[OK] Root filesystem fuser mounted flawlessly.',
          '[OK] LLVM linker structures generated safely.',
          '[SUCCESS] standalone compilation block parsed completely.'
        ];
      } else {
        output = [
          `bash: ${cmd.split(' ')[0]}: command not found`,
          `Hint: Try running 'make', 'ls', 'cat src/main.c', or executing binary './out/bin/realm_diagnostic_tool --status'.`
        ];
      }

      setTerminalLogs(prev => [...prev, ...output, 'realm-user@anyrealm-os-container:~/workspace$ ']);
    }, 150);

    setTerminalInput('');
  };

  // Trigger compiler make compilation pipeline
  const handleTriggerBuild = () => {
    if (isBuilding) return;
    setIsBuilding(true);
    setBottomTab('build_output');
    speakText("Starting compiler build pipeline.");
    setBuildLogs([
      '[*] Invoking Makefile compiler build targets in daemon...',
      `$ aarch64-linux-gnu-gcc -O3 -Wall -static src/main.c -o out/bin/realm_diagnostic_tool`,
      '[*] Resolving statically-linked system-dependent references...',
      '[*] Invoking linker strip: "llvm-strip out/bin/realm_diagnostic_tool"'
    ]);
    setBuildProblems([]);

    setTimeout(() => {
      setBuildLogs(prev => [
        ...prev,
        '[*] Verification Check: static ELF executable headers checked.',
        '[*] Binary size: 138.4 KB | Target layout architecture: ARM64-GKI-AOSP',
        '[SUCCESS] Standalone binary output finalized inside out/bin/realm_diagnostic_tool',
        '[*] Synchronizing writable SquashFS partition overlays...'
      ]);
      setIsBuilding(false);
      speakText("Build completed successfully.");

      // Log back in terminal tab too
      setTerminalLogs(prev => [
        ...prev,
        `make all`,
        `aarch64-linux-gnu-gcc -O3 -Wall -static src/main.c -o out/bin/realm_diagnostic_tool`,
        `[SUCCESS] standalone compiled out/bin/realm_diagnostic_tool ready for runtime.`,
        'realm-user@anyrealm-os-container:~/workspace$ '
      ]);
    }, 1800);
  };

  // Handle preset quick assistant commands
  const handleTriggerPresetChat = (promptType: 'sensory' | 'gdb' | 'sepolicy') => {
    let userPromptText = '';
    let assistantReply = '';
    let suggestedAction: AIMessage['suggestedAction'] = undefined;

    if (promptType === 'sensory') {
      userPromptText = "Help me write a hardware sensory bypass hook in C";
      assistantReply = "I have drafted a high-fidelity diagnostic sensory bypass overlay in C. It overrides low-level sensor readings via an auxiliary software hook. You can inspect the code below and apply the patch directly to your `src/main.c` workspace file.";
      suggestedAction = {
        type: 'apply_diff',
        label: 'Apply Code Diff to main.c',
        targetPath: 'src/main.c',
        newContent: `#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n\n// ANYREALM SENSORY BYPASS EXTENSION OVERWRITE\nint main(int argc, char *argv[]) {\n    printf("==========================================\\n");\n    printf("   ANYREALM HARDWARE SENSORY BYPASS TOOL   \\n");\n    printf("==========================================\\n");\n    \n    printf("[*] Probing hardware registry on physical board...\\n");\n    printf("[OK] Hardware bus initialized at physical register 0xEF43\\n");\n    printf("[*] Applying sensory spoofing vectors...\\n");\n    printf("[SUCCESS] Simulated temperature read fixed to stable 36.5°C\\n");\n    printf("[SUCCESS] Accelerometer offset hardcoded to absolute zero state.\\n");\n    printf("[SUCCESS] Standalone hardware bypass active in background.\\n");\n    return 0;\n}`
      };
    } else if (promptType === 'gdb') {
      userPromptText = "Setup GDB static debugger compilation targets in the Makefile";
      assistantReply = "Sure! I can inject high-fidelity static GDB debug hooks into the Makefile configuration. This binds `-g` debugging symbol headers during cross-compilation and formats the symbols securely.";
      suggestedAction = {
        type: 'apply_diff',
        label: 'Inject GDB Targets into Makefile',
        targetPath: 'Makefile',
        newContent: `CC = aarch64-linux-gnu-gcc\nCFLAGS = -O3 -Wall -static -g -ggdb\nTARGET = out/bin/realm_diagnostic_tool_debug\n\nall: clean\n\tmkdir -p out/bin\n\t$(CC) $(CFLAGS) src/main.c -o $(TARGET)\n\nclean:\n\trm -rf out/`
      };
    } else {
      userPromptText = "Add magiskpolicy permissive rules to our security metadata";
      assistantReply = "No problem. I have generated a magiskpolicy layout extension definition that injects critical custom permissive rules directly into target sepolicy binary trees, enabling userland hardware daemon communication.";
      suggestedAction = {
        type: 'apply_diff',
        label: 'Apply to extension_manifest.json',
        targetPath: 'extension_manifest.json',
        newContent: `{\n  "name": "Custom Hardware Permissive Policies",\n  "identifier": "realm.addon.sepolicy_bypass",\n  "version": "2.0.1",\n  "category": "security",\n  "arch": "arm64",\n  "binaries": [\n    "magiskpolicy",\n    "sepolicy-inject"\n  ],\n  "dependencies": [\n    "magiskpolicy-sepolicy"\n  ],\n  "description": "Cross-compiled standalone security extension loaded on startup to override restrictive SELinux containers."\n}`
      };
    }

    setAiChat(prev => [
      ...prev,
      {
        id: `user-${Date.now()}`,
        sender: 'user',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        text: userPromptText
      }
    ]);

    setIsAiTyping(true);

    setTimeout(() => {
      setIsAiTyping(false);
      setAiChat(prev => [
        ...prev,
        {
          id: `assistant-${Date.now()}`,
          sender: 'assistant',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          text: assistantReply,
          suggestedAction
        }
      ]);
    }, 1200);
  };

  // Chat message submit
  const handleAiSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiInput.trim()) return;

    const userText = aiInput.trim();
    setAiChat(prev => [
      ...prev,
      {
        id: `user-${Date.now()}`,
        sender: 'user',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        text: userText
      }
    ]);
    setAiInput('');
    setIsAiTyping(true);

    setTimeout(() => {
      setIsAiTyping(false);

      let text = "I've analyzed your request. I can help configure standalone compilations, import binary packages, or adapt workspace source code. Let's write customized C static tools or adjust compile options for your target CPU architecture.";
      let suggestedAction: AIMessage['suggestedAction'] = undefined;

      // Smart keywords matcher
      if (userText.toLowerCase().includes('bypass') || userText.toLowerCase().includes('hook') || userText.toLowerCase().includes('c code')) {
        text = "I have drafted a high-fidelity diagnostic sensory bypass overlay in C. Click 'Apply Code Diff' below to synchronize this directly into the live text editor workspace.";
        suggestedAction = {
          type: 'apply_diff',
          label: 'Apply Bypass Hook into main.c',
          targetPath: 'src/main.c',
          newContent: `#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n\n// SENSORY BOARD BYPASS CODE INJECTED BY CASCADE\nint main(int argc, char *argv[]) {\n    printf("AnyRealm Sensory Spoof Hook Active.\\n");\n    printf("[OK] Emulating board sensory inputs successfully.\\n");\n    return 0;\n}`
        };
      } else if (userText.toLowerCase().includes('build') || userText.toLowerCase().includes('make') || userText.toLowerCase().includes('compile')) {
        text = "I can trigger the GCC make compiler toolchain for you. Click 'Invoke Compiler Daemon' below to trigger the static building process.";
        suggestedAction = {
          type: 'run_build',
          label: 'Invoke Compiler Daemon'
        };
      }

      setAiChat(prev => [
        ...prev,
        {
          id: `assistant-${Date.now()}`,
          sender: 'assistant',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          text,
          suggestedAction
        }
      ]);
    }, 1400);
  };

  // Apply diff from Cascade AI directly into workspace active editor
  const handleApplyAiDiff = (targetPath: string, newContent: string) => {
    // Find the file
    const updatedFiles = workspaceFiles.map(f => {
      if (f.path === targetPath) {
        return { ...f, content: newContent };
      }
      return f;
    });

    setWorkspaceFiles(updatedFiles);

    const matchFile = updatedFiles.find(f => f.path === targetPath);
    if (matchFile) {
      setActiveFile(matchFile);
      setEditorCode(newContent);
    }

    // Add alert log in terminal & chat
    setTerminalLogs(prev => [
      ...prev,
      `[AI INTERFACE] Cascade synced code diff successfully into workspace: ${targetPath}`,
      'realm-user@anyrealm-os-container:~/workspace$ '
    ]);

    setAiChat(prev => [
      ...prev,
      {
        id: `system-diff-${Date.now()}`,
        sender: 'assistant',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        text: `✓ **Applied code updates** successfully to \`/${targetPath}\`! The editor has been refreshed in real-time. You can now type \`make\` in the Terminal below to compile your updated binary.`
      }
    ]);
  };

  // Convert bytes to readable sizes
  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="bg-[#0c1020] border border-slate-900 rounded-xl overflow-hidden shadow-2xl flex flex-col h-[740px]" id="windsurf-ide-root">
      
      {/* Windsurf Header Panel */}
      <div className="bg-[#080b18] border-b border-slate-900/80 px-4 py-2.5 flex items-center justify-between z-20 shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
          </div>
          <div className="h-4 w-px bg-slate-800 mx-1" />
          <div className="flex items-center gap-2">
            <Boxes className="text-indigo-400 w-4 h-4 animate-pulse" />
            <span className="text-[11.5px] font-bold text-slate-200 tracking-wide font-mono">AnyRealm Toolchain IDE & AI Companion</span>
            <span className="text-[9px] bg-indigo-600/10 text-indigo-400 px-1.5 py-0.5 rounded border border-indigo-500/20 font-mono uppercase font-extrabold tracking-wider">AI Cascade Co-Pilot</span>
          </div>
        </div>

        {/* Info label and Speech Toggle */}
        <div className="flex items-center gap-4 text-slate-500 text-[10px] font-mono">
          <button
            onClick={toggleSpeech}
            className={`p-1.5 rounded-full transition-colors ${
              isSpeechEnabled ? 'text-indigo-400 bg-indigo-500/10' : 'text-slate-500 hover:text-slate-300'
            }`}
            title={isSpeechEnabled ? "Disable Speech" : "Enable Speech"}
          >
            {isSpeechEnabled ? <Mic className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>
          <div className="flex items-center gap-1.5">
            <GitBranch className="w-3.5 h-3.5 text-slate-500" />
            <span>aosp-gki-3.14-stable</span>
          </div>
          <span className="text-emerald-500 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/15 flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            SECURE CONTAINER DAEMON ACTIVE
          </span>
        </div>
      </div>

      {/* Main IDE Workspace Area */}
      <div className="flex flex-1 overflow-hidden">
        
        {/* Activity Bar (Far Left, 48px width) */}
        <div className="w-12 bg-[#060814] border-r border-slate-900/60 flex flex-col items-center py-4 justify-between shrink-0">
          <div className="space-y-4 w-full flex flex-col items-center">
            {/* Explorer icon */}
            <button
              onClick={() => setActiveActivity('explorer')}
              className={`p-2.5 rounded-lg relative cursor-pointer group transition-colors ${
                activeActivity === 'explorer' ? 'text-indigo-400 bg-indigo-500/10' : 'text-slate-500 hover:text-slate-300'
              }`}
              title="File Explorer"
            >
              <Folder className="w-5 h-5" />
              <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-6 bg-indigo-500 scale-y-0 transition-all group-hover:scale-y-100 active:scale-y-100" />
            </button>

            {/* Extensions / Binary Packs icon */}
            <button
              onClick={() => setActiveActivity('extensions')}
              className={`p-2.5 rounded-lg relative cursor-pointer group transition-colors ${
                activeActivity === 'extensions' ? 'text-indigo-400 bg-indigo-500/10' : 'text-slate-500 hover:text-slate-300'
              }`}
              title="Binary Toolchain Extensions"
            >
              <Boxes className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 bg-indigo-600 text-[8px] font-extrabold px-1 rounded-full text-white scale-90">5</span>
            </button>

            {/* AI Assistant Chat (Cascade) */}
            <button
              onClick={() => setActiveActivity('ai')}
              className={`p-2.5 rounded-lg relative cursor-pointer group transition-colors ${
                activeActivity === 'ai' ? 'text-indigo-400 bg-indigo-500/10' : 'text-slate-500 hover:text-slate-300'
              }`}
              title="Windsurf Cascade AI"
            >
              <MessageSquare className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
            </button>

            {/* Matrix Module */}
            <button
              onClick={() => setActiveActivity('matrix')}
              className={`p-2.5 rounded-lg relative cursor-pointer group transition-colors ${
                activeActivity === 'matrix' ? 'text-purple-400 bg-purple-500/10' : 'text-slate-500 hover:text-slate-300'
              }`}
              title="Matrix Module Studio"
            >
              <Server className="w-5 h-5" />
            </button>

            {/* Custom Recovery Studio */}
            <button
              onClick={() => setActiveActivity('recovery')}
              className={`p-2.5 rounded-lg relative cursor-pointer group transition-colors ${
                activeActivity === 'recovery' ? 'text-rose-400 bg-rose-500/10' : 'text-slate-500 hover:text-slate-300'
              }`}
              title="Custom Recovery Studio"
            >
              <LifeBuoy className="w-5 h-5" />
            </button>
            
            {/* On-Device AI Agent Configurator */}
            <button
              onClick={() => setActiveActivity('agent')}
              className={`p-2.5 rounded-lg relative cursor-pointer group transition-colors ${
                activeActivity === 'agent' ? 'text-indigo-400 bg-indigo-500/10' : 'text-slate-500 hover:text-slate-300'
              }`}
              title="On-Device AI Agent Configurator"
            >
              <Bot className="w-5 h-5" />
            </button>


          </div>

          {/* Bottom Settings icon */}
          <button
            onClick={() => setActiveActivity('settings')}
            className={`p-2.5 rounded-lg text-slate-500 hover:text-slate-300 cursor-pointer ${
              activeActivity === 'settings' ? 'text-indigo-400 bg-indigo-500/10' : ''
            }`}
            title="IDE Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>

        {/* Side Panel (File Explorer / Extensions / Settings) */}
        <div className="w-64 bg-[#0a0d1d] border-r border-slate-900/60 flex flex-col shrink-0 overflow-y-auto">
          
          {/* Side Panel: File Explorer */}
          {activeActivity === 'explorer' && (
            <div className="p-4 space-y-4 flex flex-col h-full">
              <div className="flex items-center justify-between border-b border-slate-900 pb-2">
                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Workspace Files</span>
                <span className="text-[9px] font-mono text-indigo-400 bg-indigo-950/30 px-1.5 rounded">./workspace</span>
              </div>

              {/* Explorer Directories and list */}
              <div className="space-y-4 flex-1">
                {/* Virtual Directory Node */}
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-slate-300 font-bold px-1 py-0.5">
                    <FolderOpen className="w-4 h-4 text-indigo-400" />
                    <span>root_build_fuser</span>
                  </div>

                  <div className="pl-4 space-y-1">
                    {workspaceFiles.map((file) => (
                      <button
                        key={file.path}
                        onClick={() => {
                          setActiveFile(file);
                          setEditorCode(file.content);
                        }}
                        className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-left font-mono text-[11px] transition-all cursor-pointer ${
                          activeFile.path === file.path
                            ? 'bg-indigo-600/10 border border-indigo-500/25 text-indigo-300'
                            : 'bg-transparent text-slate-400 hover:bg-slate-900/50 hover:text-slate-200'
                        }`}
                      >
                        <span className="flex items-center gap-2 truncate">
                          <FileCode className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                          <span className="truncate">{file.name}</span>
                        </span>
                        <span className="text-[8px] opacity-60 text-slate-500 font-sans uppercase shrink-0">/{file.language}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Simulated Out Binary Folder */}
                <div className="space-y-1 pt-1 border-t border-slate-900/40">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 px-1 py-0.5 font-bold">
                    <Folder className="w-4 h-4 text-slate-600" />
                    <span>out/bin/ (Stated ELF)</span>
                  </div>
                  <div className="pl-4 font-mono text-[10.5px] text-emerald-400/80 py-1 flex items-center gap-2">
                    <Terminal className="w-3.5 h-3.5 text-emerald-500" />
                    <span>realm_diagnostic_tool</span>
                  </div>
                </div>
              </div>

              {/* Companion Tip box */}
              <div className="p-3 bg-indigo-950/15 border border-indigo-900/20 rounded-lg text-[10px] text-indigo-300 leading-relaxed">
                <Info className="w-3.5 h-3.5 text-indigo-400 inline mr-1 -mt-0.5 shrink-0" />
                <span>You can edit these virtual C and manifest source files, compile them statically via the bottom terminal, or chat with Cascade to apply updates!</span>
              </div>
            </div>
          )}

          {/* Side Panel: Extensions Manager */}
          {activeActivity === 'extensions' && (
            <div className="p-4 space-y-4 flex flex-col h-full">
              <div className="flex items-center justify-between border-b border-slate-900 pb-2">
                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Active Compiler Binaries</span>
                <span className="text-[9px] font-mono text-indigo-400">GNU LLVM Overlay</span>
              </div>

              <div className="space-y-2 flex-1 overflow-y-auto scrollbar-thin pr-0.5">
                {extensions.map(ext => (
                  <div
                    key={ext.id}
                    onClick={() => setSelectedExt(ext)}
                    className={`p-2.5 rounded-lg border transition-all cursor-pointer ${
                      selectedExt.id === ext.id
                        ? 'bg-indigo-950/20 border-indigo-500/40'
                        : 'bg-slate-900/40 border-slate-900/60 hover:bg-slate-900/60'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-1">
                      <h4 className="text-[11px] font-bold text-slate-200 truncate">{ext.name}</h4>
                      <span className="text-[9px] font-mono text-indigo-400 uppercase font-semibold">{ext.arch}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 line-clamp-2 leading-relaxed mb-1.5">{ext.description}</p>
                    <div className="flex items-center justify-between text-[8.5px] font-mono text-slate-500 border-t border-slate-900/40 pt-1">
                      <span>Exposed binaries: {ext.binaries.length}</span>
                      <span>{formatBytes(ext.sizeBytes)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Side Panel: AI Assistant Prompts Preset */}
          {activeActivity === 'ai' && (
            <div className="p-4 space-y-4 flex flex-col h-full">
              <div className="flex items-center justify-between border-b border-slate-900 pb-2">
                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Cascade Presets</span>
                <span className="text-[9px] font-mono text-indigo-400">Windsurf Co-Pilot</span>
              </div>

              <p className="text-[10.5px] text-slate-400 leading-relaxed">
                Choose a pre-armed toolchain request below to trigger AI code generation or static compiler injections automatically.
              </p>

              <div className="space-y-2.5 flex-1">
                <button
                  onClick={() => handleTriggerPresetChat('sensory')}
                  className="w-full text-left p-2.5 bg-slate-900/60 border border-slate-900 hover:border-slate-800 rounded-lg text-[10.5px] font-medium text-slate-200 transition-all hover:bg-slate-900 cursor-pointer flex items-center justify-between"
                >
                  <span>🛠️ Write C Sensory Bypass</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                </button>

                <button
                  onClick={() => handleTriggerPresetChat('gdb')}
                  className="w-full text-left p-2.5 bg-slate-900/60 border border-slate-900 hover:border-slate-800 rounded-lg text-[10.5px] font-medium text-slate-200 transition-all hover:bg-slate-900 cursor-pointer flex items-center justify-between"
                >
                  <span>🐛 Setup GDB static debugging</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                </button>

                <button
                  onClick={() => handleTriggerPresetChat('sepolicy')}
                  className="w-full text-left p-2.5 bg-slate-900/60 border border-slate-900 hover:border-slate-800 rounded-lg text-[10.5px] font-medium text-slate-200 transition-all hover:bg-slate-900 cursor-pointer flex items-center justify-between"
                >
                  <span>🔒 Inject magiskpolicy SELinux rules</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                </button>
              </div>
            </div>
          )}

          {/* Side Panel: Settings & Environment vars */}
          {activeActivity === 'settings' && (
            <div className="p-4 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-900 pb-2">
                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Environment Parameters</span>
                <span className="text-[9px] font-mono text-indigo-400">Settings</span>
              </div>

              <div className="space-y-3 font-mono text-[9.5px]">
                <div className="p-2 bg-black/40 rounded border border-slate-900 space-y-1">
                  <span className="text-slate-500 block uppercase font-bold text-[8.5px]">CROSS_TARGET</span>
                  <span className="text-slate-300 font-bold">aarch64-linux-gnu-static</span>
                </div>
                
                <div className="p-2 bg-black/40 rounded border border-slate-900 space-y-1">
                  <span className="text-slate-500 block uppercase font-bold text-[8.5px]">COMPILER_FLAGS</span>
                  <span className="text-slate-300 font-bold">-O3 -Wall -static -ffunction-sections</span>
                </div>

                <div className="p-2 bg-black/40 rounded border border-slate-900 space-y-1">
                  <span className="text-slate-500 block uppercase font-bold text-[8.5px]">STRIP_SYMBOLS</span>
                  <span className="text-emerald-400 font-bold">TRUE (llvm-strip)</span>
                </div>

                <div className="p-2 bg-black/40 rounded border border-slate-900 space-y-1">
                  <span className="text-slate-500 block uppercase font-bold text-[8.5px]">OVERLAY_PERSISTENCE</span>
                  <span className="text-indigo-400 font-bold">SquashFS Fused overlays</span>
                </div>
              </div>
            </div>
          )}

          {/* Side Panel: Matrix Module */}
          {activeActivity === 'matrix' && (
            <div className="p-4 flex flex-col h-full">
              <MatrixModuleStudio />
            </div>
          )}

          {/* Side Panel: Custom Recovery Studio */}
          {activeActivity === 'recovery' && (
            <div className="p-4 flex flex-col h-full">
              <CustomRecoveryStudio />
            </div>
          )}
          
          {/* Side Panel: On-Device AI Agent Configurator */}
          {activeActivity === 'agent' && (
            <div className="p-4 flex flex-col h-full">
              <OnDeviceAgentConfigurator />
            </div>
          )}


        </div>

        {/* Center Code Editor (Main workspace view) */}
        <div className="flex-1 flex flex-col bg-[#0b0e1a] overflow-hidden">
          
          {/* Editor Header / Tabs bar */}
          <div className="bg-[#080b15] border-b border-slate-900/60 px-4 py-2 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <FileCode className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-bold text-slate-200 font-mono">/{activeFile.path}</span>
              <span className="text-[8.5px] bg-slate-900 text-slate-500 border border-slate-800 px-1 py-0.2 rounded uppercase font-mono font-bold tracking-wider">{activeFile.language}</span>
            </div>
            
            {/* Compile make shortcut button */}
            <button
              onClick={handleTriggerBuild}
              disabled={isBuilding}
              className="flex items-center gap-1.5 px-3 py-1 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-[10px] rounded cursor-pointer transition-colors shadow-md shadow-indigo-950/30"
            >
              {isBuilding ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Hammer className="w-3 h-3" />}
              {isBuilding ? "Compiling..." : "🔨 Compile Static Binary (Make)"}
            </button>
          </div>

          {/* Interactive Code Editor with line numbers */}
          <div className="flex-1 flex overflow-hidden relative">
            {/* Line numbers column */}
            <div className="w-10 bg-[#080b15] text-slate-600 font-mono text-[10.5px] text-right pr-3.5 pt-4 select-none border-r border-slate-900/20 leading-relaxed">
              {Array.from({ length: editorCode.split('\n').length || 1 }).map((_, idx) => (
                <div key={idx} className="h-[18px]">{idx + 1}</div>
              ))}
            </div>

            {/* Realtime Editable Textarea */}
            <textarea
              value={editorCode}
              onChange={(e) => handleEditorChange(e.target.value)}
              className="flex-1 bg-[#0b0e1a] text-slate-200 font-mono text-[10.5px] leading-relaxed resize-none focus:outline-none p-4 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-900/40 select-text h-full"
              style={{ tabSize: 4, fontFamily: '"JetBrains Mono", Fira Code, monospace' }}
              id="windsurf-inline-editor"
              spellCheck={false}
            />

            {/* Hover floating save feedback indicator */}
            <div className="absolute bottom-3 right-4 bg-slate-950/80 border border-slate-900 rounded-md px-2 py-0.5 text-[8.5px] font-mono text-slate-400">
              Auto-save synchronized | UTF-8
            </div>
          </div>

          {/* Bottom Panel (Tabs: Interactive Terminal, Build logs, problems) */}
          <div className="h-60 bg-[#070914] border-t border-slate-900 flex flex-col shrink-0">
            {/* Bottom tabs bar */}
            <div className="bg-[#05060d] border-b border-slate-900/80 px-4 py-1.5 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setBottomTab('terminal')}
                  className={`text-[10.5px] font-bold tracking-wider uppercase cursor-pointer transition-colors ${
                    bottomTab === 'terminal' ? 'text-indigo-400 border-b border-indigo-400 pb-0.5' : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  📟 Interactive Terminal
                </button>
                <button
                  onClick={() => setBottomTab('build_output')}
                  className={`text-[10.5px] font-bold tracking-wider uppercase cursor-pointer transition-colors ${
                    bottomTab === 'build_output' ? 'text-indigo-400 border-b border-indigo-400 pb-0.5' : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  🔨 GCC Compiler Output {isBuilding && <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping ml-1" />}
                </button>
                <button
                  onClick={() => setBottomTab('problems')}
                  className={`text-[10.5px] font-bold tracking-wider uppercase cursor-pointer transition-colors ${
                    bottomTab === 'problems' ? 'text-indigo-400 border-b border-indigo-400 pb-0.5' : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  ⚠️ Problems (0)
                </button>
              </div>

              <div className="text-[9.5px] font-mono text-slate-600 uppercase tracking-widest">
                Statically linked shell emulator
              </div>
            </div>

            {/* Tab content panel */}
            <div className="flex-1 p-3 font-mono text-[10.5px] overflow-y-auto scrollbar-thin">
              
              {/* TAB: TERMINAL */}
              {bottomTab === 'terminal' && (
                <div className="space-y-1 text-slate-300 flex flex-col h-full justify-between">
                  <div className="space-y-1 flex-1 overflow-y-auto max-h-[140px] pr-1 scrollbar-none">
                    {terminalLogs.map((log, i) => (
                      <div key={i} className={`leading-relaxed whitespace-pre-wrap ${
                        log.startsWith('realm-user@') ? 'text-indigo-300 font-bold' : 
                        log.includes('[SUCCESS]') || log.includes('successful') ? 'text-emerald-400 font-bold' : 
                        log.startsWith('Error:') || log.includes('bash: ') ? 'text-red-400' : 'text-slate-400'
                      }`}>
                        {log}
                      </div>
                    ))}
                  </div>

                  {/* Terminal input prompt */}
                  <form onSubmit={handleTerminalSubmit} className="flex items-center gap-1.5 border-t border-slate-900/50 pt-2 shrink-0">
                    <span className="text-indigo-300 font-bold shrink-0">realm-user@anyrealm-os-container:~/workspace$</span>
                    <input
                      type="text"
                      value={terminalInput}
                      onChange={(e) => setTerminalInput(e.target.value)}
                      className="flex-1 bg-transparent border-none text-slate-200 outline-none p-0 focus:ring-0 font-mono text-[10.5px]"
                      placeholder="e.g. ls, make, ./out/bin/realm_diagnostic_tool run-diagnostics, cat Makefile"
                      id="ide-terminal-input"
                    />
                  </form>
                </div>
              )}

              {/* TAB: BUILD LOGS */}
              {bottomTab === 'build_output' && (
                <div className="space-y-1 text-slate-300 max-h-[160px] overflow-y-auto pr-1">
                  {buildLogs.length === 0 ? (
                    <div className="text-slate-500 italic text-center pt-8">
                      No active compilation run. Click the 'Compile Static Binary' button in the toolbar above to run the GCC build sequence.
                    </div>
                  ) : (
                    buildLogs.map((log, idx) => (
                      <div key={idx} className={`truncate ${
                        log.startsWith('[SUCCESS]') ? 'text-emerald-400 font-bold' : 
                        log.startsWith('$') ? 'text-blue-400' : 'text-slate-300'
                      }`}>
                        {log}
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* TAB: PROBLEMS */}
              {bottomTab === 'problems' && (
                <div className="flex flex-col items-center justify-center text-center p-6 text-slate-500 h-full">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500/60 mb-2" />
                  <p className="font-bold text-slate-400 text-xs">Zero Compilation Diagnostics Failed</p>
                  <p className="text-[10px] text-slate-500 mt-1">Statically compiled linking targets cleared the LLVM analyzer cleanly.</p>
                </div>
              )}

            </div>
          </div>
        </div>

        {/* Right Panel: Windsurf Cascade AI Companion Sidebar (280px width) */}
        <div className="w-80 bg-[#090b17] border-l border-slate-900 flex flex-col justify-between shrink-0 overflow-hidden">
          
          {/* AI companion title */}
          <div className="bg-[#050711] border-b border-slate-900/80 px-4 py-2.5 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
              <span className="text-xs font-bold text-slate-200 uppercase tracking-widest font-mono">Cascade Co-Pilot</span>
            </div>
            <span className="text-[8.5px] bg-indigo-600/10 text-indigo-400 border border-indigo-500/25 px-1.5 py-0.5 rounded font-mono uppercase font-bold tracking-wider">ANYREALM DAEMON v2.5</span>
          </div>

          {/* AI Message Stream */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 scrollbar-thin scrollbar-thumb-slate-900/40">
            {aiChat.map((msg) => (
              <div key={msg.id} className={`flex flex-col gap-1 ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
                {/* Meta details */}
                <span className="text-[8.5px] text-slate-500 font-mono">{msg.sender === 'user' ? 'You' : 'Cascade AI'} • {msg.timestamp}</span>
                
                {/* Bubble */}
                <div className={`p-3 rounded-xl max-w-[260px] text-[11px] leading-relaxed font-sans ${
                  msg.sender === 'user' 
                    ? 'bg-indigo-600 text-white rounded-tr-none shadow-md shadow-indigo-950/25' 
                    : 'bg-slate-950/80 border border-slate-900 text-slate-300 rounded-tl-none'
                }`}>
                  {/* Handle inline bold markup or standard string */}
                  {msg.text.split('**').map((chunk, idx) => (
                    idx % 2 === 1 ? <strong key={idx} className="text-white font-extrabold">{chunk}</strong> : chunk
                  ))}

                  {/* Suggest action (such as Apply Diff / Trigger Build) */}
                  {msg.suggestedAction && (
                    <div className="mt-3.5 pt-2.5 border-t border-slate-900 flex flex-col gap-2">
                      <div className="text-[9px] font-mono text-slate-500 uppercase tracking-wider">Suggested Companion Action:</div>
                      
                      {msg.suggestedAction.type === 'apply_diff' && (
                        <button
                          onClick={() => handleApplyAiDiff(msg.suggestedAction!.targetPath!, msg.suggestedAction!.newContent!)}
                          className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[10.5px] font-bold cursor-pointer transition-colors shadow-lg shadow-emerald-950/20"
                        >
                          <Check className="w-3.5 h-3.5" />
                          {msg.suggestedAction.label}
                        </button>
                      )}

                      {msg.suggestedAction.type === 'run_build' && (
                        <button
                          onClick={handleTriggerBuild}
                          className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-[10.5px] font-bold cursor-pointer transition-colors shadow-lg shadow-indigo-950/20"
                        >
                          <Hammer className="w-3.5 h-3.5" />
                          {msg.suggestedAction.label}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* Simulated typing animation */}
            {isAiTyping && (
              <div className="flex flex-col gap-1 items-start">
                <span className="text-[8.5px] text-slate-500 font-mono">Cascade AI is writing...</span>
                <div className="bg-slate-950/80 border border-slate-900 p-3 rounded-xl rounded-tl-none text-[11px] text-slate-400 flex items-center gap-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-400" />
                  <span>Scanning toolchain parameters and resolving static ELF offsets...</span>
                </div>
              </div>
            )}

            <div ref={chatBottomRef} />
          </div>

          {/* Prompt quick inputs list */}
          <div className="px-4 py-1.5 bg-[#050711]/40 border-t border-slate-900/60 flex flex-wrap gap-1 shrink-0">
            <button 
              onClick={() => handleTriggerPresetChat('sensory')}
              className="px-2 py-0.5 bg-slate-950 border border-slate-900/80 hover:border-indigo-500/20 text-[9px] text-slate-400 hover:text-slate-200 rounded cursor-pointer font-mono"
            >
              #main.c
            </button>
            <button 
              onClick={() => handleTriggerPresetChat('gdb')}
              className="px-2 py-0.5 bg-slate-950 border border-slate-900/80 hover:border-indigo-500/20 text-[9px] text-slate-400 hover:text-slate-200 rounded cursor-pointer font-mono"
            >
              #Makefile
            </button>
            <button 
              onClick={() => handleTriggerPresetChat('sepolicy')}
              className="px-2 py-0.5 bg-slate-950 border border-slate-900/80 hover:border-indigo-500/20 text-[9px] text-slate-400 hover:text-slate-200 rounded cursor-pointer font-mono"
            >
              #SELinux
            </button>
          </div>

          {/* Chat input form */}
          <form onSubmit={handleAiSubmit} className="p-3 bg-[#050711] border-t border-slate-900/80 flex gap-2 shrink-0">
            <input
              type="text"
              value={aiInput}
              onChange={(e) => setAiInput(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-900 focus:outline-none focus:border-indigo-500/80 rounded-lg px-3 py-1.5 text-xs text-slate-300 font-medium"
              placeholder="Ask Cascade to write code or add tools..."
              id="ide-ai-input"
            />
            <button
              type="submit"
              className="p-2 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-white cursor-pointer transition-colors"
              id="ide-ai-send-btn"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

        </div>

      </div>

    </div>
  );
}
