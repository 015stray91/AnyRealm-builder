import React from 'react';
import { Layers } from 'lucide-react';

interface Layer {
  name: string;
  size: string;
  type: string;
  color: string;
}

const LAYERS: Layer[] = [
  { name: 'Kernel Image (Zimage)', size: '12MB', type: 'base', color: 'bg-indigo-900' },
  { name: 'RootFS SquashFS', size: '250MB', type: 'compressed', color: 'bg-blue-800' },
  { name: 'App Binaries (ARM64)', size: '85MB', type: 'compressed', color: 'bg-cyan-700' },
  { name: 'Overlay/Config', size: '2MB', type: 'mutable', color: 'bg-amber-600' },
];

export default function RootfsStackVisualizer() {
  return (
    <div className="bg-slate-950 p-5 rounded-2xl border border-slate-900 shadow-inner">
      <h4 className="text-xs font-bold text-slate-300 mb-4 flex items-center gap-2">
        <Layers className="w-4 h-4 text-indigo-400" />
        RootFS Stack (Arch 64 Compressed)
      </h4>
      <div className="space-y-1">
        {LAYERS.map((layer, idx) => (
          <div key={idx} className={`${layer.color} p-3 rounded-lg flex justify-between items-center`}>
            <span className="text-xs text-white font-mono font-bold">{layer.name}</span>
            <span className="text-[10px] text-white/70 font-mono">{layer.size}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
