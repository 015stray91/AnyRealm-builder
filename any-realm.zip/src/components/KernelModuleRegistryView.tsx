import React from 'react';
import { Package, Search, AlertCircle, CheckCircle } from 'lucide-react';

interface KernelModule {
  id: string;
  name: string;
  type: 'upstream' | 'out-of-tree';
  hasHiddenObjects: boolean;
}

const MODULES: KernelModule[] = [
  { id: '1', name: 'drivers/net/wireless/broadcom/brcmfmac', type: 'upstream', hasHiddenObjects: false },
  { id: '2', name: 'drivers/gpu/drm/msm/adreno', type: 'upstream', hasHiddenObjects: true },
  { id: '3', name: 'vendor/qcom/proprietary/sensor-hub', type: 'out-of-tree', hasHiddenObjects: true },
  { id: '4', name: 'vendor/oem/custom-power-manager', type: 'out-of-tree', hasHiddenObjects: false },
];

export default function KernelModuleRegistryView() {
  return (
    <div className="bg-[#111827] border border-[#1e293b] rounded-2xl p-6 shadow-xl flex flex-col gap-6">
      <div className="flex justify-between items-center border-b border-slate-900 pb-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Package className="text-indigo-500 w-6 h-6" /> Kernel Module Registry
        </h2>
      </div>

      <div className="space-y-2">
        {MODULES.map(module => (
          <div key={module.id} className="bg-slate-950 p-4 rounded-xl border border-slate-900 flex items-center justify-between hover:border-slate-800 transition-colors">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded ${module.type === 'upstream' ? 'bg-indigo-950 text-indigo-400' : 'bg-amber-950 text-amber-400'}`}>
                <Package className="w-4 h-4" />
              </div>
              <div className="text-sm font-mono text-slate-300">{module.name}</div>
            </div>
            
            <div className="flex items-center gap-4">
              <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${module.type === 'upstream' ? 'bg-indigo-900/30 text-indigo-400' : 'bg-amber-900/30 text-amber-400'}`}>
                {module.type}
              </span>
              
              {module.hasHiddenObjects ? (
                <div className="flex items-center gap-1 text-rose-400 text-[10px] font-bold">
                  <AlertCircle className="w-3.5 h-3.5" /> Hidden Objects
                </div>
              ) : (
                <div className="flex items-center gap-1 text-emerald-400 text-[10px] font-bold">
                  <CheckCircle className="w-3.5 h-3.5" /> Clean
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
