import React, { useState } from 'react';
import { LifeBuoy, Zap, RefreshCw, Smartphone } from 'lucide-react';

export default function CustomRecoveryStudio() {
  const [recoveryType, setRecoveryType] = useState<'twrp' | 'orangefox' | 'pitchblack' | 'rom_custom'>('twrp');
  const [detectedRecovery, setDetectedRecovery] = useState<string | null>(null);
  const [isDetecting, setIsDetecting] = useState<boolean>(false);
  const [isBuilding, setIsBuilding] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([]);

  const handleDetect = () => {
    setIsDetecting(true);
    setLogs(['[*] Probing device for existing recovery partitions...']);
    setTimeout(() => {
      setDetectedRecovery('TWRP 3.7.0_12-0');
      setLogs(prev => [...prev, '[+] Detected: TWRP 3.7.0_12-0']);
      setIsDetecting(false);
    }, 1500);
  };

  const handleBuild = () => {
    setIsBuilding(true);
    setLogs(prev => [...prev, `[*] Initializing ${recoveryType.toUpperCase()} build pipeline...`]);
    setTimeout(() => {
      setLogs(prev => [...prev, `[+] Fetching source tree and device trees...`]);
    }, 800);
    setTimeout(() => {
      setLogs(prev => [...prev, `[+] Compiling recovery image and kernel...`]);
    }, 1600);
    setTimeout(() => {
      setLogs(prev => [...prev, `[SUCCESS] ${recoveryType.toUpperCase()} image built successfully.`]);
      setIsBuilding(false);
    }, 2400);
  };

  return (
    <div className="bg-[#0f1225] p-6 rounded-xl border border-rose-900/30 flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-600 to-pink-600 flex items-center justify-center shadow-lg shadow-rose-500/20">
          <LifeBuoy className="text-white w-5 h-5" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">Custom Recovery Studio</h2>
          <p className="text-xs text-slate-400">Build and manage custom recovery images.</p>
        </div>
      </div>

      <div className="bg-[#13162d] p-4 rounded-lg border border-rose-900/40">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">Device Detection</h3>
        <div className="flex items-center justify-between">
          <span className="text-xs text-slate-400">Current Recovery: {detectedRecovery || 'Unknown'}</span>
          <button
            onClick={handleDetect}
            disabled={isDetecting}
            className="px-3 py-1 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs font-bold rounded cursor-pointer transition-all"
          >
            {isDetecting ? 'Probing...' : 'Probe Device'}
          </button>
        </div>
      </div>

      <div className="bg-[#13162d] p-4 rounded-lg border border-rose-900/40">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">Target Recovery Type</h3>
        <select 
          value={recoveryType}
          onChange={(e) => setRecoveryType(e.target.value as any)}
          className="w-full bg-[#0a0d1d] text-slate-200 border border-rose-500/30 rounded px-3 py-2 text-xs"
        >
          <option value="twrp">TWRP (Team Win Recovery Project)</option>
          <option value="orangefox">OrangeFox Recovery</option>
          <option value="pitchblack">PitchBlack Recovery</option>
          <option value="rom_custom">ROM Custom Recovery (Evolution X / others)</option>
        </select>
      </div>

      <button
        onClick={handleBuild}
        disabled={isBuilding}
        className="flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white text-sm font-bold rounded-lg shadow-lg shadow-rose-500/20 transition-all disabled:opacity-50"
      >
        {isBuilding ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
        {isBuilding ? 'Building...' : 'Execute Recovery Build'}
      </button>

      {/* Logs */}
      {logs.length > 0 && (
        <div className="bg-black/50 p-4 rounded-lg border border-slate-800 font-mono text-[10px] text-slate-400 h-24 overflow-y-auto">
          {logs.map((log, i) => (
            <div key={i} className="mb-1">{log}</div>
          ))}
        </div>
      )}
    </div>
  );
}
