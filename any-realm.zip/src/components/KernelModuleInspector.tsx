import React, { useState, useEffect } from 'react';
import { Cpu, Power, Activity, Terminal, Shield, MemoryStick } from 'lucide-react';

interface KernelModule {
  id: string;
  name: string;
  status: 'loaded' | 'unloaded' | 'error';
  version: string;
  gkiVersion: '1.0' | '2.0';
  memory: string;
  namespace: string;
  permissions: string[];
  stability: 'stable' | 'unstable';
  diff: string;
}

export default function KernelModuleInspector() {
  const [selectedGki, setSelectedGki] = useState<'1.0' | '2.0'>('1.0');
  const [modules, setModules] = useState<KernelModule[]>([
    { id: 'kpm_thermal', name: 'thermal_mgmt_kpm', status: 'loaded', version: '1.2.0', gkiVersion: '1.0', memory: '4.2MB', namespace: 'kernel/thermal', permissions: ['r', 'w'], stability: 'stable', diff: '+0.1% latency' },
    { id: 'kpm_gpu_boost', name: 'gpu_boost_lkm', status: 'unloaded', version: '2.1.5', gkiVersion: '2.0', memory: '0MB', namespace: 'kernel/gpu', permissions: ['r', 'w', 'x'], stability: 'stable', diff: 'N/A' },
    { id: 'kpm_io_scheduler', name: 'io_sched_kpm', status: 'error', version: '0.9.8', gkiVersion: '1.0', memory: '1.8MB', namespace: 'kernel/io', permissions: ['r'], stability: 'unstable', diff: '+15.2% latency' },
  ]);

  const sortedModules = [...modules].sort((a, b) => a.name.localeCompare(b.name));

  useEffect(() => {
    const interval = setInterval(() => {
      setModules(prev => prev.map(m => {
        if (m.status === 'loaded') {
          return {
            ...m,
            memory: (Math.random() * 10).toFixed(1) + 'MB',
            stability: Math.random() > 0.9 ? 'unstable' : 'stable',
            diff: (Math.random() * 20).toFixed(1) + '% latency'
          };
        }
        return m;
      }));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const toggleModule = (id: string) => {
    setModules(prev => prev.map(m => {
      if (m.id === id) {
        return { ...m, status: m.status === 'loaded' ? 'unloaded' : 'loaded' };
      }
      return m;
    }));
  };

  return (
    <div className="bg-[#111827] border border-[#1e293b] rounded-2xl p-6 shadow-xl flex flex-col gap-6">
      <div className="flex justify-between items-center border-b border-slate-900 pb-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Cpu className="text-purple-500 w-6 h-6" /> Live Kernel Module Inspector
        </h2>
        <div className="flex items-center gap-2 bg-slate-950 p-1 rounded-xl border border-slate-900">
          {(['1.0', '2.0'] as const).map(ver => (
            <button
              key={ver}
              onClick={() => setSelectedGki(ver)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${selectedGki === ver ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
            >
              GKI v{ver}
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-400 font-mono">
          <thead className="text-slate-500 border-b border-slate-800">
            <tr>
              <th className="pb-3 px-2">Module</th>
              <th className="pb-3 px-2">Status</th>
              <th className="pb-3 px-2">Memory</th>
              <th className="pb-3 px-2">Namespace</th>
              <th className="pb-3 px-2">Permissions</th>
              <th className="pb-3 px-2">Stability</th>
              <th className="pb-3 px-2">Diff</th>
              <th className="pb-3 px-2">Compliance</th>
              <th className="pb-3 px-2">Action</th>
            </tr>
          </thead>
          <tbody>
            {sortedModules.map(module => {
                const isCompliant = module.gkiVersion === selectedGki;
                return (
              <tr key={module.id} className="border-b border-slate-900 last:border-b-0 hover:bg-slate-900/50">
                <td className="py-3 px-2 text-white">{module.name} <span className="text-[10px] text-slate-600">v{module.version}</span></td>
                <td className="py-3 px-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] ${module.status === 'loaded' ? 'bg-emerald-950 text-emerald-400' : module.status === 'error' ? 'bg-rose-950 text-rose-400' : 'bg-slate-900 text-slate-500'}`}>
                        {module.status.toUpperCase()}
                    </span>
                </td>
                <td className="py-3 px-2">{module.memory}</td>
                <td className="py-3 px-2">{module.namespace}</td>
                <td className="py-3 px-2">{module.permissions.join(', ')}</td>
                <td className={`py-3 px-2 font-bold ${module.stability === 'stable' ? 'text-emerald-400' : 'text-rose-400'}`}>{module.stability.toUpperCase()}</td>
                <td className="py-3 px-2">{module.diff}</td>
                <td className="py-3 px-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] ${isCompliant ? 'bg-indigo-950 text-indigo-400' : 'bg-rose-950 text-rose-400'}`}>
                        {isCompliant ? 'COMPLIANT' : 'INVALID'}
                    </span>
                </td>
                <td className="py-3 px-2">
                    <button
                        onClick={() => toggleModule(module.id)}
                        disabled={module.status === 'error' || !isCompliant}
                        className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold transition-all ${module.status === 'loaded' ? 'bg-rose-950 text-rose-400 hover:bg-rose-900' : 'bg-emerald-950 text-emerald-400 hover:bg-emerald-900'} ${!isCompliant ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                        <Power className="w-3 h-3" />
                        {module.status === 'loaded' ? 'Unload' : 'Load'}
                    </button>
                </td>
              </tr>
            );})}
          </tbody>
        </table>
      </div>

      <div className="p-4 bg-slate-900 rounded-lg flex items-start gap-3 text-slate-400 text-xs font-mono">
        <Terminal className="w-4 h-4 flex-shrink-0 mt-0.5" />
        <p>Virtual device interface ready. Real-time telemetry active for GKI {selectedGki}...</p>
      </div>
    </div>
  );
}
