/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Github, 
  Globe, 
  Key, 
  Terminal, 
  Usb, 
  CheckCircle2, 
  User, 
  GitBranch, 
  ShieldCheck, 
  ArrowRight, 
  Lock, 
  RefreshCw, 
  FolderGit2,
  Cpu,
  Smartphone,
  Check,
  Play,
  Layers,
  CpuIcon,
  HardDrive,
  Settings as SettingsIcon
} from 'lucide-react';

interface LoginConnectPortalProps {
  onProceedToStudio: () => void;
  onDeviceDataFetched?: (data: any) => void;
}

export default function LoginConnectPortal({ onProceedToStudio, onDeviceDataFetched }: LoginConnectPortalProps) {
  const [authStatus, setAuthStatus] = useState<{
    github: boolean;
    google: boolean;
    gitlab: boolean;
    facebook: boolean;
    username: string;
    email: string;
  }>({
    github: false,
    google: false,
    gitlab: false,
    facebook: false,
    username: '',
    email: ''
  });

  const [activeProvider, setActiveProvider] = useState<string | null>(null);
  
  // Handshake & Automated Sequence States
  const [connectionStep, setConnectionStep] = useState<'idle' | 'fastboot' | 'reboot' | 'adb_unlock' | 'pulling_props' | 'pulling_settings' | 'pulling_kernel' | 'pulling_pm' | 'completed'>('idle');
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);
  const [deviceProps, setDeviceProps] = useState<any>({
    model: 'Moto G Stylus 5G (genevn)',
    buildId: 'UP1A.231005.007',
    androidVersion: '14.0',
    soc: 'Qualcomm Snapdragon 6 Gen 1 (SM6450)',
    kernel: '6.1.43-android14-1-g7a8e2b9 (arm64)',
    ram: '6GB LPDDR4X',
    storage: '256GB UFS 2.2',
    securityPatch: '2026-06-05',
    bootloader: 'Unlocked (orange State)',
    globalSettingsCount: 142,
    secureSettingsCount: 88,
    systemSettingsCount: 114,
    featuresCount: 76
  });

  const handleSimulateOAuth = (provider: 'github' | 'google' | 'gitlab' | 'facebook') => {
    setActiveProvider(provider);
  };

  const handleCompleteLogin = (provider: 'github' | 'google' | 'gitlab' | 'facebook') => {
    const userNames = {
      github: 'dev-architect-99',
      google: 'builder.user@gmail.com',
      gitlab: 'lab-signer-user',
      facebook: 'alex.developer.meta'
    };
    const emails = {
      github: 'architect@anyrealm.org',
      google: 'builder.user@gmail.com',
      gitlab: 'signer@gitlab.com',
      facebook: 'alex.dev@facebook.user'
    };

    setAuthStatus(prev => ({
      ...prev,
      [provider]: true,
      username: userNames[provider],
      email: emails[provider]
    }));
    setActiveProvider(null);
  };

  const startAutomatedHandshakeSequence = async () => {
    setConnectionStep('fastboot');
    setTerminalLogs([
      '[00:01] Initializing WebUSB / WebDB bridge on port 3000...',
      '[00:02] Executing fastboot getvar all...'
    ]);

    await new Promise(r => setTimeout(r, 1500));
    setTerminalLogs(prev => [
      ...prev,
      '(bootloader) product: genevn',
      '(bootloader) secure: no',
      '(bootloader) unlocked: yes',
      '[00:03] Executing fastboot reboot...'
    ]);

    setConnectionStep('reboot');
    await new Promise(r => setTimeout(r, 1800));
    setTerminalLogs(prev => [
      ...prev,
      '[00:05] Device rebooting into Android runtime...',
      '[00:06] Waiting for ADB daemon to bind on tcp:5555...'
    ]);

    setConnectionStep('adb_unlock');
    await new Promise(r => setTimeout(r, 1500));
    setTerminalLogs(prev => [
      ...prev,
      '[00:07] ADB connection established. Please unlock device screen if passcode is required.',
      '[00:08] Invoking adb get-state -> device online.'
    ]);

    setConnectionStep('pulling_props');
    await new Promise(r => setTimeout(r, 1400));
    setTerminalLogs(prev => [
      ...prev,
      '[00:09] Executing: adb shell getprop',
      'ro.product.model = Moto G Stylus 5G',
      'ro.build.display.id = UP1A.231005.007',
      'ro.board.platform = sm6450',
      'ro.build.version.release = 14'
    ]);

    setConnectionStep('pulling_settings');
    await new Promise(r => setTimeout(r, 1300));
    setTerminalLogs(prev => [
      ...prev,
      '[00:11] Executing: adb shell settings list global',
      '[00:12] Executing: adb shell settings list secure',
      '[00:13] Executing: adb shell settings list system',
      'Successfully dumped 344 system setting keys.'
    ]);

    setConnectionStep('pulling_kernel');
    await new Promise(r => setTimeout(r, 1200));
    setTerminalLogs(prev => [
      ...prev,
      '[00:14] Executing: adb shell zcat /proc/config.gz | grep -i CONFIG_',
      'CONFIG_ANDROID_BINDER_IPC=y',
      'CONFIG_KERNEL_GZIP=y',
      'CONFIG_SECCOMP=y'
    ]);

    setConnectionStep('pulling_pm');
    await new Promise(r => setTimeout(r, 1200));
    setTerminalLogs(prev => [
      ...prev,
      '[00:16] Executing: adb shell pm list features',
      '[00:17] Executing: adb shell pm list packages -3',
      'All 76 system features and hardware constraints gathered successfully.'
    ]);

    setConnectionStep('completed');
    setTerminalLogs(prev => [
      ...prev,
      '[00:19] [SUCCESS] Device handshake and full parameter dump complete. Ready for ROM Customization & Linux Distribution build.'
    ]);

    if (onDeviceDataFetched) {
      onDeviceDataFetched(deviceProps);
    }
  };

  const isAnyLoggedIn = authStatus.github || authStatus.google || authStatus.gitlab || authStatus.facebook;

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 flex flex-col gap-10" id="login-connect-portal-root">
      
      {/* Hero Welcome Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-[#0f172a] to-indigo-950 border border-indigo-500/30 rounded-2xl p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-mono font-bold mb-4">
              <ShieldCheck className="w-3.5 h-3.5" />
              Page 1: Authentication & Automated WebADB Handshake
            </div>
            <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight mb-2">
              Any Realm Device & Repository Portal
            </h2>
            <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
              Authenticate with your developer identity (GitHub, Google, GitLab, or Facebook) and run the automated Fastboot & WebADB diagnostic sequence to pull system properties, kernel configs, and hardware parameters before entering the customization dashboard.
            </p>
          </div>

          {isAnyLoggedIn && (
            <div className="bg-indigo-950/80 border border-indigo-500/40 p-4 rounded-xl flex items-center gap-4 shrink-0 shadow-lg">
              <div className="w-12 h-12 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold text-lg shadow-inner">
                {authStatus.username.charAt(0).toUpperCase()}
              </div>
              <div>
                <span className="text-xs text-indigo-300 font-bold block">Authenticated Profile</span>
                <span className="text-sm font-semibold text-white block">{authStatus.username}</span>
                <span className="text-[10px] text-slate-400 font-mono">{authStatus.email}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Grid: Developer Logins vs WebADB Handshake & Command Sequence */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Left Card: Developer Logins (GitHub, Google, GitLab, Facebook) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-indigo-600/20 text-indigo-400">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Developer & Social Logins</h3>
                  <p className="text-xs text-slate-400">Establish profile & sync repositories</p>
                </div>
              </div>
              {isAnyLoggedIn && (
                <span className="px-2.5 py-1 rounded-md bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Linked
                </span>
              )}
            </div>

            <div className="space-y-3 mb-6">
              {/* GitHub Login */}
              <div className={`p-3.5 rounded-xl border transition-all ${authStatus.github ? 'bg-indigo-950/30 border-indigo-500/40' : 'bg-slate-950 border-slate-800'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center text-white">
                      <Github className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">GitHub Integration</h4>
                      <p className="text-xs text-slate-400">{authStatus.github ? 'Connected (aosp-core)' : 'Access source trees'}</p>
                    </div>
                  </div>
                  {authStatus.github ? (
                    <span className="text-xs text-indigo-400 font-bold flex items-center gap-1"><Check className="w-4 h-4" /> Connected</span>
                  ) : (
                    <button onClick={() => handleSimulateOAuth('github')} className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold cursor-pointer">
                      Connect
                    </button>
                  )}
                </div>
              </div>

              {/* Google Login */}
              <div className={`p-3.5 rounded-xl border transition-all ${authStatus.google ? 'bg-indigo-950/30 border-indigo-500/40' : 'bg-slate-950 border-slate-800'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center text-blue-400">
                      <Globe className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Google Developer Login</h4>
                      <p className="text-xs text-slate-400">{authStatus.google ? 'Connected (Compiler Node)' : 'Cloud nodes'}</p>
                    </div>
                  </div>
                  {authStatus.google ? (
                    <span className="text-xs text-indigo-400 font-bold flex items-center gap-1"><Check className="w-4 h-4" /> Connected</span>
                  ) : (
                    <button onClick={() => handleSimulateOAuth('google')} className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold border border-slate-700 cursor-pointer">
                      Sign-In
                    </button>
                  )}
                </div>
              </div>

              {/* GitLab Login */}
              <div className={`p-3.5 rounded-xl border transition-all ${authStatus.gitlab ? 'bg-indigo-950/30 border-indigo-500/40' : 'bg-slate-950 border-slate-800'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center text-amber-500">
                      <GitBranch className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">GitLab Sign-In</h4>
                      <p className="text-xs text-slate-400">{authStatus.gitlab ? 'Connected (CI Pipelines)' : 'ROM mirrors'}</p>
                    </div>
                  </div>
                  {authStatus.gitlab ? (
                    <span className="text-xs text-indigo-400 font-bold flex items-center gap-1"><Check className="w-4 h-4" /> Connected</span>
                  ) : (
                    <button onClick={() => handleSimulateOAuth('gitlab')} className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold border border-slate-700 cursor-pointer">
                      Connect
                    </button>
                  )}
                </div>
              </div>

              {/* Facebook Login */}
              <div className={`p-3.5 rounded-xl border transition-all ${authStatus.facebook ? 'bg-indigo-950/30 border-indigo-500/40' : 'bg-slate-950 border-slate-800'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-blue-700 flex items-center justify-center text-white font-bold text-sm">
                      f
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Facebook Authentication</h4>
                      <p className="text-xs text-slate-400">{authStatus.facebook ? 'Connected (Profile Linked)' : 'Social login & sync'}</p>
                    </div>
                  </div>
                  {authStatus.facebook ? (
                    <span className="text-xs text-indigo-400 font-bold flex items-center gap-1"><Check className="w-4 h-4" /> Connected</span>
                  ) : (
                    <button onClick={() => handleSimulateOAuth('facebook')} className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer">
                      Facebook Login
                    </button>
                  )}
                </div>
              </div>
            </div>

            {activeProvider && (
              <div className="bg-slate-950 border border-indigo-500/30 p-4 rounded-xl mb-6 animate-fadeIn">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-2">
                  <Lock className="w-3.5 h-3.5 text-indigo-400" />
                  Authenticate {activeProvider.toUpperCase()} Profile
                </h4>
                <p className="text-xs text-slate-400 mb-3">
                  Authorize identity verification and secure repository token generation for Any Realm studio.
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleCompleteLogin(activeProvider as any)}
                    className="flex-1 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold cursor-pointer"
                  >
                    Authorize & Connect
                  </button>
                  <button
                    onClick={() => setActiveProvider(null)}
                    className="px-3 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-slate-800">
            <button
              onClick={onProceedToStudio}
              disabled={!isAnyLoggedIn || connectionStep !== 'completed'}
              className={`w-full py-3.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                isAnyLoggedIn && connectionStep === 'completed'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-teal-500/25 cursor-pointer'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              Proceed to Page 2: ROM Customizer & Linux Builder
              <ArrowRight className="w-4 h-4" />
            </button>
            {(!isAnyLoggedIn || connectionStep !== 'completed') && (
              <p className="text-[11px] text-slate-500 text-center mt-2">
                {!isAnyLoggedIn ? 'Please log in with at least one provider.' : 'Please run and complete the WebADB Fastboot automated handshake sequence.'}
              </p>
            )}
          </div>
        </div>

        {/* Right Card: Automated WebADB Handshake & Command Sequence */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-blue-600/20 text-blue-400">
                  <Terminal className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Automated WebADB Handshake Sequence</h3>
                  <p className="text-xs text-slate-400">Fastboot getvar &rarr; Reboot &rarr; ADB props &amp; settings pull</p>
                </div>
              </div>

              <button
                onClick={startAutomatedHandshakeSequence}
                disabled={connectionStep !== 'idle' && connectionStep !== 'completed'}
                className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                  connectionStep === 'completed'
                    ? 'bg-emerald-600/20 border border-emerald-500/40 text-emerald-400'
                    : connectionStep !== 'idle'
                    ? 'bg-blue-600/50 text-white cursor-wait'
                    : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md'
                }`}
              >
                {connectionStep !== 'idle' && connectionStep !== 'completed' ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Running Sequence...
                  </>
                ) : connectionStep === 'completed' ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    Handshake Complete
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" />
                    Start Device Handshake
                  </>
                )}
              </button>
            </div>

            {/* Terminal Console Output */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 h-64 overflow-y-auto font-mono text-[11px] text-emerald-400/90 mb-4 shadow-inner flex flex-col gap-1">
              {terminalLogs.length === 0 ? (
                <div className="text-slate-600 italic my-auto text-center">
                  Click "Start Device Handshake" to execute:
                  <br />
                  1. fastboot getvar all &amp; reboot
                  <br />
                  2. adb get-state &amp; unlock prompt
                  <br />
                  3. adb shell getprop &amp; settings list (global, secure, system)
                  <br />
                  4. kernel config dump &amp; pm list features
                </div>
              ) : (
                terminalLogs.map((log, idx) => (
                  <div key={idx} className="leading-relaxed">
                    {log}
                  </div>
                ))
              )}
            </div>

            {/* Sequence Status Steps */}
            <div className="grid grid-cols-4 gap-2 text-center text-[10px] font-mono">
              <div className={`p-2 rounded-lg border ${connectionStep !== 'idle' ? 'bg-indigo-950/40 border-indigo-500/40 text-indigo-300' : 'bg-slate-950 border-slate-800 text-slate-500'}`}>
                1. Fastboot Getvar
              </div>
              <div className={`p-2 rounded-lg border ${['reboot', 'adb_unlock', 'pulling_props', 'pulling_settings', 'pulling_kernel', 'pulling_pm', 'completed'].includes(connectionStep) ? 'bg-indigo-950/40 border-indigo-500/40 text-indigo-300' : 'bg-slate-950 border-slate-800 text-slate-500'}`}>
                2. ADB Unlock
              </div>
              <div className={`p-2 rounded-lg border ${['pulling_props', 'pulling_settings', 'pulling_kernel', 'pulling_pm', 'completed'].includes(connectionStep) ? 'bg-indigo-950/40 border-indigo-500/40 text-indigo-300' : 'bg-slate-950 border-slate-800 text-slate-500'}`}>
                3. Props &amp; Settings
              </div>
              <div className={`p-2 rounded-lg border ${connectionStep === 'completed' ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300 font-bold' : 'bg-slate-950 border-slate-800 text-slate-500'}`}>
                4. Kernel &amp; PM
              </div>
            </div>
          </div>

          <div className="text-[11px] text-slate-500 bg-slate-950/50 p-3 rounded-lg border border-slate-800/80 mt-4">
            <span className="font-bold text-slate-400 block mb-0.5">Automated Data Pipeline</span>
            All gathered device parameters, build ID properties, and package features are structured and passed instantly to Page 2 for custom ROM tailoring and Linux distribution builds.
          </div>
        </div>

      </div>

    </div>
  );
}

