import React, { useState } from 'react';
import { Bot, Cpu, Zap, Brain, Shield } from 'lucide-react';

export default function OnDeviceAgentConfigurator() {
  const [persona, setPersona] = useState<'tech' | 'formal' | 'casual'>('tech');
  const [model, setModel] = useState<'lite' | 'pro'>('lite');
  const [permissions, setPermissions] = useState<string[]>(['logs', 'battery']);

  return (
    <div className="bg-[#0f1225] p-6 rounded-xl border border-indigo-900/30 flex flex-col gap-6" id="agent-config">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
          <Bot className="text-white w-5 h-5" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">On-Device AI Agent</h2>
          <p className="text-xs text-slate-400">Configure your personalized assistant to run natively on the device.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-[#13162d] p-4 rounded-lg border border-indigo-900/40">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">Persona</h3>
          <div className="space-y-2">
            {(['tech', 'formal', 'casual'] as const).map((p) => (
              <button key={p} onClick={() => setPersona(p)} className={`w-full text-left p-2 rounded text-xs font-semibold ${persona === p ? 'bg-indigo-600 text-white' : 'text-slate-400 bg-slate-900'}`}>
                {p.charAt(0).toUpperCase() + p.slice(1)}
              </button>
            ))}
          </div>
        </div>
        <div className="bg-[#13162d] p-4 rounded-lg border border-indigo-900/40">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">Model</h3>
          <div className="space-y-2">
            {(['lite', 'pro'] as const).map((m) => (
              <button key={m} onClick={() => setModel(m)} className={`w-full text-left p-2 rounded text-xs font-semibold ${model === m ? 'bg-purple-600 text-white' : 'text-slate-400 bg-slate-900'}`}>
                {m.toUpperCase()} (Quantized)
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-[#13162d] p-4 rounded-lg border border-indigo-900/40">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-2"><Shield className="w-3 h-3" /> System Access</h3>
        <div className="flex gap-2">
            {['logs', 'battery', 'network'].map(p => (
                <button key={p} className={`px-3 py-1 rounded-full text-[10px] font-bold ${permissions.includes(p) ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-slate-500'}`}>
                    {p.toUpperCase()}
                </button>
            ))}
        </div>
      </div>

      <button className="flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-sm font-bold rounded-lg shadow-lg hover:from-indigo-500 hover:to-purple-500 transition-all">
        <Zap className="w-4 h-4" />
        Package Agent into Image
      </button>
    </div>
  );
}
