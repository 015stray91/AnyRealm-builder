/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  GitMerge, 
  Layers, 
  Terminal, 
  HelpCircle, 
  Sparkles, 
  Cpu, 
  Play, 
  Plus, 
  Check, 
  AlertTriangle,
  FolderTree,
  Code2,
  Info,
  Database,
  Workflow,
  Languages,
  HardDrive,
  FileArchive,
  Users,
  Wrench,
  Settings,
  Boxes,
  Cloud,
  Usb,
  User
} from 'lucide-react';
import AospArchitect from './components/AospArchitect';
import ModuleVectorSettingsPanel from './components/ModuleVectorSettingsPanel';
import RootfsFuser from './components/RootfsFuser';
import AospCodeStudio from './components/AospCodeStudio';
import DeveloperConsole from './components/DeveloperConsole';
import SuperPartitionStudio from './components/SuperPartitionStudio';
import AutomationStudio from './components/AutomationStudio';
import UiTranslatorInterpreter from './components/UiTranslatorInterpreter';
import IsoDissectorStudio from './components/IsoDissectorStudio';
import FirmwareDecomposer from './components/FirmwareDecomposer';
import PeoplesImporter from './components/PeoplesImporter';
import AndroidImageKitchen from './components/AndroidImageKitchen';
import ExperimentalLaboratory from './components/ExperimentalLaboratory';
import ToolchainExtensionHub from './components/ToolchainExtensionHub';
import BootSequenceAnalyzer from './components/BootSequenceAnalyzer';
import QualcommKernelPortingStudio from './components/QualcommKernelPortingStudio';
import WebAdbStudio from './components/WebAdbStudio';
import LoginConnectPortal from './components/LoginConnectPortal';
import { DeviceMetadata, AospComponent, GeneratedFile } from './types';

// ... (existing imports)

export default function App() {
  const [deviceMetadata, setDeviceMetadata] = useState<DeviceMetadata | null>(null);

  // Initial pre-configured core components of our custom AOSP Board
  const [components, setComponents] = useState<AospComponent[]>([
    {
      id: 'color_picker_app',
      name: 'ColorPicker System UI',
      layer: 'Apps',
      type: 'System UI Application',
      description: 'An AOSP pre-installed system application that displays the colors and coordinates detected by the physical sensor. Dynamically links to the custom hardware manager.',
      selinuxContext: 'system_app'
    },
    {
      id: 'custom_sensor_service',
      name: 'ColorSensorService Manager',
      layer: 'Framework Services',
      type: 'Java System Service',
      description: 'Lives inside system_server. Registers the custom color sensor binder with AOSP ServiceManager, handling client callbacks, JNI mappings, and permission enforcements.',
      selinuxContext: 'system_server_service',
      dependencies: ['custom_sensor_hal'],
      aidlMethods: [
        { name: 'registerCallback', returnType: 'void', parameters: [{ name: 'cb', type: 'IColorCallback', direction: 'in' }] },
        { name: 'getLatestColorData', returnType: 'int[]', parameters: [] },
        { name: 'setSensorSensitivity', returnType: 'boolean', parameters: [{ name: 'level', type: 'int', direction: 'in' }] }
      ]
    },
    {
      id: 'custom_sensor_hal',
      name: 'android.hardware.colorsensor-service',
      layer: 'HAL',
      type: 'C++ AIDL HAL Service',
      description: 'A modern AOSP AIDL Hardware Abstraction Layer. Acts as the stable interface between Java system services and raw native background daemons.',
      selinuxContext: 'hal_colorsensor_default',
      dependencies: ['sensor_daemon'],
      aidlMethods: [
        { name: 'getColorRGB', returnType: 'ColorData', parameters: [] },
        { name: 'enableSensor', returnType: 'void', parameters: [{ name: 'enable', type: 'boolean', direction: 'in' }] }
      ]
    },
    {
      id: 'sensor_daemon',
      name: 'colorsensord Daemon',
      layer: 'Native Daemons',
      type: 'Native C++ System Daemon',
      description: 'Low-level background native daemon written in C++. It communicates with kernel filesystems, handles uevents, structures coordinates, and serves them via socket or binder to the HAL.',
      selinuxContext: 'sensor_daemon_exec',
      dependencies: ['sensor_driver']
    },
    {
      id: 'sensor_driver',
      name: 'colorsensor_driver',
      layer: 'Kernel',
      type: 'I2C Platform Kernel Driver',
      description: 'Linux platform character device driver. Communicates over raw physical I2C, handles device trees, physical interrupts, and registers character file nodes under /dev/colorsensor.',
      selinuxContext: 'colorsensor_device',
      dependencies: []
    }
  ]);

  const [partitions, setPartitions] = useState<any[]>([
    {
      name: 'system',
      sizeMb: 1500,
      filesystem: 'erofs',
      erofsCompression: 'lz4hc',
      readOnly: true,
      description: 'Android Core Operating System OS binaries, frameworks, and JNI linkages fused with Linux glibc dependencies.'
    },
    {
      name: 'vendor',
      sizeMb: 600,
      filesystem: 'erofs',
      erofsCompression: 'lz4',
      readOnly: true,
      description: 'Device-specific HAL services, AIDL drivers, hardware modules, and proprietary blobs.'
    },
    {
      name: 'product',
      sizeMb: 500,
      filesystem: 'erofs',
      erofsCompression: 'none',
      readOnly: true,
      description: 'OEM system specifications, application layers, branding materials, and vendor overlay configs.'
    },
    {
      name: 'system_ext',
      sizeMb: 300,
      filesystem: 'ext4',
      erofsCompression: 'none',
      readOnly: false,
      description: 'Optional system extension packages and custom development toolchains.'
    }
  ]);
  const [superCapacityMb, setSuperCapacityMb] = useState<number>(4096);
  const [lastAutoSaved, setLastAutoSaved] = useState<string | null>(null);

  const discoverDevice = async () => {
    // Simulate WebADB/Fastboot interaction
    await new Promise(resolve => setTimeout(resolve, 2000));
    setDeviceMetadata({
      model: 'Moto G Stylus 5G',
      codename: 'genevn',
      arch: 'GKI 2.0 (Android 13 / Kernel 5.15)',
      activeSlot: 'B',
      partitions: 'system.erofs (2.4GB), vendor.img (1.1GB), boot.img (LZ4 Ramdisk)',
      sdkVersion: '33'
    });
  };

  const [activeTab, setActiveTab] = useState<'login' | 'architect' | 'fuser' | 'code' | 'super' | 'automation' | 'interpreter' | 'iso_fs' | 'firmware' | 'peoples' | 'aik' | 'module_vector' | 'experimental' | 'toolchains' | 'bootloader' | 'qualcomm_porting' | 'web_adb'>('login');
  const [userProfile, setUserProfile] = useState<'admin' | 'user'>('admin');
  const [isGeneratingCode, setIsGeneratingCode] = useState(false);
  const [isRefactoringCode, setIsRefactoringCode] = useState(false);
  const [generatedFiles, setGeneratedFiles] = useState<GeneratedFile[]>([]);
  const [isConsoleOpen, setIsConsoleOpen] = useState(false);

  // Resume Workspace from LocalStorage if active
  useEffect(() => {
    const saved = localStorage.getItem('aosp_architect_workspace');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.deviceMetadata) setDeviceMetadata(parsed.deviceMetadata);
        if (parsed.components) setComponents(parsed.components);
        if (parsed.generatedFiles) setGeneratedFiles(parsed.generatedFiles);
        if (parsed.partitions) setPartitions(parsed.partitions);
        if (parsed.superCapacityMb) setSuperCapacityMb(parsed.superCapacityMb);
        setLastAutoSaved(new Date().toLocaleTimeString());
      } catch (err) {
        console.error("Failed to restore session from LocalStorage:", err);
      }
    }
  }, []);

  // 10-minute Auto-save Heartbeat
  useEffect(() => {
    const interval = setInterval(() => {
      const stateToSave = {
        deviceMetadata,
        components,
        generatedFiles,
        partitions,
        superCapacityMb
      };
      localStorage.setItem('aosp_architect_workspace', JSON.stringify(stateToSave));
      const now = new Date().toLocaleTimeString();
      setLastAutoSaved(now);
    }, 600000); // 10 minutes

    return () => clearInterval(interval);
  }, [deviceMetadata, components, generatedFiles, partitions, superCapacityMb]);

  const handleExportSession = () => {
    const stateToExport = {
      timestamp: new Date().toISOString(),
      deviceMetadata,
      components,
      generatedFiles,
      partitions,
      superCapacityMb
    };
    const element = document.createElement("a");
    const file = new Blob([JSON.stringify(stateToExport, null, 2)], { type: 'application/json' });
    element.href = URL.createObjectURL(file);
    element.download = `aosp_session_workspace_${new Date().toISOString().substring(0,10)}.json`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleImportSession = (fileContent: string) => {
    try {
      const parsed = JSON.parse(fileContent);
      if (parsed.deviceMetadata) setDeviceMetadata(parsed.deviceMetadata);
      if (parsed.components) setComponents(parsed.components);
      if (parsed.generatedFiles) setGeneratedFiles(parsed.generatedFiles);
      if (parsed.partitions) setPartitions(parsed.partitions);
      if (parsed.superCapacityMb) setSuperCapacityMb(parsed.superCapacityMb);
      setLastAutoSaved(new Date().toLocaleTimeString());
      return true;
    } catch (e) {
      console.error("Import failure:", e);
      return false;
    }
  };
  
  const [selectedComponent, setSelectedComponent] = useState<AospComponent | null>(components[1]);

  // Handle generation of actual AOSP code via backend Gemini
  const handleGenerateCode = async (component: AospComponent) => {
    setIsGeneratingCode(true);
    try {
      const response = await fetch('/api/generate-component', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          componentName: component.name,
          componentType: component.type,
          layer: component.layer,
          description: component.description,
          aidlMethods: component.aidlMethods,
          connectedComponents: component.dependencies
        })
      });

      if (!response.ok) {
        throw new Error("Failed to compile target files.");
      }

      const data = await response.json();
      if (data && data.files) {
        setGeneratedFiles(data.files);
        setActiveTab('code'); // Navigate to Code Studio to see the results
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingCode(false);
    }
  };

  // Handle AI refactoring of currently active file
  const handleRefactorCode = async (instruction: string) => {
    if (!selectedComponent || generatedFiles.length === 0) return;
    setIsRefactoringCode(true);
    try {
      const response = await fetch('/api/generate-component', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          componentName: selectedComponent.name,
          componentType: selectedComponent.type,
          layer: selectedComponent.layer,
          description: `${selectedComponent.description}. Modified under these rules: ${instruction}`,
          aidlMethods: selectedComponent.aidlMethods,
          connectedComponents: selectedComponent.dependencies
        })
      });

      if (!response.ok) {
        throw new Error("Failed to refactor file.");
      }

      const data = await response.json();
      if (data && data.files) {
        setGeneratedFiles(data.files);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsRefactoringCode(false);
    }
  };

  // Pre-load default component files on start so the user is greeted with code
  useEffect(() => {
    if (selectedComponent && generatedFiles.length === 0) {
      handleGenerateCode(selectedComponent);
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#070913] text-slate-100 flex flex-col font-sans" id="aosp-architect-app-root">
      
      {/* Top Navigation / App Title Header */}
      <header className="border-b border-[#1e293b]/65 bg-[#090d1a] sticky top-0 z-50 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/10">
            <Cpu className="text-white w-5.5 h-5.5" />
          </div>
          <div>
            <h1 className="text-lg font-extrabold tracking-tight text-white flex items-center gap-2">
              Any Realm <span className="text-[10px] bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 font-mono font-bold px-1.5 py-0.5 rounded mr-2">Any RealM v1.4</span>
              {lastAutoSaved && (
                <span className="text-[10px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono font-bold px-1.5 py-0.5 rounded animate-pulse">Auto-saved {lastAutoSaved}</span>
              )}
            </h1>
            <p className="text-xs text-slate-400">Design, code, and fuse custom system services, custom HAL drivers, and manage secure people imports.</p>
          </div>
        </div>

        {/* Actions & Tab Selection Wrap */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Tab selection */}
          <div className="flex bg-[#0f172a] border border-[#1e293b] p-1 rounded-lg overflow-x-auto max-w-full scrollbar-none gap-1 whitespace-nowrap">
            <button
              onClick={() => setActiveTab('login')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'login' 
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-login-connect"
            >
              <User className="w-3.5 h-3.5" />
              Login & Connect Portal
            </button>

            <button
              onClick={() => setActiveTab('architect')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'architect' 
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-architect-studio"
            >
              <Layers className="w-3.5 h-3.5" />
              Architect Studio
            </button>

            <button
              onClick={() => setActiveTab('fuser')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'fuser' 
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-rootfs-fuser"
            >
              <GitMerge className="w-3.5 h-3.5" />
              Rootfs Fuser
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'code' 
                  ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-code-studio"
            >
              <Code2 className="w-3.5 h-3.5" />
              AOSP Code Studio
            </button>

            <button
              onClick={() => setActiveTab('super')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'super' 
                  ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-super-partition"
            >
              <Database className="w-3.5 h-3.5" />
              Super Partition (LP & EROFS)
            </button>

            <button
              onClick={() => setActiveTab('automation')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'automation' 
                  ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-automation-pipeline"
            >
              <Workflow className="w-3.5 h-3.5" />
              Automation & Agents (CI/CD)
            </button>

            <button
              onClick={() => setActiveTab('interpreter')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'interpreter' 
                  ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-ui-translator-interpreter"
            >
              <Languages className="w-3.5 h-3.5" />
              UI & Translation Interpreter
            </button>

            <button
              onClick={() => setActiveTab('iso_fs')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'iso_fs' 
                  ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-iso-fs-matrix"
            >
              <HardDrive className="w-3.5 h-3.5" />
              ISO Dissector & FS Matrix
            </button>

            <button
              onClick={() => setActiveTab('firmware')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'firmware' 
                  ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-carrier-firmware-decomposer"
            >
              <FileArchive className="w-3.5 h-3.5" />
              Stock Firmware Decomposer
            </button>

            <button
              onClick={() => setActiveTab('peoples')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'peoples' 
                  ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-peoples-importer"
            >
              <Users className="w-3.5 h-3.5" />
              Peoples & Signers
            </button>

            <button
              onClick={() => setActiveTab('aik')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'aik' 
                  ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-android-image-kitchen"
            >
              <Wrench className="w-3.5 h-3.5" />
              Android Image Kitchen (AIK)
            </button>

            <button
              onClick={() => setActiveTab('module_vector')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'module_vector' 
                  ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-module-vector-settings"
            >
              <Settings className="w-3.5 h-3.5" />
              Module Vector Settings
            </button>

            <button
              onClick={() => setActiveTab('experimental')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'experimental' 
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-experimental-laboratory"
            >
              <GitMerge className="w-3.5 h-3.5" />
              Experimental Laboratory
            </button>

            <button
              onClick={() => setActiveTab('toolchains')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'toolchains' 
                  ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-toolchain-extensions"
            >
              <Boxes className="w-3.5 h-3.5 text-indigo-400" />
              Toolchains & Extensions
            </button>

            <button
              onClick={() => setActiveTab('bootloader')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'bootloader' 
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-bootloader-studio"
            >
              <Cpu className="w-3.5 h-3.5" />
              Bootloader Studio
            </button>

            <button
              onClick={() => setActiveTab('qualcomm_porting')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'qualcomm_porting' 
                  ? 'bg-gradient-to-r from-blue-500 to-cyan-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-qualcomm-porting-studio"
            >
              <Cloud className="w-3.5 h-3.5" />
              Qualcomm Porting
            </button>

            <button
              onClick={() => setActiveTab('web_adb')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                activeTab === 'web_adb' 
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              id="tab-web-adb-studio"
            >
              <Usb className="w-3.5 h-3.5 text-blue-400" />
              Web ADB & Fastboot
            </button>
          </div>

          {/* Profile Switcher: Admin vs User Distributed */}
          <div className="flex items-center gap-1.5 bg-[#0f172a] border border-[#1e293b] p-1 rounded-lg">
            <button
              onClick={() => setUserProfile('admin')}
              className={`px-3 py-1.5 rounded text-xs font-bold transition-all cursor-pointer ${
                userProfile === 'admin'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Admin Mode
            </button>
            <button
              onClick={() => setUserProfile('user')}
              className={`px-3 py-1.5 rounded text-xs font-bold transition-all cursor-pointer ${
                userProfile === 'user'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              User Distributed
            </button>
          </div>

          <button
            onClick={() => setIsConsoleOpen(true)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-300 hover:text-white border border-indigo-500/30 hover:border-indigo-500/50 rounded-lg text-xs font-bold transition-all shadow shadow-indigo-500/5 cursor-pointer"
            id="open-dev-console-btn"
          >
            <Database className="w-3.5 h-3.5 animate-pulse text-indigo-400" />
            Developer Console
          </button>
        </div>
      </header>

      {/* Main Container Wrapper */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 flex flex-col gap-8">
        
        {/* Conceptual Alert of full-stack power */}
        <div className="bg-gradient-to-r from-blue-500/10 to-indigo-500/5 border border-blue-500/20 rounded-xl p-4 flex items-start gap-3">
          <Info className="text-blue-400 w-5 h-5 shrink-0 mt-0.5" />
          <div className="text-xs text-slate-300 leading-relaxed">
            <span className="font-bold text-white block mb-0.5">Dual-System Architecture Fusion Workspace</span>
            This workspace lets you visually map custom AOSP layers and **fuse standard Linux root filesystems (glibc)** into the AOSP runtime hierarchy. This creates unified system images with zero overhead, combining standard Debian/Ubuntu toolchains with stable AOSP low-level HAL services and AIDL interface drivers.
          </div>
        </div>

        {/* Tab view dispatches */}
        <div className="flex-1">
          {activeTab === 'login' && (
            <LoginConnectPortal onProceedToStudio={() => setActiveTab('architect')} />
          )}

          {activeTab === 'architect' && (
            <AospArchitect
              onSelectComponent={(comp) => {
                setSelectedComponent(comp);
                // Pre-fetch files when selecting a new component
                handleGenerateCode(comp);
              }}
              selectedComponent={selectedComponent}
              components={components}
              setComponents={setComponents}
              generatedFiles={generatedFiles}
              setGeneratedFiles={setGeneratedFiles}
              onGenerateCode={handleGenerateCode}
              isGenerating={isGeneratingCode}
              deviceMetadata={deviceMetadata}
              discoverDevice={discoverDevice}
            />
          )}

          {activeTab === 'fuser' && (
            <RootfsFuser />
          )}

          {activeTab === 'code' && (
            <AospCodeStudio
              files={generatedFiles}
              onRefactor={handleRefactorCode}
              isRefactoring={isRefactoringCode}
              activeComponentId={selectedComponent?.id || ''}
              selectedComponent={selectedComponent}
              deviceMetadata={deviceMetadata}
              onConnectDevice={discoverDevice}
              userProfile={userProfile}
            />
          )}

          {activeTab === 'super' && (
            <SuperPartitionStudio 
              deviceMetadata={deviceMetadata}
              partitions={partitions}
              setPartitions={setPartitions}
              superCapacityMb={superCapacityMb}
              setSuperCapacityMb={setSuperCapacityMb}
            />
          )}

          {activeTab === 'experimental' && (
            <ExperimentalLaboratory />
          )}

          {activeTab === 'automation' && (
            <AutomationStudio workspaceFiles={generatedFiles} />
          )}

          {activeTab === 'interpreter' && (
            <UiTranslatorInterpreter />
          )}

          {activeTab === 'iso_fs' && (
            <IsoDissectorStudio />
          )}

          {activeTab === 'firmware' && (
            <FirmwareDecomposer />
          )}

          {activeTab === 'peoples' && (
            <PeoplesImporter />
          )}

          {activeTab === 'aik' && (
            <AndroidImageKitchen />
          )}

          {activeTab === 'module_vector' && (
            <ModuleVectorSettingsPanel deviceMetadata={deviceMetadata} />
          )}

          {activeTab === 'toolchains' && (
            <ToolchainExtensionHub />
          )}

          {activeTab === 'bootloader' && (
            <BootSequenceAnalyzer />
          )}

          {activeTab === 'qualcomm_porting' && (
            <QualcommKernelPortingStudio />
          )}

          {activeTab === 'web_adb' && (
            <WebAdbStudio />
          )}
        </div>
      </main>

      {/* Developer Console Slider Drawer */}
      <DeveloperConsole 
        isOpen={isConsoleOpen} 
        onClose={() => setIsConsoleOpen(false)} 
        activeFiles={generatedFiles} 
        onExportSession={handleExportSession}
        onImportSession={handleImportSession}
        deviceMetadata={deviceMetadata}
        components={components}
        partitions={partitions}
        superCapacityMb={superCapacityMb}
      />

      {/* Humble page footer with visual branding */}
      <footer className="border-t border-[#1e293b]/40 py-6 px-6 bg-[#090d1a] text-center text-xs text-slate-500">
        <p>© 2026 Any Realm Workstation. Built with Google Gemini AI integration. Standard AOSP Apache 2.0 license applied.</p>
      </footer>
    </div>
  );
}
